/*
 Copyright (c) 2014 Shinji Tsuneyuki
 This file is distributed under the terms of the GNU General Public License version 3.
 */

/*!
 \file dtatoms.cc
 \brief �i�q�̌��q�z�u�f�[�^�̃N���X
*/

#include <stdio.h>
#include "dtatoms.h"
#include "dtcif.h"
#include "dtcell.h"
#include "qtmisc.h"
#include "qtexception.h"
#include "symbol.h"


DTAtoms::DTAtoms( void )
{
  clear();
}

void DTAtoms::clear( void )
{
  vatom.clear();
  unselect();
}

bool DTAtoms::loadXYZ( DTCell& cell, const QString& fname )
{
  FILE* fptr = fopen(fname, "rb" );
  if( fptr == NULL ){
    throw MyException("can not open a molecule file.",fname);
  }

  clear();

  char buf[256];

  int Na = 0;
  Position L = Position(0.0,0.0,0.0);
  char name[8];
  Position r;

  fgets( buf, sizeof(buf), fptr ); // SKIP total atoms line
  if( 1+3*3 == sscanf( buf, "%d %lf %lf %lf %lf %lf %lf %lf %lf %lf",
		       &Na, 
		       &cell.Ea.a,&cell.Ea.b,&cell.Ea.c,
		       &cell.Eb.a,&cell.Eb.b,&cell.Eb.c,
		       &cell.Ec.a,&cell.Ec.b,&cell.Ec.c ) ){
    cell.length = 1.0;
    cell.clear();
    cell.update();
  }
  else if( 1+3 == sscanf( buf, "%d %lf %lf %lf",
		     &Na, &L.x, &L.y, &L.z ) ){
    cell.length = 1.0;
    cell.Ea = Position(L.x,0.0,0.0);
    cell.Eb = Position(0.0,L.y,0.0);
    cell.Ec = Position(0.0,0.0,L.z);
    cell.update();
  }
  else if( 1 == sscanf( buf, "%d", &Na ) ){
  }
  else{
    throw MyException("broken header in a molecule file.",fname);
  }

  fgets( buf, sizeof(buf), fptr ); // SKIP commnet line

  while( fgets( buf, sizeof(buf), fptr ) ){
    DTAtom atom;
    if( 4 != sscanf( buf, "%s %lf %lf %lf",
		     name, &r.x, &r.y, &r.z ) ) continue;

    atom.name = QString(name);
    atom.number = ElementSymbol::getAtomicNumber(atom.name);
    atom.coords = cell.getCoordinatesNormalized(r);
    vatom.push_back(atom);
  }

  fclose(fptr);

  if( Na != (int)vatom.size() ){
    throw MyException("inconsistent number of atoms in a molecule file.",fname);
  }


  return true;
}


bool DTAtoms::loadCIF( DTCell& cell, const QString& fname )
{
  DTCIF cif;
  if( !cif.load(fname) ){
    throw MyException("can not open a molecule file.",fname);
  }

  clear();
  {
    cell.clear();
    cell.length = 1.0;
    cell.Ea = cif.unit_prim[0];
    cell.Eb = cif.unit_prim[1];
    cell.Ec = cif.unit_prim[2];
    cell.update();
  }

  for( int i=0; i<(int)cif.vatom_prim.size(); i++ ){
    DTAtom atom;

    atom.name = ElementSymbol::getAtomicName(cif.vatom_prim[i].name);
    atom.number = ElementSymbol::getAtomicNumber(atom.name);    
    atom.coords = cif.vatom_prim[i].coords;

    vatom.push_back(atom);
  }

  return true;
}

void DTAtoms::update( void )
{
}

bool DTAtoms::select( const int iatom )
{
  if( iatom<0 || (int)vatom.size()<=iatom ) return false;
  if( iatom_selected == iatom ) return false;

  iatom_selected = iatom;

  return true;
}

void DTAtoms::unselect( void )
{
  iatom_selected = -1;
}

bool DTAtoms::isSelected( void ) const
{
  return iatom_selected != -1;
}

int  DTAtoms::getSelected( void ) const
{
  return iatom_selected;
}


bool DTAtoms::changeSelected( const QString& name )
{
  if( !isSelected() ) return false;

  vatom[iatom_selected].name = name;
  vatom[iatom_selected].number = ElementSymbol::getAtomicNumber(name);

  return true;
}

bool DTAtoms::changeSelected( const Coordinates& coords )
{
  if( !isSelected() ) return false;

  vatom[iatom_selected].coords = Coordinates::normalize(coords);

  return true;
}

bool DTAtoms::deleteSelected( void )
{
  if( !isSelected() ) return false;

  vatom.erase( vatom.begin()+iatom_selected );
  unselect();

  return true;
}

bool DTAtoms::appendSelected( void )
{
  if( !isSelected() ) return false;

  DTAtom atom = vatom[iatom_selected];
  atom.coords.a += 0.1;
  vatom.push_back( atom );

  return true;
}
