/*
 Copyright (c) 2014 Shinji Tsuneyuki
 This file is distributed under the terms of the GNU General Public License version 3.
 */

/*!
 \file gloption.cc
 \brief GL�\���̑S�Ă̕\���w��
*/

#include "gloption.h"
#include "qtxml.h"
#include "symbol.h"
#include <QtGui/QColor>

GLOption::GLOption( void )
{
  loadDefaults();

  icolorname = 0;
  vcolorname.resize(ICOLORINDEX_LAST);
  vcolorname[ICOLORINDEX_WINDOW_BACKGROUND] = "background of 3d-viewer";
  vcolorname[ICOLORINDEX_WINDOW_FOREGROUND] = "foreground of 3d-viewer";
  vcolorname[ICOLORINDEX_LATTICE_CELL]      = "frame of cell";
}

GLOption::Window::Window( void )
{
  title      = "C-Tools 0.5.0";
  width      = 1024;
  height     = 512;
  background = GLcolor::black;
  foreground = GLcolor::white;
}

GLOption::Location::Location( void )
{
  world      = 128.0;

  eye      = Position( 0.0, 0.0, world );
  gaze     = Position( 0.0, 0.0, 0.0 );
  up       = Position( 0.0, 1.0, 0.0 );

  pangle   = 30.0;
  pnear    = world/8.0;
  pfar     = world*8.0;
}

GLOption::Light::Light( void )
{
  diffuse    = GLcolor( 0.8, 0.8, 0.8 );
  specular   = GLcolor( 1.0, 1.0, 1.0 );
  ambient    = GLcolor( 0.25, 0.25, 0.25 );
  shininess  = 128.0;
  direction_orig = Direction( 1.0, 1.0, 1.0, 0.0 );
  direction  = direction_orig;
  second_direction = Direction( -1.0, -1.0, -1.0, 0.0 );
  second = true;
  fog = false;
}

GLOption::Lattice::Lattice( void )
{
  show = true;

  atom.show      = true;
  atom.points    = false;
  atom.scale     = 0.25;
  atom.slices    = 16.0;
  atom.color_selected = GLcolor::yellow;

  atom.velement.resize(ElementSymbol::Lr+1);
  atom.velement[ElementSymbol::X ]=Atom::byElement(ElementSymbol::X, 0.75,GLcolor(0.00,0.00,0.00));
  atom.velement[ElementSymbol::H ]=Atom::byElement(ElementSymbol::H, 1.00,GLcolor(1.00,1.00,1.00));
  atom.velement[ElementSymbol::He]=Atom::byElement(ElementSymbol::He,1.00,GLcolor(1.00,0.75,0.80));
  atom.velement[ElementSymbol::Li]=Atom::byElement(ElementSymbol::Li,1.00,GLcolor(0.70,0.13,0.13));
  atom.velement[ElementSymbol::Be]=Atom::byElement(ElementSymbol::Be,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::B ]=Atom::byElement(ElementSymbol::B, 1.00,GLcolor(0.00,1.00,0.00));
  atom.velement[ElementSymbol::C ]=Atom::byElement(ElementSymbol::C, 1.00,GLcolor(0.78,0.78,0.78));
  atom.velement[ElementSymbol::N ]=Atom::byElement(ElementSymbol::N, 1.00,GLcolor(0.56,0.56,1.00));
  atom.velement[ElementSymbol::O ]=Atom::byElement(ElementSymbol::O, 1.00,GLcolor(0.94,0.00,0.00));
  atom.velement[ElementSymbol::F ]=Atom::byElement(ElementSymbol::F, 1.00,GLcolor(0.85,0.65,0.13));
  atom.velement[ElementSymbol::Ne]=Atom::byElement(ElementSymbol::Ne,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::Na]=Atom::byElement(ElementSymbol::Na,1.00,GLcolor(0.00,0.00,1.00));
  atom.velement[ElementSymbol::Mg]=Atom::byElement(ElementSymbol::Mg,1.00,GLcolor(0.13,0.55,0.13));
  atom.velement[ElementSymbol::Al]=Atom::byElement(ElementSymbol::Al,1.00,GLcolor(0.50,0.50,0.56));
  atom.velement[ElementSymbol::Si]=Atom::byElement(ElementSymbol::Si,1.00,GLcolor(0.85,0.65,0.13));
  atom.velement[ElementSymbol::P ]=Atom::byElement(ElementSymbol::P, 1.00,GLcolor(1.00,0.65,0.00));
  atom.velement[ElementSymbol::S ]=Atom::byElement(ElementSymbol::S, 1.00,GLcolor(1.00,0.78,0.20));
  atom.velement[ElementSymbol::Cl]=Atom::byElement(ElementSymbol::Cl,1.00,GLcolor(0.00,1.00,0.00));
  atom.velement[ElementSymbol::Ar]=Atom::byElement(ElementSymbol::Ar,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::K ]=Atom::byElement(ElementSymbol::K, 1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::Ca]=Atom::byElement(ElementSymbol::Ca,1.00,GLcolor(0.50,0.50,0.56));
  atom.velement[ElementSymbol::Sc]=Atom::byElement(ElementSymbol::Sc,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::Ti]=Atom::byElement(ElementSymbol::Ti,1.00,GLcolor(0.50,0.50,0.56));
  atom.velement[ElementSymbol::V ]=Atom::byElement(ElementSymbol::V, 1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::Cr]=Atom::byElement(ElementSymbol::Cr,1.00,GLcolor(0.50,0.50,0.56));
  atom.velement[ElementSymbol::Mn]=Atom::byElement(ElementSymbol::Mn,1.00,GLcolor(0.50,0.50,0.56));
  atom.velement[ElementSymbol::Fe]=Atom::byElement(ElementSymbol::Fe,1.00,GLcolor(1.00,0.65,0.00));
  atom.velement[ElementSymbol::Co]=Atom::byElement(ElementSymbol::Co,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::Ni]=Atom::byElement(ElementSymbol::Ni,1.00,GLcolor(0.65,0.16,0.16));
  atom.velement[ElementSymbol::Cu]=Atom::byElement(ElementSymbol::Cu,1.00,GLcolor(0.65,0.16,0.16));
  atom.velement[ElementSymbol::Zn]=Atom::byElement(ElementSymbol::Zn,1.00,GLcolor(0.65,0.16,0.16));
  atom.velement[ElementSymbol::Ga]=Atom::byElement(ElementSymbol::Ga,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::Ge]=Atom::byElement(ElementSymbol::Ge,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::As]=Atom::byElement(ElementSymbol::As,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::Se]=Atom::byElement(ElementSymbol::Se,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::Br]=Atom::byElement(ElementSymbol::Br,1.00,GLcolor(0.65,0.16,0.16));
  atom.velement[ElementSymbol::Kr]=Atom::byElement(ElementSymbol::Kr,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::Rb]=Atom::byElement(ElementSymbol::Rb,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::Sr]=Atom::byElement(ElementSymbol::Sr,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::Y ]=Atom::byElement(ElementSymbol::Y, 1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::Zr]=Atom::byElement(ElementSymbol::Zr,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::Nb]=Atom::byElement(ElementSymbol::Nb,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::Mo]=Atom::byElement(ElementSymbol::Mo,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::Tc]=Atom::byElement(ElementSymbol::Tc,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::Ru]=Atom::byElement(ElementSymbol::Ru,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::Rh]=Atom::byElement(ElementSymbol::Rh,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::Pd]=Atom::byElement(ElementSymbol::Pd,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::Ag]=Atom::byElement(ElementSymbol::Ag,1.00,GLcolor(0.50,0.50,0.56));
  atom.velement[ElementSymbol::Cd]=Atom::byElement(ElementSymbol::Cd,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::In]=Atom::byElement(ElementSymbol::In,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::Sn]=Atom::byElement(ElementSymbol::Sn,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::Sb]=Atom::byElement(ElementSymbol::Sb,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::Te]=Atom::byElement(ElementSymbol::Te,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::I ]=Atom::byElement(ElementSymbol::I, 1.00,GLcolor(0.63,0.13,0.94));
  atom.velement[ElementSymbol::Xe]=Atom::byElement(ElementSymbol::Xe,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::Cs]=Atom::byElement(ElementSymbol::Cs,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::Ba]=Atom::byElement(ElementSymbol::Ba,1.00,GLcolor(1.00,0.65,0.00));
  atom.velement[ElementSymbol::La]=Atom::byElement(ElementSymbol::La,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::Ce]=Atom::byElement(ElementSymbol::Ce,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::Pr]=Atom::byElement(ElementSymbol::Pr,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::Nd]=Atom::byElement(ElementSymbol::Nd,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::Pm]=Atom::byElement(ElementSymbol::Pm,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::Sm]=Atom::byElement(ElementSymbol::Sm,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::Eu]=Atom::byElement(ElementSymbol::Eu,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::Gd]=Atom::byElement(ElementSymbol::Gd,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::Tb]=Atom::byElement(ElementSymbol::Tb,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::Dy]=Atom::byElement(ElementSymbol::Dy,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::Ho]=Atom::byElement(ElementSymbol::Ho,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::Er]=Atom::byElement(ElementSymbol::Er,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::Tm]=Atom::byElement(ElementSymbol::Tm,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::Yb]=Atom::byElement(ElementSymbol::Yb,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::Lu]=Atom::byElement(ElementSymbol::Lu,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::Hf]=Atom::byElement(ElementSymbol::Hf,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::Ta]=Atom::byElement(ElementSymbol::Ta,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::W ]=Atom::byElement(ElementSymbol::W, 1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::Re]=Atom::byElement(ElementSymbol::Re,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::Os]=Atom::byElement(ElementSymbol::Os,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::Ir]=Atom::byElement(ElementSymbol::Ir,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::Pt]=Atom::byElement(ElementSymbol::Pt,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::Au]=Atom::byElement(ElementSymbol::Au,1.00,GLcolor(0.85,0.65,0.13));
  atom.velement[ElementSymbol::Hg]=Atom::byElement(ElementSymbol::Hg,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::Tl]=Atom::byElement(ElementSymbol::Tl,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::Pb]=Atom::byElement(ElementSymbol::Pb,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::Bi]=Atom::byElement(ElementSymbol::Bi,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::Po]=Atom::byElement(ElementSymbol::Po,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::At]=Atom::byElement(ElementSymbol::At,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::Rn]=Atom::byElement(ElementSymbol::Rn,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::Fr]=Atom::byElement(ElementSymbol::Fr,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::Ra]=Atom::byElement(ElementSymbol::Ra,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::Ac]=Atom::byElement(ElementSymbol::Ac,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::Th]=Atom::byElement(ElementSymbol::Th,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::Pa]=Atom::byElement(ElementSymbol::Pa,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::U ]=Atom::byElement(ElementSymbol::U, 1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::Np]=Atom::byElement(ElementSymbol::Np,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::Pu]=Atom::byElement(ElementSymbol::Pu,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::Am]=Atom::byElement(ElementSymbol::Am,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::Cm]=Atom::byElement(ElementSymbol::Cm,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::Bk]=Atom::byElement(ElementSymbol::Bk,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::Cf]=Atom::byElement(ElementSymbol::Cf,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::Es]=Atom::byElement(ElementSymbol::Es,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::Fm]=Atom::byElement(ElementSymbol::Fm,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::Md]=Atom::byElement(ElementSymbol::Md,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::No]=Atom::byElement(ElementSymbol::No,1.00,GLcolor(1.00,0.08,0.58));
  atom.velement[ElementSymbol::Lr]=Atom::byElement(ElementSymbol::Lr,1.00,GLcolor(1.00,0.08,0.58));
  atom.element_default            =Atom::byElement(ElementSymbol::X ,1.00, GLcolor::black );

  bond.show      = true;
  bond.lines     = false;
  bond.scale = 0.5/8;
  bond.slices = 8.0;

  bond.velement.push_back( Bond::byElement(ElementSymbol::H,ElementSymbol::H,1.50,GLcolor::white) );
  bond.velement.push_back( Bond::byElement(ElementSymbol::H,ElementSymbol::C,1.75,GLcolor::white) );
  bond.velement.push_back( Bond::byElement(ElementSymbol::C,ElementSymbol::C,2.00,GLcolor::white) );
  bond.element_default = ( Bond::byElement(ElementSymbol::X,ElementSymbol::X,2.00,GLcolor::white) );

  cell.show = true;
  cell.color = GLcolor::white;

  axis.show = true;
}

static bool loadColor( GLcolor& color, const QDomElement& node )
{
  GLcolor temp;
  char str[32];

  temp.A = 1.0; // default

  if( 3 <= XML::sscanf( XML::getAttribute(node,"color"),
		       "%lf %lf %lf %lf",
		       &temp.R, &temp.G, &temp.B, &temp.A ) ){
    color = temp;
    return true;
  }else if( 1 <= XML::sscanf( XML::getAttribute(node,"color"),
		       "%31s %lf",
		       str, &temp.A ) ){
    QColor qcolor;
    qcolor.setNamedColor( str );
    if( qcolor.isValid() ){
      color.R = qcolor.redF();
      color.G = qcolor.greenF();
      color.B = qcolor.blueF();
      color.A = temp.A;
      return true;
    }
    return false;
  }
  return false;
}

void GLOption::loadDefaults( void )
{
  QDomDocument doc;

  if( !XML::load( doc, "defaults.glml") ){
    return;
  }

  QDomNode root = XML::getRoot(doc);

  //---- <Window>
  {
    QDomElement group, node;

    group = XML::getFirstElementByTagName(root,"Window");

    node = XML::getFirstElementByTagName(group,"background");

    loadColor( window.background, node );
  }

  //---- <Lattice>
  {
    QDomElement group, node;
    vector<QDomElement> vnode;
    char name[8], name1[8], name2[8];
    double radius, length;
    GLcolor color;

    group = XML::getFirstElementByTagName(root,"Lattice");

    vnode = XML::getElementsByTagName(group,"atom");
    for( int i=0; i<(int)vnode.size(); i++ ){
      XML::sscanf( XML::getAttribute(vnode[i],"element"), "%s", name );
      XML::sscanf( XML::getAttribute(vnode[i],"radius"), "%lf", &radius );
      loadColor( color, vnode[i] );

      const int id = ElementSymbol::getAtomicNumber(name);
      Lattice::Atom::byElement& element = lattice.atom.element(id);

      if( element == lattice.atom.element_default ){
      }
      else{
	element = Lattice::Atom::byElement(id,radius,color);
      }
    }

    vnode = XML::getElementsByTagName(group,"bond");
    for( int i=0; i<(int)vnode.size(); i++ ){
      XML::sscanf( XML::getAttribute(vnode[i],"element1"), "%s", name1 );
      XML::sscanf( XML::getAttribute(vnode[i],"element2"), "%s", name2 );
      XML::sscanf( XML::getAttribute(vnode[i],"length"), "%lf", &length );
      loadColor( color, vnode[i] );

      const int id1 = ElementSymbol::getAtomicNumber(name1);
      const int id2 = ElementSymbol::getAtomicNumber(name2);
      Lattice::Bond::byElement& element = lattice.bond.element(id1,id2);

      if( element == lattice.bond.element_default ){
	lattice.bond.velement.push_back( Lattice::Bond::byElement(id1,id2,length,color) );
      }
      else{
	element = Lattice::Bond::byElement(id1,id2,length,color);
      }
    }

    node = XML::getFirstElementByTagName(group,"cell");
    loadColor( lattice.cell.color, node );
  }
}


GLcolor& GLOption::getColorTarget( void )
{
  switch( icolorname ){
  case ICOLORINDEX_WINDOW_BACKGROUND : return window.background;
  case ICOLORINDEX_WINDOW_FOREGROUND : return window.foreground;
  case ICOLORINDEX_LATTICE_CELL : return lattice.cell.color;
  }

  return window.background; // dummy
}

