/*
 Copyright (c) 2014 Shinji Tsuneyuki
 This file is distributed under the terms of the GNU General Public License version 3.
 */

#ifndef __DTATOM_H_INCLUDED
#define __DTATOM_H_INCLUDED

#include <QtCore/QString>

struct DTAtom
{
  QString name;
  double a, b, c;
};


#endif // __DTATOM_H_INCLUDED
