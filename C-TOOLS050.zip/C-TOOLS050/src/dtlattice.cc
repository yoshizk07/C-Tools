/*
 Copyright (c) 2014 Shinji Tsuneyuki
 This file is distributed under the terms of the GNU General Public License version 3.
 */

/*!
 \file dtlattice.cc
 \brief �i�q�f�[�^�̓����N���X
*/

#include "dtlattice.h"
#include <stdio.h>

const double AU_TO_AA = 0.529177210818; // a.u. length to angstrom
const double AA_TO_AU = 1.0/AU_TO_AA;


DTLattice::DTLattice( void )
{
  clear();
}

void DTLattice::clear( void )
{
  cell.clear();

  molecule.clear();
}

void DTLattice::update( void )
{
  cell.update();
  molecule.update();
}

double DTLattice::getScale( void ) const
{
  double scale=0.0;
  {
    for( int ika=-1;ika<=+1; ika+=2 ){
      for( int ikb=-1;ikb<=+1; ikb+=2 ){
	for( int ikc=-1;ikc<=+1; ikc+=2 ){
	  const Position L = 
	    +cell.La*double(ika)
	    +cell.Lb*double(ikb)
	    +cell.Lc*double(ikc);
	  const double length = Position::length(L);
	  if( scale < length ){
	    scale = length;
	  }
	}
      }
    }
  }

  return scale;
}

double DTLattice::getReciprocalScale( void ) const
{
  double Kscale=0.0;
  {
    for( int ika=-1;ika<=+1; ika+=2 ){
      for( int ikb=-1;ikb<=+1; ikb+=2 ){
	for( int ikc=-1;ikc<=+1; ikc+=2 ){
	  const Position L = 
	    +cell.Ka*double(ika)
	    +cell.Kb*double(ikb)
	    +cell.Kc*double(ikc);
	  const double length = Position::length(L);
	  if( Kscale < length ){
	    Kscale = length;
	  }
	}
      }
    }
  }
  return Kscale;
}
