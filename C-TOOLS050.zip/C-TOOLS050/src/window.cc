/*
 Copyright (c) 2014 Shinji Tsuneyuki
 This file is distributed under the terms of the GNU General Public License version 3.
 */

/*!
 \file window.cc
 \brief ���C���E�B���h�E�N���X
*/

#include <stdio.h>

#include <QtGui/QtGui>
#include <QtOpenGL/QtOpenGL>

#include "window.h"
#include "qtwidgets.h"
#include "qtmisc.h"

#include "qtfile.h"
#include "qtunitlattice.h"
#include "qtrecplattice.h"
#include "qtudf.h"

MainWindow::MainWindow( void ) : model()
{
  setWindowTitle( model.gloption.window.title );
  setMinimumSize( model.gloption.window.width, model.gloption.window.height );
  setSizePolicy( QSizePolicy::Expanding, QSizePolicy::Expanding );
  setFocusPolicy( Qt::ClickFocus );

  {
    QGroupBox* group = new QGroupBox;
    QHBoxLayout* box = new QHBoxLayout;

    {
      file = new QTFile( model );
      connect(file, SIGNAL(changed(const MyEvent&)), this, SLOT(editFile(const MyEvent&)) );
      box->addWidget(file);
      box->setAlignment(file,Qt::AlignTop);
    }

    // file menu
    tab = new QTabWidget;

    // unit lattice tab
    {
      unitlattice = new QTUnitLattice( model, ID_UNITLATTICE );
      tab->addTab(unitlattice, "Unit Lattice");
      connect(unitlattice, SIGNAL(changed(const MyEvent&)), this, SLOT(edit(const MyEvent&)) );
    }
    // recp lattice tab
    {
      recplattice = new QTRecpLattice( model, ID_RECPLATTICE );
      tab->addTab(recplattice, "Reciprocal Lattice");
      connect(recplattice, SIGNAL(changed(const MyEvent&)), this, SLOT(edit(const MyEvent&)) );
    }
    // UDF tab
    {
      udf = new QTUDF( model, ID_SOLVER );
      tab->addTab(udf, "UDF setup");
      connect(udf, SIGNAL(changed(const MyEvent&)), this, SLOT(edit(const MyEvent&)) );
    }

    box->addWidget(tab);
    group->setLayout(box);

    setCentralWidget(group);
  }

  connect( &model, SIGNAL(changed()), this,   SLOT(update()) );
  connect( this, SIGNAL(changed()), &model, SLOT(update()) );
}



void MainWindow::edit( const MyEvent& ev )
{
  switch(ev.id){
  case ID_UNITLATTICE : {
  } break;
  case ID_RECPLATTICE : {
  } break;
  case ID_SOLVER : {
  } break;

  default: break;
  }

  emit changed();
}

void MainWindow::editFile( const MyEvent& ev )
{
  switch(ev.id){
  case QTFile::ID_LOAD_MOLECULE : {
    tab->setCurrentIndex(ID_UNITLATTICE);
  } break;
  case QTFile::ID_LOAD_SOLVER : {
    tab->setCurrentIndex(ID_SOLVER);
  } break;

  default : break;
  }

  emit changed();
}


void MainWindow::update( void )
{
  file->update();
  unitlattice->update();
  recplattice->update();
  udf->update();
}

bool MainWindow::load( const QString& fname )
{
  return  file->load( fname );
}

bool MainWindow::load( const QString& format, const QString& fname )
{
  return  file->load( fname );
}

bool MainWindow::convert
( const QString& informat, const QString& infile,
  const QString& outformat, const QString& outfile )
{
  return model.convert
    ( informat, infile, outformat, outfile );
}
