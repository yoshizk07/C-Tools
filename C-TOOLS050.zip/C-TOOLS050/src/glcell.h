/*
 Copyright (c) 2014 Shinji Tsuneyuki
 This file is distributed under the terms of the GNU General Public License version 3.
 */

/*!
 \file glcell.h
 \brief �i�q�̒P�ʖE��GL�\���̃N���X
*/

#ifndef __GLCELL_H_INCLUDED
#define __GLCELL_H_INCLUDED

#include "glbase.h"

class DTModel;
class QGLWidget;

class GLCell : public GLBase
{
private:
  DTModel& model;
  QGLWidget* qglwidget;

public:
  GLCell( DTModel& _model,
	  QGLWidget* _qglwidget ) :
    model(_model), qglwidget(_qglwidget) {}

public:
  void draw( void );
  void update( void );
};

#endif // __GLCELL_H_INCLUDED
