/*
 Copyright (c) 2014 Shinji Tsuneyuki
 This file is distributed under the terms of the GNU General Public License version 3.
 */

/*!
 \file gloption.h
 \brief GL�\���̑S�Ă̕\���w��
*/

#ifndef __GLOPTION_H_INCLUDED
#define __GLOPTION_H_INCLUDED

#include <vector>
using namespace std;

#include <QtCore/QString>
#include "glmisc.h"
#include "position.h"

// �p�����^���Ǘ�����N���X
struct GLOption
{
  GLOption( void );

  struct Window {
    Window( void );

    QString title;
    int     width;
    int     height;
    GLcolor background;
    GLcolor foreground;
  } window;

  struct Location {
    Location( void );

    double   world;

    Position eye;
    Position gaze;
    Position up;

    double   pangle;
    double   pnear;
    double   pfar;
  } location;

  struct Light {
    struct Direction {
      GLdouble x,y,z,a;
      Direction(){}
      Direction( const GLdouble x, const GLdouble y, const GLdouble z, const GLdouble a ) {
	this->x = x;
	this->y = y;
	this->z = z;
	this->a = a;
      }
      operator GLdouble* () {
	return &x;
      }
    };
    Light( void );

    GLcolor  diffuse;
    GLcolor  specular;
    GLcolor  ambient;
    GLdouble shininess;
    Direction direction_orig;
    Direction direction;
    bool  second;
    Direction second_direction;
    bool  fog;
  } light;


  struct Lattice {
    Lattice( void );

    bool show;

    struct Atom {
      bool   show;
      bool   points;
      double scale;
      double slices;
      GLcolor color_selected;

      struct byElement {
	int     id;
	double  radius;
	GLcolor color;
	byElement( void ){
	  this->radius = 1.0;
	  this->color  = GLcolor::white;
	}
	byElement( const int id, const double radius, const GLcolor& color ){
	  this->id     = id;
	  this->radius = radius;
	  this->color  = color;
	}
	bool operator == ( const byElement& element ) const {
	  return this == &element;
	}
      };
      vector<byElement> velement;
      byElement element_default;
      byElement& element( const int id ){
	if( id < (int)velement.size() ){
	  return velement[id];
	}
	return element_default;
      }
    } atom;

    struct Bond {
      bool   show;
      bool   lines;
      double scale;
      double slices;

      struct byElement {
	int id1;
	int id2;
	double length;
	GLcolor color;
	byElement( void ){
	  this->id1 = 0;
	  this->id2 = 0;
	  this->length = 2.0;
	  this->color  = GLcolor::white;
	}
	byElement( const int id1, const int id2,
		   const double length, const GLcolor& color ){
	  this->id1    = id1;
	  this->id2    = id2;
	  this->length = length;
	  this->color  = color;
	}
	bool operator == ( const byElement& element ) const {
	  return this == &element;
	}
      };
      vector<byElement> velement;
      byElement element_default;
      byElement& element( const int id ){
	if( id < (int)velement.size() ){
	  return velement[id];
	}
	return element_default;
      }
      byElement& element( const int id1, const int id2 ){
	for( int b=0; b<(int)velement.size(); b++ ){
	  if( (velement[b].id1 == id1 && velement[b].id2 == id2 ) ||
	      (velement[b].id1 == id2 && velement[b].id2 == id1 ) ){
	    return velement[b];
	  }
	}
	return element_default;
      }
    } bond;

    struct Cell {
      bool show;
      GLcolor color;
      GLcolor color_selected;
    } cell;

    struct Axis {
      bool show;
    } axis;
  } lattice;

  vector<QString> vcolorname;
  int             icolorname;
  enum {
    ICOLORINDEX_WINDOW_BACKGROUND,
    ICOLORINDEX_WINDOW_FOREGROUND,
    ICOLORINDEX_LATTICE_CELL,
    ICOLORINDEX_LAST
  };
  GLcolor& getColorTarget( void );

  void loadDefaults( void );
};

#endif // __GLOPTION_H_INCLUDED
