/*
 Copyright (c) 2014 Shinji Tsuneyuki
 This file is distributed under the terms of the GNU General Public License version 3.
 */

/*!
 \file qtudf.h
 \brief UDF�̐ݒ��GUI�\���̃N���X
*/

#ifndef __QTUDF_H_INCLUDED
#define __QTUDF_H_INCLUDED

#include "qtwidgets.h"

class DTModel;

class QTUDF : public QWidget
{
  Q_OBJECT

private:
  DTModel& model;
  const int id;

  enum { 
    ID_TYPE,
    ID_ACCURACY,
    ID_SPIN,
    ID_KPOINT,
    ID_PARAM,
  };

  vector<MyQWidget*> vwidget;

public:
  QTUDF( DTModel& _model, const int id );
signals:
  void changed( const MyEvent& ev );
public slots:
  void update( void );
private slots:
  void edit( const MyEvent& ev );
};

#endif // __QTUDF_H_INCLUDED
