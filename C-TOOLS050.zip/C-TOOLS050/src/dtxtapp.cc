/*
 Copyright (c) 2014 Shinji Tsuneyuki
 This file is distributed under the terms of the GNU General Public License version 3.
 */

#include <stdio.h>
#include "dtlattice.h"
#include "dtxtapp.h"
#include "qtexception.h"
#include "namelist.h"
#include "symbol.h"
#include <algorithm>

// Fortran�̎w���`�� 1.0d2 ��C�̎w���`�� 1.0e2 �ɕϊ�����֐�
static bool change_exp_format( char* ptr )
{
  while( *ptr ){
    if( *ptr == 'd' ) *ptr = 'e';
    ptr++;
  }
  return true;
}


Table DTXTapp::TappInput::cutoff_wave_function_def( 6.0, 7.0, 9.0, 5.0, 10.0 );
Table DTXTapp::TappInput::xtrap_beta_def( 0.3, 0.2, 0.1, 0.1, 0.9 );
Table DTXTapp::TappInput::scf_number_iter_def( 30, 40, 60, 10, 100 );
Table DTXTapp::TappInput::scf_converge_def( 1.0e-8, 1.0e-10, 1.0e-12, 1.0e-15, 1.0e-6 );
Table DTXTapp::StructOpt::converge_force_def( 1.0e-2, 1.0e-3, 1.0e-4, 1.0e-5, 1.0e-1 );

void DTXTapp::clear( void )
{
  TappInput.lattice_factor = 1.0;
  TappInput.lattice_list[0] = Position(1.0,0.0,0.0);
  TappInput.lattice_list[1] = Position(0.0,1.0,0.0);
  TappInput.lattice_list[2] = Position(0.0,0.0,1.0);
  TappInput.number_spin = 1;

  TappInput.cutoff_wave_function = TappInput::cutoff_wave_function_def.getDefault("Normal");
  TappInput.xtrap_beta = TappInput::xtrap_beta_def.getDefault("Normal");
  TappInput.scf_number_iter = TappInput::scf_number_iter_def.getDefault("Normal");
  TappInput.scf_converge = TappInput::scf_converge_def.getDefault("Normal");
  StructOpt.converge_force = StructOpt::converge_force_def.getDefault("Normal");

  TappInput.number_band = 0;
  TappInput.chain_calc = 0;
  TappInput.xc_type = "'PBE'";
  Symmetry.number_sym_op = 1;
  Atom.atom.clear();
  SmplKpt.dos_mode = "'COS'";
  SmplKpt.dos_mesh[0] = SmplKpt.dos_mesh[1] = SmplKpt.dos_mesh[2] = 1;
  SmplKpt.nkmesh[0] = SmplKpt.nkmesh[1] = SmplKpt.nkmesh[2] = 1;
  SmplKpt.skmesh[0] = SmplKpt.skmesh[1] = SmplKpt.skmesh[2] = 1;

  StructOpt.number_cycle = 0;
  TraceBand.number_band_traced = 0;
}

QString DTXTapp::guess( const QString& fname )
{
  FILE* fptr = fopen(fname, "rb" );
  if( fptr == NULL ){
    return "";
  }

  char buf[256];
  char svalue[32];

  bool match = false;

  fgets(buf,sizeof(buf),fptr);
  fgets(buf,sizeof(buf),fptr);
  if( 1 == sscanf(buf," %s", svalue ) &&
      strcasecmp(svalue,"&tappinput")==0 ){
    match = true;
  }

  fclose(fptr);

  if( match ){
    return "solver xtapp format";
  }

  return "";
}

bool DTXTapp::load( const QString& fname )
{
  clear();

  NameListBuffer nlb(qPrintable(fname));

  try{
    if( !nlb.isValid() ){
      throw MyException("can not open a xTAPP file.",fname);
    }

    char name[1024], value[1024];
    int number_atom =  0;
    int number_element = 0;
    //    int number_valence = 0;

    if( nlb.readList("&tappinput","# main data") ){
      while( nlb.getVariable(name,value) ){
	if( false );
	else if( !strcasecmp(name,"lattice_factor") ){
	  if( 1 != sscanf(value,"%lf",&TappInput.lattice_factor) ){
	    throw MyException("broken lattice_factor.");
	  }
	}
	else if( !strcasecmp(name,"lattice_list") ){
	  if( 9 != sscanf(value,"%lf %lf %lf %lf %lf %lf %lf %lf %lf",
			  &TappInput.lattice_list[0].x,
			  &TappInput.lattice_list[0].y,
			  &TappInput.lattice_list[0].z,
			  &TappInput.lattice_list[1].x,
			  &TappInput.lattice_list[1].y,
			  &TappInput.lattice_list[1].z,
			  &TappInput.lattice_list[2].x,
			  &TappInput.lattice_list[2].y,
			  &TappInput.lattice_list[2].z ) ){
	    throw MyException("broken lattice_list.");
	  }
	}
	else if( !strcasecmp(name,"number_spin") ){
	  if( 1 != sscanf(value,"%d", &TappInput.number_spin ) ){
	    throw MyException("broken number_spin.");
	  }
	}
	else if( !strcasecmp(name,"cutoff_wave_function") ){
	  if( 1 != sscanf(value,"%lf", &TappInput.cutoff_wave_function ) ) {
	    throw MyException("broken cutoff_wave_function.");
	  }
	}
	else if( !strcasecmp(name,"xtrap_beta") ){
	  if( 1 != sscanf(value,"%lf", &TappInput.xtrap_beta ) ){
	    throw MyException("broken xtrap_beta.");
	  }
	}
	else if( !strcasecmp(name,"number_element") ){
	  if( 1 != sscanf(value,"%d", &number_element ) ) {
	    throw MyException("broken number_element.");
	  }
	}
	else if( !strcasecmp(name,"number_atom") ){
	  if( 1 != sscanf(value,"%d", &number_atom ) ){
	    throw MyException("broken number_atom.");
	  }
	}
	else if( !strcasecmp(name,"number_band") ){
	  if( 1 != sscanf(value,"%d", &TappInput.number_band ) ){
	    throw MyException("broken number_band.");
	  }
	}
	else if( !strcasecmp(name,"chain_calc") ){
	  if( 1 != sscanf(value,"%d", &TappInput.chain_calc ) ){
	    throw MyException("broken chain_calc.");
	  }
	}
	else if( !strcasecmp(name,"scf_converge") ){
	  if( 1 != sscanf(value,"%lf", &TappInput.scf_converge ) ){
	    throw MyException("broken scf_converge.");
	  }
	}
	else if( !strcasecmp(name,"scf_number_iter") ){
	  if( 1 != sscanf(value,"%d", &TappInput.scf_number_iter ) ){
	    throw MyException("broken scf_number_iter.");
	  }
	}
	else if( !strcasecmp(name,"xc_type") ){
	  TappInput.xc_type = value;
	}
      }
    }

    if( nlb.readList("&symmetry","# symmetry data") ){
      while( nlb.getVariable(name,value) ){
	if( false );
	else if( !strcasecmp(name,"number_sym_op") ){
	  if( 1 != sscanf(value,"%d", &Symmetry.number_sym_op ) ){
	    throw MyException("broken number_sym_op.");
	  }
	}
      }
    }

    if( nlb.readList("&atom","# atom data") ){
      char buf[1024];

      vector<QString> vname(number_element);
      vector<int>   vnumber(number_element);
      double z;
      for( int ie=0; ie<number_element; ie++ ){
	if( nlb.readExtra(buf) && change_exp_format(buf) &&
	    1 == sscanf( buf, "%*f %lf", &z ) ){
	  vname[ie] = ElementSymbol::getAtomicName( (int)z );
	  vnumber[ie] = ElementSymbol::getAtomicNumber(vname[ie]);
	}
	else{
	  throw MyException("broken element list.");
	}
      }

      Atom.atom.resize(number_atom);
 
      for( int ia=0,ie; ia<number_atom; ia++ ){
	if( nlb.readExtra(buf) && change_exp_format(buf) &&
	    4 == sscanf(buf, "%d %le %le %le",
			&ie,
			&Atom.atom[ia].coords.a,
			&Atom.atom[ia].coords.b,
			&Atom.atom[ia].coords.c ) ){
	  ie--;
	  if( ie<0 || number_element<=ie ){
	    throw MyException("broken element number.");
	  }
	  Atom.atom[ia].name = vname[ie];
	  Atom.atom[ia].number = vnumber[ie];
	}
	else{
	  throw MyException("broken atom list.");
	}
      }

      /*
      if( TappInput.number_band == 0 ){
	number_valence=0;
	for( int ia=0; ia<number_atom; ia++ ){
	  int number = ElementSymbol::getAtomicNumber(Atom.atom[ia].name);
	  double valence = ElementSymbol::getAtomicValence(number);

	  number_valence += (int)valence;
	}

	if( TappInput.number_spin == 1 ){
	  TappInput.number_band = number_valence/2 + number_atom/2;
	}
	else{
	  TappInput.number_band = number_valence + number_atom;
	}
      }
      */
    }

    if( nlb.readList("&smpl_kpt","# k-points data") ){
      int bz_number_tile = 0;
      int bz_mesh = 0;
      int mmm1[3];
      int mmm2[3];
      char buf[1024];

      while( nlb.getVariable(name,value) ){
	if( false );
	else if( !strcasecmp(name,"dos_mode") ){
	  SmplKpt.dos_mode = value;
	}
	else if( !strcasecmp(name,"dos_mesh") ){
	  if( 3 != sscanf(value,"%d %d %d",
			  &SmplKpt.dos_mesh[0],
			  &SmplKpt.dos_mesh[1],
			  &SmplKpt.dos_mesh[2] ) ){
	    MyException::critical("broken dos_mesh.");
	  }
	}
	else if( !strcasecmp(name,"bz_mesh") ){
	  if( 1 != sscanf(value,"%d", &bz_mesh ) ){
	    MyException::critical("broken bz_mesh.");
	  }
	}
	else if( !strcasecmp(name,"bz_number_tile") ){
	  if( 1 != sscanf(value,"%d", &bz_number_tile ) ){
	    MyException::critical("broken bz_number_tile.");
	  }
	}
      }

      if( bz_mesh>0 && bz_number_tile > 0 ){
	if( nlb.readExtra(buf) &&
	    3 == sscanf(buf, "%d %d %d", &mmm1[0], &mmm1[1], &mmm1[2] ) ){
	}
	else{
	  MyException::critical("broken mmm1.");
	}
	if( nlb.readExtra(buf) &&
	    3 == sscanf(buf, "%d %d %d", &mmm2[0], &mmm2[1], &mmm2[2] ) ){
	}
	else{
	  MyException::critical("broken mmm2.");
	}
      }
      for( int i=0; i<3; i++ ){
	SmplKpt.nkmesh[i] = 0;
	SmplKpt.skmesh[i] = 0;

	for( int m=-mmm1[i]; m<=+mmm1[i]; m+=mmm2[i] ){
	  if( 2*m<-bz_mesh || +bz_mesh<2*m ) continue;
	  SmplKpt.nkmesh[i]++;
	  if( m==0 ) SmplKpt.skmesh[i] = 1;
	}
      }
    }

    if( nlb.readList("&struct_opt","# struct_opt data") ){
      while( nlb.getVariable(name,value) ){
	if( false );
	else if( !strcasecmp(name,"converge_force") ){
	  if( 1 != sscanf(value,"%lf", &StructOpt.converge_force ) ){
	    throw MyException("broken converge_force.");
	  }
	}
	else if( !strcasecmp(name,"number_cycle") ){
	  if( 1 != sscanf(value,"%d", &StructOpt.number_cycle ) ){
	    throw MyException("broken number_cycle.");
	  }
	}
      }
    }

    if( nlb.readList("&trace_band","# trace band data") ){
      while( nlb.getVariable(name,value) ){
	if( false );
	else if( !strcasecmp(name,"number_band_traced") ){
	  if( 1 != sscanf(value,"%d", &TraceBand.number_band_traced ) ){
	    MyException::critical("broken number_band_traced.");
	  }
	}
      }
    }
  }
  catch( const MyException& e ){
    MyException::critical(e);
    return false;
  }

  return true;
}


static inline int GCD( int a, int b )
{
  int na, nb, nr;

  na = a;
  nb = b;

  while( nb>0 ){
    nr = na%nb;
    na = nb;
    nb = nr;
  }

  return na;
}

static inline int LCM( int a, int b )
{
  int g = GCD(a,b);
  return (a/g)*(b/g)*g;
}

static inline int LCM( int a, int b, int c )
{
  return LCM(LCM(a,b),c);
}

bool DTXTapp::save( const DTLattice& lattice, const QString& fname ) const
{
  FILE* fptr = fopen( fname, "w" );

  try{
    if( fptr == NULL ){
      throw MyException("can not create a xTAPP file.",fname);
    }

    vector<QString> vname;
    vector<int>     vnumber;
    for( int ia=0; ia<(int)Atom.atom.size(); ia++ ){
      const QString& name = Atom.atom[ia].name;
      if( std::find( vname.begin(), vname.end(), name ) == vname.end() ){
	vname.push_back(name);
	int number = ElementSymbol::getAtomicNumber(name);
	vnumber.push_back(number);
      }
    }

    int number_atom = (int)Atom.atom.size();
    int number_element = (int)vname.size();

    {
      fprintf(fptr, "# main data\n");
      fprintf(fptr, "&tappinput\n");

      fprintf(fptr,"  lattice_factor = %f\n", TappInput.lattice_factor );
      fprintf(fptr,"  lattice_list   = \n");
      fprintf(fptr,"    %+15.10f %+15.10f %+15.10f\n",
	      TappInput.lattice_list[0].x,
	      TappInput.lattice_list[0].y,
	      TappInput.lattice_list[0].z );
      fprintf(fptr,"    %+15.10f %+15.10f %+15.10f\n",
	      TappInput.lattice_list[1].x,
	      TappInput.lattice_list[1].y,
	      TappInput.lattice_list[1].z );
      fprintf(fptr,"    %+15.10f %+15.10f %+15.10f\n",
	      TappInput.lattice_list[2].x,
	      TappInput.lattice_list[2].y,
	      TappInput.lattice_list[2].z );

      fprintf(fptr,"  number_spin = %d\n", TappInput.number_spin );
      fprintf(fptr,"  cutoff_wave_function = %f\n", TappInput.cutoff_wave_function );
      fprintf(fptr,"  xtrap_beta = %f\n", TappInput.xtrap_beta );
      fprintf(fptr,"  number_element = %d\n", number_element );
      fprintf(fptr,"  number_atom = %d\n", number_atom );
      fprintf(fptr,"  number_band = %d\n", TappInput.number_band );
      fprintf(fptr,"  chain_calc = %d\n", TappInput.chain_calc );
      fprintf(fptr,"  scf_converge = %e\n", TappInput.scf_converge );
      fprintf(fptr,"  scf_number_iter = %d\n", TappInput.scf_number_iter );
      fprintf(fptr,"  xc_type = %s\n", qPrintable(TappInput.xc_type) );
      fprintf(fptr,"  control_uptime = 3600\n");
      fprintf(fptr,"  store_wfn = 1\n");
      fprintf(fptr,"/\n");
    }

    {
      fprintf(fptr, "# symmetry data\n");
      fprintf(fptr, "&symmetry\n");
      fprintf(fptr, "  symmetry_format = 'reciprocal'\n");
      fprintf(fptr, "  number_sym_op = %d\n", (int)Symmetry.vmatrix.size() );
      fprintf(fptr, "  has_inversion = %d\n", Symmetry.has_inversion ? 1 : 0 );
      fprintf(fptr, "  denom_trans = %d\n", Symmetry.denom_trans );
      fprintf(fptr, "  /\n");

      for( int n=0; n<(int)Symmetry.vmatrix.size(); n++ ){
	const IMatrix imatrix = Symmetry.vmatrix[n].getTransInverse();
	for( int i=0; i<3; i++ ){
	  for( int j=0; j<3; j++ ){
	    fprintf(fptr, " %2d", imatrix.M[j][i] );
	  }
	  fprintf(fptr,"  ");
	}
	fprintf(fptr," ");
	for( int i=0; i<3; i++ ){
	  fprintf(fptr, " %d", (Symmetry.vmatrix[n].T[i]*Symmetry.denom_trans).toInteger() );
	}
	fprintf(fptr, " ! %s\n", Symmetry.vmatrix[n].name() );
      }
    }

    {
      fprintf(fptr, "# atom data\n");
      for( int ie=0; ie<number_element; ie++ ){
	int number = vnumber[ie];
	fprintf(fptr, " %6.2f %6.2f\n", 
		ElementSymbol::getAtomicValence(number),
		(double)number );
      }
      for( int ia=0; ia<number_atom; ia++ ){
	int ie;
	for( ie=0; ie<number_element; ie++ ){
	  if( vname[ie] == Atom.atom[ia].name ){
	    break;
	  }
	}
	fprintf(fptr, " %d %15.10f %15.10f %15.10f # atom %2s\n",
		ie+1,
		Atom.atom[ia].coords.a,
		Atom.atom[ia].coords.b,
		Atom.atom[ia].coords.c,
		qPrintable(Atom.atom[ia].name) );
      }
    }

    {
      int bz_mesh =
	LCM( 2*SmplKpt.nkmesh[0],
	     2*SmplKpt.nkmesh[1],
	     2*SmplKpt.nkmesh[2] );

      int mmm1[3];
      int mmm2[3];
      for( int i=0; i<3; i++ ){
	if( SmplKpt.skmesh[i] == 1 ){
	  if( SmplKpt.nkmesh[i]%2 == 0 ){
	    mmm1[i] = SmplKpt.nkmesh[i]+0;
	  }
	  else{
	    mmm1[i] = SmplKpt.nkmesh[i]+1;
	  }
	}
	else{
	  if( SmplKpt.nkmesh[i]%2 == 0 ){
	    mmm1[i] = SmplKpt.nkmesh[i]+1;
	  }
	  else{
	    mmm1[i] = SmplKpt.nkmesh[i]+0;
	  }
	}
	mmm1[i] *= bz_mesh/(2*SmplKpt.nkmesh[i]);
	mmm2[i] = 2;
      }

      fprintf(fptr, "# k-points data\n");
      fprintf(fptr, "&smpl_kpt\n");
      fprintf(fptr, "  dos_mode = %s\n", qPrintable(SmplKpt.dos_mode) );
      fprintf(fptr, "  dos_mesh = %d %d %d\n",
	      SmplKpt.dos_mesh[0],
	      SmplKpt.dos_mesh[1],
	      SmplKpt.dos_mesh[2] );
      fprintf(fptr, "  bz_mesh = %d\n", bz_mesh );
      fprintf(fptr, "  bz_number_tile = 1\n");
      fprintf(fptr, "/\n");
      fprintf(fptr, "%d %d %d # mmm1 \n", mmm1[0], mmm1[1], mmm1[2] );
      fprintf(fptr, "%d %d %d # mmm2 \n", mmm2[0], mmm2[1], mmm2[2] );
    }

    {
      fprintf(fptr, "# struct_opt data\n");
      fprintf(fptr, "&struct_opt\n");
      fprintf(fptr, "  converge_force = %e\n", StructOpt.converge_force );
      fprintf(fptr, "  number_cycle = %d\n", StructOpt.number_cycle );
      fprintf(fptr, "/\n");
      fprintf(fptr, "# str_opt_constr data\n");
      fprintf(fptr, "1 # only unit matrix\n");
      fprintf(fptr, "0 # no atoms fixed\n");

    }

    {
      const vector<BrillouinSegment> vsymmL 
	= lattice.cell.vsymmL;

      Position last;
      int number_band_traced;
      int number_trace_block;

      number_band_traced = 0;
      for( int i=0; i<(int)vsymmL.size(); i++ ){
	const BrillouinSegment& symmL = vsymmL[i];

	if( i==0 ){
	  number_band_traced++;
	  number_band_traced++;
	}
	else{
	  if( last != symmL.positions ){
	    number_band_traced++;
	  }
	  number_band_traced++;
	}
	last = symmL.positione;
      }
      number_trace_block = number_band_traced-1;

      fprintf(fptr, "# trace band data\n");
      fprintf(fptr, "&trace_band\n");
      fprintf(fptr, "  number_band_traced = %d\n", number_band_traced );
      fprintf(fptr, "  number_trace_block = %d\n", number_trace_block );
      fprintf(fptr, "/\n");

      for( int i=0; i<(int)vsymmL.size(); i++ ){
	const BrillouinSegment& symmL = vsymmL[i];

	if( i==0 ){
	  fprintf(fptr, "%-5s ", qPrintable(("'"+symmL.labelPs+"'")) ); 
	  fprintf(fptr, "%-5s ", qPrintable(("'"+symmL.labelPe+"'")) ); 
	}
	else{
	  if( last != symmL.positions ){
	    fprintf(fptr, "%-5s ", qPrintable(("'"+symmL.labelPs+"'")) ); 
	  }
	  fprintf(fptr, "%-5s ", qPrintable(("'"+symmL.labelPe+"'")) ); 
	}
	last = symmL.positione;
      }
      if( !vsymmL.empty() ){
	fprintf(fptr, "# nkpt(1:nbk+1)\n");
      }

      for( int i=0; i<(int)vsymmL.size(); i++ ){
	const BrillouinSegment& symmL = vsymmL[i];

	if( i==0 ){
	  fprintf(fptr, "%5.3f ", symmL.positions.x ); 
	  fprintf(fptr, "%5.3f ", symmL.positione.x ); 
	}
	else{
	  if( last != symmL.positions ){
	    fprintf(fptr, "%5.3f ", symmL.positions.x ); 
	  }
	  fprintf(fptr, "%5.3f ", symmL.positione.x ); 
	}
	last = symmL.positione;
      }
      if( !vsymmL.empty() ){
	fprintf(fptr, "# ak(1,1:nbk+1)\n");
      }

      for( int i=0; i<(int)vsymmL.size(); i++ ){
	const BrillouinSegment& symmL = vsymmL[i];

	if( i==0 ){
	  fprintf(fptr, "%5.3f ", symmL.positions.y ); 
	  fprintf(fptr, "%5.3f ", symmL.positione.y ); 
	}
	else{
	  if( last != symmL.positions ){
	    fprintf(fptr, "%5.3f ", symmL.positions.y ); 
	  }
	  fprintf(fptr, "%5.3f ", symmL.positione.y ); 
	}
	last = symmL.positione;
      }
      if( !vsymmL.empty() ){
	fprintf(fptr, "# ak(2,1:nbk+1)\n");
      }

      for( int i=0; i<(int)vsymmL.size(); i++ ){
	const BrillouinSegment& symmL = vsymmL[i];

	if( i==0 ){
	  fprintf(fptr, "%5.3f ", symmL.positions.z ); 
	  fprintf(fptr, "%5.3f ", symmL.positione.z ); 
	}
	else{
	  if( last != symmL.positions ){
	    fprintf(fptr, "%5.3f ", symmL.positions.z ); 
	  }
	  fprintf(fptr, "%5.3f ", symmL.positione.z ); 
	}
	last = symmL.positione;
      }
      if( !vsymmL.empty() ){
	fprintf(fptr, "# ak(3,1:nbk+1)\n");
      }


      fprintf(fptr, "     ");
      for( int i=0; i<(int)vsymmL.size(); i++ ){
	const BrillouinSegment& symmL = vsymmL[i];

	if( i==0 ){
	  fprintf(fptr, "%-5d ", symmL.npoint ); 
	}
	else{
	  if( last != symmL.positions ){
	    fprintf(fptr, "%-5d ", 0 );
	  }
	  fprintf(fptr, "%-5d ", symmL.npoint );
	}
	last = symmL.positione;
      }
      if( !vsymmL.empty() ){
	fprintf(fptr, " # nkfi(1:nbk)\n");
      }

    }

    fclose(fptr);
  }
  catch( const MyException& e ){
    MyException::critical(e);
    if(fptr) fclose(fptr);
    return false;
  }
  return true;
}


static inline int nabs( const int n )
{
  return n<0 ? -n : n;
}

static bool match( const double matrixA[3][3], const double matrixB[3][3] )
{
  const double tolerance = 1.0e-5;
  double residue = 0.0;
  for( int i=0; i<3; i++ ){
    for( int j=0; j<3; j++ ){
      const double diff = matrixA[i][j] - matrixB[i][j];
      residue += diff*diff;
    }
  }
  return residue<tolerance*tolerance;
}

static bool match( const Coordinates& coordsA, const Coordinates& coordsB )
{
  const double tolerance = 1.0e-8;
  const double residue = Coordinates::normalize5(coordsA-coordsB).norm();
  return residue<tolerance*tolerance;
}

static bool checkChanged( const vector<DTAtom>& vatom, const Position latvec[3] )
{
  static vector<DTAtom> vatom_prev;
  static Position latvec_prev[3] = {
    Position(0.0,0.0,0.0),
    Position(0.0,0.0,0.0),
    Position(0.0,0.0,0.0)
  };
  bool status = false;

  if( latvec_prev[0] != latvec[0] ||
      latvec_prev[1] != latvec[1] ||
      latvec_prev[2] != latvec[2] ){
    status = true;
    goto end_block;
  }

  for( int ia=0; ia<(int)vatom.size(); ia++ ){
    if( ia>=(int)vatom_prev.size() ){
      status = true;
      goto end_block;
    }
    if( vatom_prev[ia].number != vatom[ia].number ||
	vatom_prev[ia].coords != vatom[ia].coords ){
      status = true;
      goto end_block;
    }
  }

end_block:
  vatom_prev = vatom;
  latvec_prev[0] = latvec[0];
  latvec_prev[1] = latvec[1];
  latvec_prev[2] = latvec[2];

  return status;
}

void DTXTapp::findSymmetry( void )
{
  Position latvec[3];
  vector<DTAtom>& vatom = Atom.atom;

  if( vatom.empty() ) return;

  double metric_original[3][3];
  double metric_rotated[3][3];

  latvec[0] = TappInput.lattice_list[0];
  latvec[1] = TappInput.lattice_list[1];
  latvec[2] = TappInput.lattice_list[2];

  // check lattice is not changed
  if( !checkChanged( vatom, latvec ) ) return;

  // check this lattice has_inversion symmetry.
  // move all atoms so that the inversion center locates at the origin
  {
    Symmetry.has_inversion = false;

    const int ia = 0;
    const Coordinates coords0_transformed = vatom[ia].coords*(-1.0);

    for( int ja=0; ja<(int)vatom.size(); ja++ ){
      if( vatom[ja].number != vatom[ia].number ) continue;
      const Coordinates difference =
	Coordinates::normalize5(vatom[ja].coords - coords0_transformed);

      bool is_acceptable = true;
      for( int ka=0; ka<(int)vatom.size(); ka++ ){
	const Coordinates coords_transformed = vatom[ka].coords*(-1.0) + difference;
	const int element_number_transformed = vatom[ka].number;

	bool is_match = false;
	for( int la=0; la<(int)vatom.size(); la++ ){
	  if( vatom[la].number != element_number_transformed ) continue;
	  if( match( vatom[la].coords, coords_transformed ) ){
	    is_match = true;
	    break;
	  }
	} // end for la
	if( !is_match ){
	  is_acceptable = false;
	  break;
	}
      } // end for ka

      if( is_acceptable ){
	// it has inversion symmetry
	/*
	const Coordinates translation = difference*(-0.5);
	if( translation != Coordinates( 0.0, 0.0, 0.0 ) &&
	    MyException::question( "Move atoms for symmetry?" ) ){
	  // translate all atoms so that the inversion center locates on the origin
	  for( int ka=0; ka<(int)vatom.size(); ka++ ){
	    vatom[ka].coords += translation;
	    Coordinates::normalize(vatom[ka].coords);
	  }
	  Symmetry.has_inversion = true;
	}
	*/
	const Coordinates translation = difference*(-0.5);
	if( translation == Coordinates( 0.0, 0.0, 0.0 ) ){
	  Symmetry.has_inversion = true;
	}
	break; // end of check
      }
    }
  } // end of check

  for( int i=0; i<3; i++ ){
    for( int j=0; j<3; j++ ){
      metric_original[i][j] = latvec[i] * latvec[j];
    }
  }

  IMatrix matrix;

  Symmetry.vmatrix.clear();
  matrix.initCanditate();
  do{
    if( nabs(matrix.determinant()) != 1 ){
      continue;
    }

    matrix.transformUnitary( metric_rotated, metric_original );

    if( !match( metric_rotated, metric_original ) ){
      continue;
    }

    const int ia = 0;
    const Coordinates coords0_transformed = matrix * vatom[ia].coords;

    for( int ja=0; ja<(int)vatom.size(); ja++ ){
      if( vatom[ja].number != vatom[ia].number ) continue;

      const Coordinates difference =
	Coordinates::normalize(vatom[ja].coords - coords0_transformed);

      matrix.T[0] = fraction(difference.a);
      matrix.T[1] = fraction(difference.b);
      matrix.T[2] = fraction(difference.c);
      if( !matrix.T[0].isvalid() ) continue;
      if( !matrix.T[1].isvalid() ) continue;
      if( !matrix.T[2].isvalid() ) continue;


      bool is_acceptable = true;

      for( int ka=0; ka<(int)vatom.size(); ka++ ){
	const Coordinates coords_transformed = matrix * vatom[ka].coords;
	const int element_number_transformed = vatom[ka].number;

	bool is_match = false;
	for( int la=0; la<(int)vatom.size(); la++ ){
	  if( vatom[la].number != element_number_transformed ) continue;
	  if( match( vatom[la].coords, coords_transformed ) ){
	    is_match = true;
	    break;
	  }
	} // end for la
	if( !is_match ){
	  is_acceptable = false;
	  break;
	}
      } // end for ka

      if( is_acceptable ){
	Symmetry.vmatrix.push_back(matrix);
      }
    } // end for ja
  }while( matrix.nextCanditate() );

  Symmetry.denom_trans=1;
  for( int n=0; n<(int)Symmetry.vmatrix.size(); n++ ){
    Symmetry.denom_trans = fraction::common_denominator
      ( Symmetry.denom_trans, Symmetry.vmatrix[n].T[0].denominator );
    Symmetry.denom_trans = fraction::common_denominator
      ( Symmetry.denom_trans, Symmetry.vmatrix[n].T[1].denominator );
    Symmetry.denom_trans = fraction::common_denominator
      ( Symmetry.denom_trans, Symmetry.vmatrix[n].T[2].denominator );
  }

  Symmetry.number_sym_op = Symmetry.vmatrix.size();

}
