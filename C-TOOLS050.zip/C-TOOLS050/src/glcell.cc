/*
 Copyright (c) 2014 Shinji Tsuneyuki
 This file is distributed under the terms of the GNU General Public License version 3.
 */

/*!
 \file glcell.cc
 \brief �i�q�̒P�ʖE��GL�\���̃N���X
*/

#include <QtOpenGL/QGLWidget>
#include "dtmodel.h"
#include "glcell.h"

void GLCell::update( void )
{
  const Position& La = model.lattice.cell.La;
  const Position& Lb = model.lattice.cell.Lb;
  const Position& Lc = model.lattice.cell.Lc;
  const Position& Lo = model.lattice.cell.Lo;

  GLcolor color = model.gloption.lattice.cell.color;

  GLBase::beginNewList();
  glDisable( GL_LIGHTING );

  glPushMatrix(); {
    double mat[4][4];
  
    mat[0][0] = La.x, mat[0][1] = La.y, mat[0][2] = La.z, mat[0][3] = 0.0;
    mat[1][0] = Lb.x, mat[1][1] = Lb.y, mat[1][2] = Lb.z, mat[1][3] = 0.0;
    mat[2][0] = Lc.x, mat[2][1] = Lc.y, mat[2][2] = Lc.z, mat[2][3] = 0.0;
    mat[3][0] = Lo.x, mat[3][1] = Lo.y, mat[3][2] = Lo.z, mat[3][3] = 1.0;
    glMultMatrixd((double*)mat);
  }

  glColor4dv( color );

  // �P�ʖE�̘g�̕\��
  {
    glBegin( GL_LINE_LOOP );
    glVertex3d( 0.0, 0.0, 0.0 );
    glVertex3d( 1.0, 0.0, 0.0 );
    glVertex3d( 1.0, 1.0, 0.0 );
    glVertex3d( 0.0, 1.0, 0.0 );
    glEnd();

    glBegin( GL_LINE_LOOP );
    glVertex3d( 0.0, 0.0, 1.0 );
    glVertex3d( 1.0, 0.0, 1.0 );
    glVertex3d( 1.0, 1.0, 1.0 );
    glVertex3d( 0.0, 1.0, 1.0 );
    glEnd();

    glBegin( GL_LINES );
    glVertex3d( 0.0, 0.0, 0.0 );
    glVertex3d( 0.0, 0.0, 1.0 );
    glVertex3d( 1.0, 0.0, 0.0 );
    glVertex3d( 1.0, 0.0, 1.0 );
    glVertex3d( 0.0, 1.0, 0.0 );
    glVertex3d( 0.0, 1.0, 1.0 );
    glVertex3d( 1.0, 1.0, 0.0 );
    glVertex3d( 1.0, 1.0, 1.0 );
    glEnd();
  }

  // ���_��ʂ���W���̕\��
  {
    const Coordinates origin = Coordinates(0.0,0.0,0.0);
    glBegin( GL_LINE_LOOP );
    glVertex3d( origin.a, 0.0, 0.0 );
    glVertex3d( origin.a, 1.0, 0.0 );
    glVertex3d( origin.a, 1.0, 1.0 );
    glVertex3d( origin.a, 0.0, 1.0 );
    glEnd();
    glBegin( GL_LINE_LOOP );
    glVertex3d( 0.0, origin.b, 0.0 );
    glVertex3d( 1.0, origin.b, 0.0 );
    glVertex3d( 1.0, origin.b, 1.0 );
    glVertex3d( 0.0, origin.b, 1.0 );
    glEnd();
    glBegin( GL_LINE_LOOP );
    glVertex3d( 0.0, 0.0, origin.c );
    glVertex3d( 1.0, 0.0, origin.c );
    glVertex3d( 1.0, 1.0, origin.c );
    glVertex3d( 0.0, 1.0, origin.c );
    glEnd();
    glBegin( GL_LINES );
    glVertex3d( 0.0, origin.b, origin.c );
    glVertex3d( 1.0, origin.b, origin.c );
    glVertex3d( origin.a, 0.0, origin.c );
    glVertex3d( origin.a, 1.0, origin.c );
    glVertex3d( origin.a, origin.b, 0.0 );
    glVertex3d( origin.a, origin.b, 1.0 );
    glEnd();
  }


  glPopMatrix();

  glEnable( GL_LIGHTING );

  // XYZ�̖���`��
  if( model.gloption.lattice.axis.show ){
    glPushMatrix();

    const double L = Position::length(La + Lb + Lc)*(1.0/8);
    glTranslated( Lo.x-L, Lo.y-L, Lo.z-L );

    const double   radius = L*(1.0/32);
    const Position O = Position( 0.0, 0.0, 0.0 );
    const Position X = Position(   L, 0.0, 0.0 );
    const Position Y = Position( 0.0,   L, 0.0 );
    const Position Z = Position( 0.0, 0.0,   L );

    glMaterialdv( GL_FRONT, GL_AMBIENT_AND_DIFFUSE, GLcolor::red );
    gluSolidStick( radius, O, X*0.75, 16 );
    gluSolidCone( radius*2.0, X*0.75, X, 16 );

    glMaterialdv( GL_FRONT, GL_AMBIENT_AND_DIFFUSE, GLcolor::green );
    gluSolidStick( radius, O, Y*0.75, 16 );
    gluSolidCone( radius*2.0, Y*0.75, Y, 16 );

    glMaterialdv( GL_FRONT, GL_AMBIENT_AND_DIFFUSE, GLcolor::blue );
    gluSolidStick( radius, O, Z*0.75, 16 );
    gluSolidCone( radius*2.0, Z*0.75, Z, 16 );

    glPopMatrix();
  }

  GLBase::endNewList();
}



void GLCell::draw( void )
{
  GLBase::draw();

  const Position& La = model.lattice.cell.La;
  const Position& Lb = model.lattice.cell.Lb;
  const Position& Lc = model.lattice.cell.Lc;
  const Position& Lo = model.lattice.cell.Lo;

  GLcolor color = model.gloption.lattice.cell.color;

  glDisable( GL_LIGHTING );

  glPushMatrix(); {
    double mat[4][4];
  
    mat[0][0] = La.x, mat[0][1] = La.y, mat[0][2] = La.z, mat[0][3] = 0.0;
    mat[1][0] = Lb.x, mat[1][1] = Lb.y, mat[1][2] = Lb.z, mat[1][3] = 0.0;
    mat[2][0] = Lc.x, mat[2][1] = Lc.y, mat[2][2] = Lc.z, mat[2][3] = 0.0;
    mat[3][0] = Lo.x, mat[3][1] = Lo.y, mat[3][2] = Lo.z, mat[3][3] = 1.0;
    glMultMatrixd((double*)mat);
  }

  glColor4dv( color );

  // �����\�����Ȃ��ꍇ�͎��̃��x����\������B
  {
    {
      const Coordinates coordA = Coordinates(0.5,-1.0/16,-1.0/16);
      qglwidget->renderText( coordA.x, coordA.y, coordA.z, QString("A"));
    }
    {
      const Coordinates coordB = Coordinates(-1.0/16,+0.5,-1.0/16);
      qglwidget->renderText( coordB.x, coordB.y, coordB.z, QString("B"));
    }
    {
      const Coordinates coordC = Coordinates(-1.0/16,-1.0/16,+0.5);
      qglwidget->renderText( coordC.x, coordC.y, coordC.z, QString("C"));
    }
    {
      const Coordinates coordO = Coordinates(-1.0/16,-1.0/16,-1.0/16);
      qglwidget->renderText( coordO.x, coordO.y, coordO.z, QString("O"));
    }
  }

  glPopMatrix();

  glEnable( GL_LIGHTING );

  // XYZ�̖���`��
  if( model.gloption.lattice.axis.show ){
    glPushMatrix();

    const double L = Position::length(La + Lb + Lc)*(1.0/8);
    glTranslated( Lo.x-L, Lo.y-L, Lo.z-L );

    //    const Position O = Position( 0.0, 0.0, 0.0 );
    const Position X = Position(   L, 0.0, 0.0 );
    const Position Y = Position( 0.0,   L, 0.0 );
    const Position Z = Position( 0.0, 0.0,   L );

    qglwidget->renderText( X.x, X.y, X.z, QString("X"));
    qglwidget->renderText( Y.x, Y.y, Y.z, QString("Y"));
    qglwidget->renderText( Z.x, Z.y, Z.z, QString("Z"));

    glPopMatrix();
  }
}
