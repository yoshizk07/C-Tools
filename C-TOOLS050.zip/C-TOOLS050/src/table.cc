/*
 Copyright (c) 2014 Shinji Tsuneyuki
 This file is distributed under the terms of the GNU General Public License version 3.
 */

#include <stdio.h>
#include <math.h>
#include "table.h"

Table::Table
( const double& vlow, const double& vnormal, const double& vhigh,
  const double& vmin, const double& vmax )
{
  value_min    = vmin;
  value_max    = vmax;
  (void)setTable(vlow,vnormal,vhigh);
}


bool Table::setTable
( const double& vlow, const double& vnormal, const double& vhigh )
{
  value_low    = vlow;
  value_normal = vnormal;
  value_high   = vhigh;

  if( value_low == value_normal ){
    fprintf(stderr,"Invalid table, low==normal.\n");
    return false;
  }
  if( value_normal == value_high ){
    fprintf(stderr,"Invalid table, normal==high.\n");
    return false;
  }
  if( value_low <= 0.0 ){
    fprintf(stderr,"Invalid table, low<=0.\n");
    return false;
  }
  if( value_normal <= 0.0 ){
    fprintf(stderr,"Invalid table, normal<=0.\n");
    return false;
  }
  if( value_high <= 0.0 ){
    fprintf(stderr,"Invalid table, high<=0.\n");
    return false;
  }

  if( value_min <= 0.0 ){
    fprintf(stderr,"Invalid table, min<=0.\n");
    return false;
  }
  if( value_max <= 0.0 ){
    fprintf(stderr,"Invalid table, max<=0.\n");
    return false;
  }
  if( value_min >= value_max ){
    fprintf(stderr,"Invalid table, min>=max.\n");
    return false;
  }

  lowsmaller  = value_low<value_high;
  log_value_low    = log(value_low);
  log_value_normal = log(value_normal);
  log_value_high   = log(value_high);

  exponential = fabs(log_value_high-log_value_low)/log(10.0)>=2.0-0.000001;
  return true;
}

double Table::getDefault( const QString& accuracy ) const
{
  if( false );
  else if( accuracy=="Low" ){
    return value_low;
  }
  else if( accuracy=="Normal" ){
    return value_normal;
  }
  else if( accuracy=="High" ){
    return value_high;
  }
  return value_normal;
}

QString Table::getAccuracy( const double v ) const
{
  const double d = getDegree( v );
  if( d < 1.5 ) return "Low";
  if( d < 2.5 ) return "Normal";
  return "High";
}

// below 1.0 means extra low
// 1.0 means low
// 2.0 means normal
// 3.0 means high
// above 3.0 means extra high
double Table::getDegree( const double v ) const
{
  double d;
  if( exponential ){ // exponential
    double log_v = log(v);
    if( lowsmaller ){ // low smaller
      if( false );
      else if( v<value_low ){
	d = 1.0+(log_v-log_value_low)
	  /(log_value_normal-log_value_low);
      }
      else if( v<value_normal ){
	d = 1.0+(log_v-log_value_low)
	  /(log_value_normal-log_value_low);
      }
      else if( v<value_high ){
	d = 2.0+(log_v-log_value_normal)
	  /(log_value_high-log_value_normal);
      }
      else{
	d = 3.0+(log_v-log_value_high)
	  /(log_value_high-log_value_normal);
      }
    }
    else{ // high smaller
      if( false );
      else if( v>value_low ){
	d = 1.0+(log_v-log_value_low)
	  /(log_value_normal-log_value_low);
      }
      else if( v>value_normal ){
	d = 1.0+(log_v-log_value_low)
	  /(log_value_normal-log_value_low);
      }
      else if( v>value_high ){
	d = 2.0+(log_v-log_value_normal)
	  /(log_value_high-log_value_normal);
      }
      else{
	d = 3.0+(log_v-log_value_high)
	  /(log_value_high-log_value_normal);
      }
    }
  }
  else{ // linear
    if( lowsmaller ){ // low smaller
      if( false );
      else if( v<value_low ){
	d = 1.0+double(v-value_low)/(value_normal-value_low);
      }
      else if( v<value_normal ){
	d = 1.0+double(v-value_low)/(value_normal-value_low);
      }
      else if( v<value_high ){
	d = 2.0+double(v-value_normal)/(value_high-value_normal);
      }
      else{
	d = 3.0+double(v-value_high)/(value_high-value_normal);
      }
    }
    else{ // high smaller
      if( false );
      else if( v>value_low ){
	d = 1.0+double(v-value_low)/(value_normal-value_low);
      }
      else if( v>value_normal ){
	d = 1.0+double(v-value_low)/(value_normal-value_low);
      }
      else if( v>value_high ){
	d = 2.0+double(v-value_normal)/(value_high-value_normal);
      }
      else{
	d = 3.0+double(v-value_high)/(value_high-value_normal);
      }
    }
  }
  return d;
}


double Table::getValue( const double d ) const
{
  double v;

  if( exponential ){ // exponential
    if( false );
    else if( d<1.0 ){
      v = log_value_low + (d-1.0)*(log_value_normal-log_value_low);
    }
    else if( d<2.0 ){
      v = log_value_low + (d-1.0)*(log_value_normal-log_value_low);
    }
    else if( d<3.0 ){
      v = log_value_normal + (d-2.0)*(log_value_high-log_value_normal);
    }
    else{
      v = log_value_high + (d-3.0)*(log_value_high-log_value_normal);
    }
    v = exp(v);
  }
  else{ // linear
    if( false );
    else if( d<1.0 ){
      v = value_low + (d-1.0)*(value_normal-value_low);
    }
    else if( d<2.0 ){
      v = value_low + (d-1.0)*(value_normal-value_low);
    }
    else if( d<3.0 ){
      v = value_normal + (d-2.0)*(value_high-value_normal);
    }
    else{
      v = value_high + (d-3.0)*(value_high-value_normal);
    }
  }
  if( v < value_min ) v = value_min;
  if( v > value_max ) v = value_max;
  return v;
}

void output( const QString& fname, const Table& tableS, const Table& tableU )
{
  FILE* fptr = fopen(qPrintable(fname),"wb");

  double v;

  if( tableS.lowsmaller ){
    v = tableS.value_min;
    fprintf(fptr,"%e %e # min\n", v, tableU.getValue(tableS.getDegree(v)) );
    v = tableS.value_low;
    fprintf(fptr,"%e %e # low\n", v, tableU.getValue(tableS.getDegree(v)) );
    v = tableS.value_normal;
    fprintf(fptr,"%e %e # normal\n", v, tableU.getValue(tableS.getDegree(v)) );
    v = tableS.value_high;
    fprintf(fptr,"%e %e # high\n", v, tableU.getValue(tableS.getDegree(v)) );
    v = tableS.value_max;
    fprintf(fptr,"%e %e # max\n", v, tableU.getValue(tableS.getDegree(v)) );
  }
  else{
    v = tableS.value_max;
    fprintf(fptr,"%e %e # max\n", v, tableU.getValue(tableS.getDegree(v)) );
    v = tableS.value_low;
    fprintf(fptr,"%e %e # low\n", v, tableU.getValue(tableS.getDegree(v)) );
    v = tableS.value_normal;
    fprintf(fptr,"%e %e # normal\n", v, tableU.getValue(tableS.getDegree(v)) );
    v = tableS.value_high;
    fprintf(fptr,"%e %e # high\n", v, tableU.getValue(tableS.getDegree(v)) );
    v = tableS.value_min;
    fprintf(fptr,"%e %e # min\n", v, tableU.getValue(tableS.getDegree(v)) );
  }

  /*
  const int N = 16;
  for( int n=0; n<=N; n++ ){
    double v;
    if( tableS.exponential ){
      v = exp(log(tableS.value_min) + (log(tableS.value_max)-log(tableS.value_min))/N*n);
    }
    else{
      v = tableS.value_min + (tableS.value_max-tableS.value_min)/N*n;
    }
    double d  = tableS.getDegree(v);
    double v2 = tableU.getValue(d);

    

    fprintf(fptr,"%e %f %e\n", v, d, v2 );
  }
  */

  fclose(fptr);
}
