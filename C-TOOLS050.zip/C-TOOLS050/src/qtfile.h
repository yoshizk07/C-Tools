/*
 Copyright (c) 2014 Shinji Tsuneyuki
 This file is distributed under the terms of the GNU General Public License version 3.
 */

/*!
 \file qtfile.h
 \brief �t�@�C�������GUI�\���̃N���X
*/

#ifndef __QTFILE_H_INCLUDED
#define __QTFILE_H_INCLUDED

#include "qtwidgets.h"

class DTModel;

class QTFile : public QWidget
{
  Q_OBJECT

private:
  DTModel& model;

  QString path;

public:
  enum { ID_CLEAR, ID_LOAD, ID_SAVE, ID_QUIT };
  enum { ID_LOAD_MOLECULE, ID_LOAD_SOLVER, ID_SAVE_SOLVER };

public:
  QTFile( DTModel& _model );
  bool load( const QString& fname );
  bool save( const QString& fname );

signals:
  void changed( const MyEvent& ev );
public slots:
  void update( void );
private slots:
  void edit( const MyEvent& ev );
};

#endif // __QTFILE_H_INCLUDED
