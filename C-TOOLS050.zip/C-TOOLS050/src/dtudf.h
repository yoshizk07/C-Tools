/*
 Copyright (c) 2014 Shinji Tsuneyuki
 This file is distributed under the terms of the GNU General Public License version 3.
 */

#ifndef __DTUDF_H_INCLUDED
#define __DTUDF_H_INCLUDED

#include <QtCore/QString>
#include "position.h"
#include "dtatoms.h"
#include "table.h"

#include <vector>
using namespace std;

class DTLattice;
class DTXTapp;
class DTVasp;
class DTOpenMX;
class DTRSDFT;

struct DTUDF
{
  struct Common_Parameters{
    struct Calculation_Settings{
      QString Calculation_Type;
      QString Continue;
      QString Accuracy;

      double  Cutoff_Wave_Function;
      static Table Cutoff_Wave_Function_def;
      double  Mixing_Factor;
      static Table Mixing_Factor_def;
      int     Electron_Max_Iteration;
      static Table Electron_Max_Iteration_def;
      double  Energy_Converge;
      static Table Energy_Converge_def;
      double  Force_Converge;
      static Table Force_Converge_def;

      int     Number_Band;
      QString Smearing;
      bool    Spin;
      QString XC_Type;
      bool    Symmetry;
      QString Pseudopotential;
      int     Ion_Max_Iteration;
    } Calculation_Settings;
    struct Structural_Parameters{
      double   Lattice_Constant;
      Position Lattice_Vector[3];
      vector<DTAtom> Atom;
    } Structural_Parameters;
    struct K_points{
      QString Sampling_k_mesh;
      int     nkmesh[3];
      int     Symmetric_k_points;
    } K_points;
  } Common_Parameters;

  DTUDF( void );

  bool isset( void );
  void clear( void );
  void update( void );
  void updateType( void );
  void updateAccuracy( void );
  void updateAtom( void );
  void updateKPoint( void );

  void setLattice( const DTLattice& lattice );
  void getLattice( DTLattice& lattice );

  QString guess( const QString& fname );
  bool load( const QString& fname );
  bool save( const QString& fname ) const;

  void convertTo( DTXTapp& xtapp ) const;
  void convertFrom( const DTXTapp& xtapp );

  void convertTo( DTVasp& vasp ) const;
  void convertFrom( const DTVasp& vasp );

  void convertTo( DTOpenMX& openmx ) const;
  void convertFrom( const DTOpenMX& openmx );

  void convertTo( DTRSDFT& rsdft ) const;
  void convertFrom( const DTRSDFT& rsdft );
};

#endif // __DTUDF_H_INCLUDED
