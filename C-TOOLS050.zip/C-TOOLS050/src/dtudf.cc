/*
 Copyright (c) 2014 Shinji Tsuneyuki
 This file is distributed under the terms of the GNU General Public License version 3.
 */

#include <stdio.h>
#include "dtlattice.h"
#include "dtudf.h"
#include "dtxtapp.h"
#include "dtvasp.h"
#include "dtopenmx.h"
#include "dtrsdft.h"
#include "qtxml.h"
#include "qtmisc.h"
#include "qtexception.h"
#include "symbol.h"

const double AU_TO_AA = 0.529177210818; // a.u. length to angstrom
const double AA_TO_AU = 1.0/AU_TO_AA;

static inline void truncate( double& v, const double v_min, const double v_max )
{
  if( v<v_min ){
    v=v_min;
    return;
  }
  if( v>v_max ){
    v=v_max;
    return;
  }
}

static inline void truncate( int& v, const int v_min, const int v_max )
{
  if( v<v_min ){
    v=v_min;
    return;
  }
  if( v>v_max ){
    v=v_max;
    return;
  }
}


Table DTUDF::Common_Parameters::Calculation_Settings::
Cutoff_Wave_Function_def( 36.0, 49.0, 81.0, 10.0, 200.0 );

Table DTUDF::Common_Parameters::Calculation_Settings::
Mixing_Factor_def( 0.3, 0.2, 0.1, 0.1, 0.9 );

Table DTUDF::Common_Parameters::Calculation_Settings::
Electron_Max_Iteration_def( 30, 40, 60, 10, 100 );

Table DTUDF::Common_Parameters::Calculation_Settings::
Energy_Converge_def( 1.0e-8, 1.0e-10, 1.0e-12, 1.0e-15, 1.0e-6 );

Table DTUDF::Common_Parameters::Calculation_Settings::
Force_Converge_def( 1.0e-2, 1.0e-3, 1.0e-4, 1.0e-5, 1.0e-1 );

DTUDF::DTUDF( void )
{
}

bool DTUDF::isset( void )
{
  return !Common_Parameters.Structural_Parameters.Atom.empty();
}

void DTUDF::clear( void )
{
  // <Calculation_Type>
  Common_Parameters.Calculation_Settings.Calculation_Type = "Energy";

  // <Continue>
  Common_Parameters.Calculation_Settings.Continue = "New";

  // <Accuracy>
  Common_Parameters.Calculation_Settings.Accuracy = "Normal";

  // <Spin>
  Common_Parameters.Calculation_Settings.Spin = false;

  // <Smearing>
  Common_Parameters.Calculation_Settings.Smearing = "Recommend";

  // <XC_Type>
  Common_Parameters.Calculation_Settings.XC_Type = "PBE";

  // <Symmetry>
  Common_Parameters.Calculation_Settings.Symmetry = true;

  // <Lattice_Constant>
  Common_Parameters.Structural_Parameters.Lattice_Constant = 1.0;//AA

  // <Lattice_Vector>
  Common_Parameters.Structural_Parameters.Lattice_Vector[0]
    = Position(1.0,0.0,0.0);
  Common_Parameters.Structural_Parameters.Lattice_Vector[1]
    = Position(0.0,1.0,0.0);
  Common_Parameters.Structural_Parameters.Lattice_Vector[2]
    = Position(0.0,0.0,1.0);

  // <Atom>
  Common_Parameters.Structural_Parameters.Atom.clear();

  Common_Parameters.Calculation_Settings.Number_Band = 0;

  updateType();
  updateAccuracy();
  updateAtom();
  updateKPoint();
}

void DTUDF::update( void )
{
}

// call if Calculation_Type is updated
void DTUDF::updateType( void )
{
  // <Ion_Max_Iteration>
  if( Common_Parameters.Calculation_Settings.Calculation_Type == "Optimize" ){
    Common_Parameters.Calculation_Settings.Ion_Max_Iteration = 100;
  }
  else{
    Common_Parameters.Calculation_Settings.Ion_Max_Iteration = 0;
  }
}

// call if Atom is updated and Number_Band is not given
void DTUDF::updateAtom( void )
{
  // <Number_Band>
  if( Common_Parameters.Calculation_Settings.Number_Band == 0 ){
    int number_atom = Common_Parameters.Structural_Parameters.Atom.size();
    int number_valence = 0;

    for( int ia=0; ia<number_atom; ia++ ){
      const QString& name = Common_Parameters.Structural_Parameters.Atom[ia].name;
      int number = ElementSymbol::getAtomicNumber(name);
      double valence = ElementSymbol::getAtomicValence(number);
      number_valence += (int)valence;
    }

    if( Common_Parameters.Calculation_Settings.Spin ){
      Common_Parameters.Calculation_Settings.Number_Band
	= number_valence + number_atom;
    }
    else{
      Common_Parameters.Calculation_Settings.Number_Band
	= (number_valence+1)/2 + (number_atom+1)/2;
    }
  }
}


// call if Accracy is updated
void DTUDF::updateAccuracy( void )
{
  const QString& Accuracy
    = Common_Parameters.Calculation_Settings.Accuracy;

  // <Cutoff_Wave_Function>
  Common_Parameters.Calculation_Settings.Cutoff_Wave_Function
    = Common_Parameters::Calculation_Settings::Cutoff_Wave_Function_def.getDefault(Accuracy);
  // <Energy_Converge>
  Common_Parameters.Calculation_Settings.Energy_Converge
    = Common_Parameters::Calculation_Settings::Energy_Converge_def.getDefault(Accuracy);
  // <Electron_Max_Iteration>
  Common_Parameters.Calculation_Settings.Electron_Max_Iteration
    = (int)Common_Parameters::Calculation_Settings::Electron_Max_Iteration_def.getDefault(Accuracy);
  // <Mixing_Factor>
  Common_Parameters.Calculation_Settings.Mixing_Factor
    = Common_Parameters::Calculation_Settings::Mixing_Factor_def.getDefault(Accuracy);
  // <Force_Converge>
  Common_Parameters.Calculation_Settings.Force_Converge
    = Common_Parameters::Calculation_Settings::Force_Converge_def.getDefault(Accuracy);

  // <Sampling_k_mesh>
  if( false );
  else if( Accuracy == "Low" ){
    Common_Parameters.K_points.Sampling_k_mesh = "Sparse";
  }
  else if( Accuracy == "Normal" ){
    Common_Parameters.K_points.Sampling_k_mesh = "Normal";
  }
  else if( Accuracy == "High" ){
    Common_Parameters.K_points.Sampling_k_mesh = "Dense";
  }

  // <Sampling_k_mesh>
  updateKPoint();
}


// call if Sampling_k_mesh is updated or Lattice_Constant is updated
void DTUDF::updateKPoint( void )
{
  const double A =
    Common_Parameters.Structural_Parameters.Lattice_Constant
    * Position::length(Common_Parameters.Structural_Parameters.Lattice_Vector[0]);
  const double B =
    Common_Parameters.Structural_Parameters.Lattice_Constant
    * Position::length(Common_Parameters.Structural_Parameters.Lattice_Vector[1]);
  const double C =
    Common_Parameters.Structural_Parameters.Lattice_Constant
    * Position::length(Common_Parameters.Structural_Parameters.Lattice_Vector[2]);

  if( false );
  else if( Common_Parameters.K_points.Sampling_k_mesh == "Sparse" ){
    Common_Parameters.K_points.nkmesh[0] = int(ceil(10.0/A));
    Common_Parameters.K_points.nkmesh[1] = int(ceil(10.0/B));
    Common_Parameters.K_points.nkmesh[2] = int(ceil(10.0/C));
    Common_Parameters.K_points.Symmetric_k_points = 25;
  }
  else if( Common_Parameters.K_points.Sampling_k_mesh == "Normal" ){
    Common_Parameters.K_points.nkmesh[0] = int(ceil(20.0/A));
    Common_Parameters.K_points.nkmesh[1] = int(ceil(20.0/B));
    Common_Parameters.K_points.nkmesh[2] = int(ceil(20.0/C));
    Common_Parameters.K_points.Symmetric_k_points = 50;
  }
  else if( Common_Parameters.K_points.Sampling_k_mesh == "Dense" ){
    Common_Parameters.K_points.nkmesh[0] = int(ceil(30.0/A));
    Common_Parameters.K_points.nkmesh[1] = int(ceil(30.0/B));
    Common_Parameters.K_points.nkmesh[2] = int(ceil(30.0/C));
    Common_Parameters.K_points.Symmetric_k_points = 100;
  }
}




void DTUDF::setLattice( const DTLattice& lattice )
{
  Common_Parameters.Structural_Parameters.Lattice_Constant
    = lattice.cell.length;
  Common_Parameters.Structural_Parameters.Lattice_Vector[0]
    = lattice.cell.Ea;
  Common_Parameters.Structural_Parameters.Lattice_Vector[1]
    = lattice.cell.Eb;
  Common_Parameters.Structural_Parameters.Lattice_Vector[2]
    = lattice.cell.Ec;

  Common_Parameters.Structural_Parameters.Atom
    = lattice.molecule.vatom;

  Common_Parameters.K_points.Symmetric_k_points
    = lattice.cell.nsymmK;

  updateAtom();
  updateKPoint();
}


void DTUDF::getLattice( DTLattice& lattice )
{
  lattice.cell.clear();

  lattice.cell.length
    = Common_Parameters.Structural_Parameters.Lattice_Constant;

  lattice.cell.Ea
    = Common_Parameters.Structural_Parameters.Lattice_Vector[0];
  lattice.cell.Eb
    = Common_Parameters.Structural_Parameters.Lattice_Vector[1];
  lattice.cell.Ec
    = Common_Parameters.Structural_Parameters.Lattice_Vector[2];

  lattice.molecule.vatom
    = Common_Parameters.Structural_Parameters.Atom;

  lattice.cell.nsampK[0] = Common_Parameters.K_points.nkmesh[0];
  lattice.cell.nsampK[1] = Common_Parameters.K_points.nkmesh[1];
  lattice.cell.nsampK[2] = Common_Parameters.K_points.nkmesh[2];
  lattice.cell.nsymmK = Common_Parameters.K_points.Symmetric_k_points;

  lattice.cell.update();
}

QString DTUDF::guess( const QString& fname )
{
  FILE* fptr = fopen(fname, "rb" );
  if( fptr == NULL ){
    return "";
  }

  char buf[256];
  char svalue[32];

  bool match = false;

  fgets(buf,sizeof(buf),fptr);
  fgets(buf,sizeof(buf),fptr);
  if( 1 == sscanf(buf," %s", svalue ) &&
      QString(svalue) == "<Unified_DFT_Format>" ){
    match = true;
  }

  fclose(fptr);

  if( match ){
    return "solver udf format";
  }

  return "";
}


bool DTUDF::load( const QString& fname )
{
  QDomDocument doc;

  clear();

  try{
    if( !XML::load( doc, fname ) ){
      throw MyException("can not open a UDF file.",fname);
    }

    QDomNode Unified_DFT_Format_node = XML::getRoot(doc);

    // <Common_Parameters>
    {
      QDomElement Common_Parameters_node =
	XML::getFirstElementByTagName(Unified_DFT_Format_node,"Common_Parameters");

      // <Calculation_Settings>
      {
	QDomElement Calculation_Settings_node =
	  XML::getFirstElementByTagName(Common_Parameters_node,"Calculation_Settings");

	// <Calculation_Type>
	{
	  QDomNode node = XML::getFirstElementByTagName(Calculation_Settings_node,"Calculation_Type");
	  if( 1 != XML::sscanf( XML::getChildValue(node), "%s",
				&Common_Parameters.Calculation_Settings.Calculation_Type ) ){
	    throw MyException("broken Calculation_Type",fname);
	  }
	  updateType();
	}
	// <Continue>
	{
	  QDomNode node = XML::getFirstElementByTagName(Calculation_Settings_node,"Continue");
	  if( 1 != XML::sscanf( XML::getChildValue(node), "%s",
				&Common_Parameters.Calculation_Settings.Continue ) ){
	    throw MyException("broken Continue",fname);
	  }
	}
	// <Accuracy>
	{
	  QDomNode node = XML::getFirstElementByTagName(Calculation_Settings_node,"Accuracy");
	  if( 1 != XML::sscanf( XML::getChildValue(node), "%s",
				&Common_Parameters.Calculation_Settings.Accuracy ) ){
	    throw MyException("broken Accuracy",fname);
	  }
	  updateAccuracy();
	}
	// <Energy_Converge>
	{
	  QDomNode node = XML::getFirstElementByTagName(Calculation_Settings_node,"Energy_Converge");
	  if( 1 != XML::sscanf( XML::getChildValue(node), "%lf",
				&Common_Parameters.Calculation_Settings.Energy_Converge ) ){
	    throw MyException("broken Energy_Converge",fname);
	  }
	}
	// <Electron_Max_Iteration>
	{
	  QDomNode node = XML::getFirstElementByTagName(Calculation_Settings_node,"Electron_Max_Iteration");
	  if( 1 != XML::sscanf( XML::getChildValue(node), "%d",
				&Common_Parameters.Calculation_Settings.Electron_Max_Iteration ) ){
	    throw MyException("broken Electron_Max_Iteration",fname);
	  }
	}
	// <Cutoff_Wave_Function>
	{
	  QDomNode node = XML::getFirstElementByTagName(Calculation_Settings_node,"Cutoff_Wave_Function");
	  if( 1 != XML::sscanf( XML::getChildValue(node), "%lf",
				&Common_Parameters.Calculation_Settings.Cutoff_Wave_Function )){
	    throw MyException("broken Cutoff_Wave_Function",fname);
	  }
	}
	// <Mixing_Factor>
	{
	  QDomNode node = XML::getFirstElementByTagName(Calculation_Settings_node,"Mixing_Factor");
	  if( 1 != XML::sscanf( XML::getChildValue(node), "%lf",
				&Common_Parameters.Calculation_Settings.Mixing_Factor ) ){
	    throw MyException("broken Mixing_Factor",fname);
	  }
	}
	// <Number_Band>
	{
	  QDomNode node = XML::getFirstElementByTagName(Calculation_Settings_node,"Number_Band");
	  if( 1 != XML::sscanf( XML::getChildValue(node), "%d",
				&Common_Parameters.Calculation_Settings.Number_Band ) ){
	    throw MyException("broken Number_Band",fname);
	  }
	}
	// <Smearing>
	{
	  QDomNode node = XML::getFirstElementByTagName(Calculation_Settings_node,"Smearing");
	  if( 1 != XML::sscanf( XML::getChildValue(node), "%s",
				&Common_Parameters.Calculation_Settings.Smearing ) ){
	    throw MyException("broken Smearing",fname);
	  }
	}
	// <Spin>
	{
	  QDomNode node = XML::getFirstElementByTagName(Calculation_Settings_node,"Spin");
	  if( 1 != XML::sscanf( XML::getChildValue(node), "%s",
				&Common_Parameters.Calculation_Settings.Spin ) ){
	    throw MyException("broken Spin",fname);
	  }
	}
	// <XC_Type>
	{
	  QDomNode node = XML::getFirstElementByTagName(Calculation_Settings_node,"XC_Type");
	  if( 1 != XML::sscanf( XML::getChildValue(node), "%s",
				&Common_Parameters.Calculation_Settings.XC_Type ) ){
	    throw MyException("broken XC_Type",fname);
	  }
	}
	// <Symmetry>
	{
	  QDomNode node = XML::getFirstElementByTagName(Calculation_Settings_node,"Symmetry");
	  if( 1 != XML::sscanf( XML::getChildValue(node), "%s",
				&Common_Parameters.Calculation_Settings.Symmetry ) ){
	    throw MyException("broken Symmetry",fname);
	  }
	}
	// <Ion_Max_Iteration>
	{
	  QDomNode node = XML::getFirstElementByTagName(Calculation_Settings_node,"Ion_Max_Iteration");
	  if( 1 != XML::sscanf( XML::getChildValue(node), "%d",
				&Common_Parameters.Calculation_Settings.Ion_Max_Iteration ) ){
	    throw MyException("broken Ion_Max_Iteration",fname);
	  }
	}
	// <Force_Converge>
	{
	  QDomNode node = XML::getFirstElementByTagName(Calculation_Settings_node,"Force_Converge");
	  if( 1 != XML::sscanf( XML::getChildValue(node), "%lf",
				&Common_Parameters.Calculation_Settings.Force_Converge ) ){
	    throw MyException("broken Force_Converge",fname);
	  }
	}
      } // </Calculation_Settings>


      // <Structural_Parameters>
      {
	QDomElement Structural_Parameters_node =
	  XML::getFirstElementByTagName(Common_Parameters_node,"Structural_Parameters");

	// <Lattice_Constant>
	{
	  QDomNode node = XML::getFirstElementByTagName(Structural_Parameters_node,"Lattice_Constant");
	  if( 1 != XML::sscanf( XML::getChildValue(node), "%lf",
				&Common_Parameters.Structural_Parameters.Lattice_Constant ) ){
	    throw MyException("broken Lattice_Constant",fname);
	  }
	}
	// <Lattice_Vector>
	{
	  vector<QDomElement> vnode = XML::getElementsByTagName(Structural_Parameters_node,"Lattice_Vector");
	  for( int i=0; i<(int)vnode.size(); i++ ){
	    if( 3 != XML::sscanf( XML::getChildValue(vnode[i]), "%lf %lf %lf",
				  &Common_Parameters.Structural_Parameters.Lattice_Vector[i].x,
				  &Common_Parameters.Structural_Parameters.Lattice_Vector[i].y,
				  &Common_Parameters.Structural_Parameters.Lattice_Vector[i].z ) ){
	      throw MyException("broken Lattice_Vector",fname);
	    }
	  }
	}
	// <Atom>
	{
	  vector<QDomElement> vnode = XML::getElementsByTagName(Structural_Parameters_node,"Atom");
	  Common_Parameters.Structural_Parameters.Atom.resize( vnode.size() );
	  for( int i=0; i<(int)vnode.size(); i++ ){
	    char name[4];
	    if( 4 != XML::sscanf( XML::getChildValue(vnode[i]), "%2s %lf %lf %lf",
				  name,
				  &Common_Parameters.Structural_Parameters.Atom[i].coords.a,
				  &Common_Parameters.Structural_Parameters.Atom[i].coords.b,
				  &Common_Parameters.Structural_Parameters.Atom[i].coords.c ) ){
	      throw MyException("broken Atom",fname);
	    }
	    int number = ElementSymbol::getAtomicNumber(name);
	    Common_Parameters.Structural_Parameters.Atom[i].name = name;
	    Common_Parameters.Structural_Parameters.Atom[i].number = number;
	  }
	}
      } // </Structural_Parameters>

      { // <K_points>
	QDomElement K_points_node =
	  XML::getFirstElementByTagName(Common_Parameters_node,"K_points");

	// <Sampling_k_mesh>
	{
	  QDomNode node = XML::getFirstElementByTagName(K_points_node,"Sampling_k_mesh");
	  if( 1 != XML::sscanf( XML::getChildValue(node), "%s",
				&Common_Parameters.K_points.Sampling_k_mesh ) ){
	    throw MyException("broken K_points",fname);
	  }
	}
      } // </K_points>
    } // </Common_Parameters>
  }
  catch( const MyException& e ){
    MyException::critical(e);
    return false;
  }


  //post process
  updateAtom();
  updateKPoint();

  return true;
}

bool DTUDF::save( const QString& fname ) const
{
  FILE* fptr = fopen(fname, "wb" );

  try{
    if( fptr == NULL ){
      throw MyException("can not create a UDF file.",fname);
    }

    fprintf(fptr,"<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");

    // <Unified_DFT_Format>
    fprintf(fptr,"<Unified_DFT_Format>\n");
    {
      // <Common_Parameters>
      fprintf(fptr,"  <Common_Parameters>\n");
      {
	// <Calculation_Settings>
	fprintf(fptr,"\n");
	fprintf(fptr,"    <Calculation_Settings>\n");
	{
	  fprintf(fptr,"      <Calculation_Type> %s </Calculation_Type>\n",
		  qPrintable(Common_Parameters.Calculation_Settings.Calculation_Type) );
	  fprintf(fptr,"      <Continue> %s </Continue>\n",
		  qPrintable(Common_Parameters.Calculation_Settings.Continue) );
	  fprintf(fptr,"      <Accuracy> %s </Accuracy>\n",
		  qPrintable(Common_Parameters.Calculation_Settings.Accuracy) );

	  fprintf(fptr,"      <Energy_Converge> %e </Energy_Converge>\n",
		  Common_Parameters.Calculation_Settings.Energy_Converge );
	  fprintf(fptr,"      <Electron_Max_Iteration> %d </Electron_Max_Iteration>\n",
		  Common_Parameters.Calculation_Settings.Electron_Max_Iteration );
	  fprintf(fptr,"      <Cutoff_Wave_Function> %f </Cutoff_Wave_Function>\n",
		  Common_Parameters.Calculation_Settings.Cutoff_Wave_Function );
	  fprintf(fptr,"      <Mixing_Factor> %f </Mixing_Factor>\n",
		  Common_Parameters.Calculation_Settings.Mixing_Factor );
	  fprintf(fptr,"      <Number_Band> %d </Number_Band>\n",
		  Common_Parameters.Calculation_Settings.Number_Band );
	  fprintf(fptr,"      <Smearing> %s </Smearing>\n",
		  qPrintable(Common_Parameters.Calculation_Settings.Smearing) );
	  fprintf(fptr,"      <Spin> %s </Spin>\n",
		  Common_Parameters.Calculation_Settings.Spin ? "on" : "off" );
	  fprintf(fptr,"      <XC_Type> %s </XC_Type>\n",
		  qPrintable(Common_Parameters.Calculation_Settings.XC_Type) );
	  fprintf(fptr,"      <Symmetry> %s </Symmetry>\n",
		  Common_Parameters.Calculation_Settings.Symmetry ? "on" : "off" );
	  fprintf(fptr,"      <Ion_Max_Iteration> %d </Ion_Max_Iteration>\n",
		  Common_Parameters.Calculation_Settings.Ion_Max_Iteration );
	  fprintf(fptr,"      <Force_Converge> %e </Force_Converge>\n",
		  Common_Parameters.Calculation_Settings.Force_Converge );
	}
	fprintf(fptr,"    </Calculation_Settings>\n");
	// </Calculation_Settings>
	fprintf(fptr,"\n");
	// <Structural_Parameters>
	fprintf(fptr,"    <Structural_Parameters>\n");
	{
	  fprintf(fptr,"      <Lattice_Constant>  %f </Lattice_Constant>\n",
		  Common_Parameters.Structural_Parameters.Lattice_Constant );
	  for( int i=0; i<3; i++ ){
	    fprintf(fptr,"      <Lattice_Vector> %+f %+f %+f </Lattice_Vector>\n",
		    Common_Parameters.Structural_Parameters.Lattice_Vector[i].x,
		    Common_Parameters.Structural_Parameters.Lattice_Vector[i].y,
		    Common_Parameters.Structural_Parameters.Lattice_Vector[i].z );
	  }
	  for( int i=0; i<(int)Common_Parameters.Structural_Parameters.Atom.size(); i++ ){
	    const char* name = qPrintable(Common_Parameters.Structural_Parameters.Atom[i].name);
	    fprintf(fptr,"      <Atom> %2s %f  %f  %f </Atom>\n",
		    name,
		    Common_Parameters.Structural_Parameters.Atom[i].coords.a,
		    Common_Parameters.Structural_Parameters.Atom[i].coords.b,
		    Common_Parameters.Structural_Parameters.Atom[i].coords.c );
	  }
	}
	fprintf(fptr,"    </Structural_Parameters>\n");
	// </Structural_Parameters>
	fprintf(fptr,"\n");
	// <K_points>
	fprintf(fptr,"    <K_points>\n");
	{
	  fprintf(fptr,"      <Sampling_k_mesh> %s </Sampling_k_mesh>\n",
		  qPrintable(Common_Parameters.K_points.Sampling_k_mesh) );
	}
	fprintf(fptr,"    </K_points>\n");
	// </K_points>
	fprintf(fptr,"\n");
      }
      fprintf(fptr,"  </Common_Parameters>\n");
      // </Common_Parameters>

    }      
    fprintf(fptr,"</Unified_DFT_Format>\n");
    // <Unified_DFT_Format>

    fclose(fptr);
  }
  catch( const MyException& e ){
    MyException::critical(e);
    return false;
  }

  return true;
}







void DTUDF::convertFrom( const DTXTapp& xtapp )
{
  clear();

  // <Calculation_Type>
  if( xtapp.StructOpt.number_cycle != 0 ){
    Common_Parameters.Calculation_Settings.Calculation_Type = "Optimize";    
  }
  else{
    if( xtapp.SmplKpt.dos_mesh[0] > 0 ){
      Common_Parameters.Calculation_Settings.Calculation_Type = "DOS";
    }
    else if( xtapp.TraceBand.number_band_traced > 0 ){
      Common_Parameters.Calculation_Settings.Calculation_Type = "Band";
    }
    else{
      Common_Parameters.Calculation_Settings.Calculation_Type = "Energy";    
    }
  }
  updateType();

  // <Continue>
  if( xtapp.TappInput.chain_calc == 0 ){
    Common_Parameters.Calculation_Settings.Continue = "New";
  }
  else{
    Common_Parameters.Calculation_Settings.Continue = "Restart";
  }

  // <Accuracy>
  Common_Parameters.Calculation_Settings.Accuracy
    = DTXTapp::TappInput::cutoff_wave_function_def.getAccuracy
    (xtapp.TappInput.cutoff_wave_function);
  updateAccuracy();

  double degree;

  // <Cutoff_Wave_Function>
  degree = DTXTapp::TappInput::cutoff_wave_function_def.getDegree
    (xtapp.TappInput.cutoff_wave_function);
  Common_Parameters.Calculation_Settings.Cutoff_Wave_Function
    = Common_Parameters::Calculation_Settings::Cutoff_Wave_Function_def.getValue(degree);

  // <Mixing_Factor>
  degree = DTXTapp::TappInput::xtrap_beta_def.getDegree
    (xtapp.TappInput.xtrap_beta);
  Common_Parameters.Calculation_Settings.Mixing_Factor
    = Common_Parameters::Calculation_Settings::Mixing_Factor_def.getValue(degree);

  // <Electron_Max_Iteration>
  degree = DTXTapp::TappInput::scf_number_iter_def.getDegree
    (xtapp.TappInput.scf_number_iter);
  Common_Parameters.Calculation_Settings.Electron_Max_Iteration
    = (int)Common_Parameters::Calculation_Settings::Electron_Max_Iteration_def.getValue(degree);

  // <Energy_Converge>
  degree = DTXTapp::TappInput::scf_converge_def.getDegree
    (xtapp.TappInput.scf_converge);
  Common_Parameters.Calculation_Settings.Energy_Converge
    = Common_Parameters::Calculation_Settings::Energy_Converge_def.getValue(degree);

  // <Force_Converge>
  degree = DTXTapp::StructOpt::converge_force_def.getDegree
    (xtapp.StructOpt.converge_force);
  Common_Parameters.Calculation_Settings.Force_Converge
    = Common_Parameters::Calculation_Settings::Force_Converge_def.getValue(degree);

  // <Spin>
  if( xtapp.TappInput.number_spin == 2 ){
    Common_Parameters.Calculation_Settings.Spin = true;
  }
  else{
    Common_Parameters.Calculation_Settings.Spin = false;
  }

  // <Number_Band>
  Common_Parameters.Calculation_Settings.Number_Band
    = xtapp.TappInput.number_band;

  // <Smearing>
  if( false );
  else if( xtapp.SmplKpt.dos_mode == "'COS'" ){
    Common_Parameters.Calculation_Settings.Smearing = "Recommend";
  }
  else if( xtapp.SmplKpt.dos_mode == "'METHEFESSEL_PAXTON'" ){
    Common_Parameters.Calculation_Settings.Smearing = "Methfessel-Paxton";
  }
  else if( xtapp.SmplKpt.dos_mode == "'FERMI'" ){
    Common_Parameters.Calculation_Settings.Smearing = "Fermi";
  }

  // <XC_Type>
  if( false );
  else if( xtapp.TappInput.xc_type == "'CAPZ'" ){
    Common_Parameters.Calculation_Settings.XC_Type = "LDA";
  }
  else if( xtapp.TappInput.xc_type == "'PBE'" ){
    Common_Parameters.Calculation_Settings.XC_Type = "PBE";
  }
  else if( xtapp.TappInput.xc_type == "'PBEsol'" ){
    Common_Parameters.Calculation_Settings.XC_Type = "PBEsol";
  }
  else if( xtapp.TappInput.xc_type == "'PW91'" ){
    Common_Parameters.Calculation_Settings.XC_Type = "PW91";
  }
  else if( xtapp.TappInput.xc_type == "'PBE0'" ){
    Common_Parameters.Calculation_Settings.XC_Type = "PBE0";
  }
  else if( xtapp.TappInput.xc_type == "'HF'" ){
    Common_Parameters.Calculation_Settings.XC_Type = "HF";
  }

  // <Symmetry>
  if( xtapp.Symmetry.number_sym_op > 1 ){
    Common_Parameters.Calculation_Settings.Symmetry = true;
  }
  else{
    Common_Parameters.Calculation_Settings.Symmetry = false;
  }

  // <Ion_Max_Iteration>
  Common_Parameters.Calculation_Settings.Ion_Max_Iteration
    = xtapp.StructOpt.number_cycle;

  // <Lattice_Constant>
  Common_Parameters.Structural_Parameters.Lattice_Constant
    = xtapp.TappInput.lattice_factor * AU_TO_AA;

  // <Lattice_Vector>
  Common_Parameters.Structural_Parameters.Lattice_Vector[0]
    = xtapp.TappInput.lattice_list[0];
  Common_Parameters.Structural_Parameters.Lattice_Vector[1]
    = xtapp.TappInput.lattice_list[1];
  Common_Parameters.Structural_Parameters.Lattice_Vector[2]
    = xtapp.TappInput.lattice_list[2];

  // <Atom>
  Common_Parameters.Structural_Parameters.Atom
    = xtapp.Atom.atom;

  // <Number_Band>
  updateAtom();


  // <Sampling_k_mesh>
  {
    const double A =
      Common_Parameters.Structural_Parameters.Lattice_Constant
      * Position::length(Common_Parameters.Structural_Parameters.Lattice_Vector[0]);

    if( false );
    else if( xtapp.SmplKpt.nkmesh[0] < int(15.0/A) ){
      Common_Parameters.K_points.Sampling_k_mesh = "Sparse";
    }
    else if( xtapp.SmplKpt.nkmesh[0] < int(25.0/A) ){
      Common_Parameters.K_points.Sampling_k_mesh = "Normal";
    }
    else{
      Common_Parameters.K_points.Sampling_k_mesh = "Dense";
    }
    updateKPoint();
  }
}


void DTUDF::convertTo( DTXTapp& xtapp ) const
{
  xtapp.clear();

  // <Calculation_Type>
  if( false );
  else if( Common_Parameters.Calculation_Settings.Calculation_Type
      == "Energy" ){
    xtapp.StructOpt.number_cycle = 0;
    xtapp.SmplKpt.dos_mesh[0] = 0;
    xtapp.TraceBand.number_band_traced = 0;
  }
  else if( Common_Parameters.Calculation_Settings.Calculation_Type
      == "Band" ){
    xtapp.StructOpt.number_cycle = 0;
    xtapp.SmplKpt.dos_mesh[0] = 0;
    xtapp.TraceBand.number_band_traced = 1;//add kpath after
  }
  else if( Common_Parameters.Calculation_Settings.Calculation_Type
      == "DOS" ){
    xtapp.StructOpt.number_cycle = 0;
    xtapp.SmplKpt.dos_mesh[0] = 1; // will be given just later
    xtapp.TraceBand.number_band_traced = 0;
  }
  else if( Common_Parameters.Calculation_Settings.Calculation_Type
      == "Optimize" ){
    xtapp.StructOpt.number_cycle = 1; // will be given just later
    xtapp.SmplKpt.dos_mesh[0] = 0;
    xtapp.TraceBand.number_band_traced = 0;
  }

  // <Continue>
  if( Common_Parameters.Calculation_Settings.Continue == "New" ){
    xtapp.TappInput.chain_calc = 0;
  }
  else{ // "Restart"
    xtapp.TappInput.chain_calc = 1;
  }

  double degree;

  // <Cutoff_Wave_Function>
  degree = Common_Parameters::Calculation_Settings::Cutoff_Wave_Function_def
    .getDegree(Common_Parameters.Calculation_Settings.Cutoff_Wave_Function);
  xtapp.TappInput.cutoff_wave_function =
    DTXTapp::TappInput::cutoff_wave_function_def.getValue(degree);

  // <Mixing_Factor>
  degree = Common_Parameters::Calculation_Settings::Mixing_Factor_def
    .getDegree(Common_Parameters.Calculation_Settings.Mixing_Factor);
  xtapp.TappInput.xtrap_beta =
    DTXTapp::TappInput::xtrap_beta_def.getValue(degree);

  // <Electron_Max_Iteration>
  degree = Common_Parameters::Calculation_Settings::Electron_Max_Iteration_def
    .getDegree(Common_Parameters.Calculation_Settings.Electron_Max_Iteration);
  xtapp.TappInput.scf_number_iter =
    (int)DTXTapp::TappInput::scf_number_iter_def.getValue(degree);

  // <Energy_Converge>
  degree = Common_Parameters::Calculation_Settings::Energy_Converge_def
    .getDegree(Common_Parameters.Calculation_Settings.Energy_Converge);
  xtapp.TappInput.scf_converge =
    DTXTapp::TappInput::scf_converge_def.getValue(degree);

  // <Force_Converge>
  degree = Common_Parameters::Calculation_Settings::Force_Converge_def
    .getDegree(Common_Parameters.Calculation_Settings.Force_Converge);
  xtapp.StructOpt.converge_force =
    DTXTapp::StructOpt::converge_force_def.getValue(degree);

  // <Spin>
  if( Common_Parameters.Calculation_Settings.Spin ){
    xtapp.TappInput.number_spin = 2;
  }
  else{
    xtapp.TappInput.number_spin = 1;
  }


  // <Number_Band>
  xtapp.TappInput.number_band =
    Common_Parameters.Calculation_Settings.Number_Band;

  // <Smearing>
  if( false );
  else if( Common_Parameters.Calculation_Settings.Smearing == "Recommend" ){
    xtapp.SmplKpt.dos_mode = "'COS'";
  }
  else if( Common_Parameters.Calculation_Settings.Smearing == "Methfessel-Paxton" ){
    xtapp.SmplKpt.dos_mode = "'METHEFESSEL_PAXTON'";
  }
  else if( Common_Parameters.Calculation_Settings.Smearing == "Fermi" ){
    xtapp.SmplKpt.dos_mode = "'FERMI'";
  }

  // <XC_Type>
  if( false );
  else if( Common_Parameters.Calculation_Settings.XC_Type == "LDA" ){
    xtapp.TappInput.xc_type = "'CAPZ'";
  }
  else if( Common_Parameters.Calculation_Settings.XC_Type == "PBE" ){
    xtapp.TappInput.xc_type = "'PBE'";
  }
  else if( Common_Parameters.Calculation_Settings.XC_Type == "PBEsol" ){
    xtapp.TappInput.xc_type = "'PBEsol'";
  }
  else if( Common_Parameters.Calculation_Settings.XC_Type == "PW91" ){
    xtapp.TappInput.xc_type = "'PW91'";
  }
  else if( Common_Parameters.Calculation_Settings.XC_Type == "PBE0" ){
    xtapp.TappInput.xc_type = "'PBE0'";
  }
  else if( Common_Parameters.Calculation_Settings.XC_Type == "HF" ){
    xtapp.TappInput.xc_type = "'HF'";
  }

  // <Ion_Max_Iteration>
  if( Common_Parameters.Calculation_Settings.Calculation_Type
      == "Optimize" ){
    if( Common_Parameters.Calculation_Settings.Ion_Max_Iteration == 0){
      xtapp.StructOpt.number_cycle = 3*Common_Parameters.Structural_Parameters.Atom.size();
    }
    else{
      xtapp.StructOpt.number_cycle =
	Common_Parameters.Calculation_Settings.Ion_Max_Iteration;
    }
  }
  else{
    xtapp.StructOpt.number_cycle = 0;
  }

  // <Lattice_Constant>
  xtapp.TappInput.lattice_factor
    = Common_Parameters.Structural_Parameters.Lattice_Constant * AA_TO_AU;

  // <Lattice_Vector>
  xtapp.TappInput.lattice_list[0]
    = Common_Parameters.Structural_Parameters.Lattice_Vector[0];

  xtapp.TappInput.lattice_list[1]
    = Common_Parameters.Structural_Parameters.Lattice_Vector[1];

  xtapp.TappInput.lattice_list[2]
    = Common_Parameters.Structural_Parameters.Lattice_Vector[2];

  // <Atom>
  xtapp.Atom.atom
    = Common_Parameters.Structural_Parameters.Atom;

  // <Symmetry>
  xtapp.findSymmetry();


  // <Sampling_k_mesh>
  {
    xtapp.SmplKpt.nkmesh[0] = Common_Parameters.K_points.nkmesh[0];
    xtapp.SmplKpt.nkmesh[1] = Common_Parameters.K_points.nkmesh[1];
    xtapp.SmplKpt.nkmesh[2] = Common_Parameters.K_points.nkmesh[2];
    xtapp.SmplKpt.skmesh[0] = 1;
    xtapp.SmplKpt.skmesh[1] = 1;
    xtapp.SmplKpt.skmesh[2] = 1;

    if( Common_Parameters.Calculation_Settings.Calculation_Type
      == "DOS" ){
      xtapp.SmplKpt.dos_mesh[0] = xtapp.SmplKpt.nkmesh[0]*2;
      xtapp.SmplKpt.dos_mesh[1] = xtapp.SmplKpt.nkmesh[1]*2;
      xtapp.SmplKpt.dos_mesh[2] = xtapp.SmplKpt.nkmesh[2]*2;
    }
    else{
      xtapp.SmplKpt.dos_mesh[0] = 0;
      xtapp.SmplKpt.dos_mesh[1] = 0;
      xtapp.SmplKpt.dos_mesh[2] = 0;
    }
  }
}


void DTUDF::convertFrom( const DTVasp& vasp )
{
  clear();

  // <Calculation_Type>
  if( vasp.INCAR.NSW != 0 ){
    Common_Parameters.Calculation_Settings.Calculation_Type = "Optimize";    
  }
  else{
    if( vasp.INCAR.ICHARG < 10 ){
      Common_Parameters.Calculation_Settings.Calculation_Type = "Energy";    
    }
    else{
      if( vasp.KPOINT.number_band_traced > 0 ){
	Common_Parameters.Calculation_Settings.Calculation_Type = "Band";
      }
      else{
	Common_Parameters.Calculation_Settings.Calculation_Type = "DOS";
      }
    }
  }
  updateType();

  // <Continue>
  if( vasp.INCAR.ISTART == 0 ){
    Common_Parameters.Calculation_Settings.Continue = "New";
  }
  else{
    Common_Parameters.Calculation_Settings.Continue = "Restart";
  }

  // <Accuracy>
  if( false );
  else if( vasp.INCAR.PREC == "Single" ){
    Common_Parameters.Calculation_Settings.Accuracy = "Low";
  }
  else if( vasp.INCAR.PREC == "Normal" ){
    Common_Parameters.Calculation_Settings.Accuracy = "Normal";
  }
  else if( vasp.INCAR.PREC == "High" ){
    Common_Parameters.Calculation_Settings.Accuracy = "High";
  }
  updateAccuracy();

  double degree;

  // <Cutoff_Wave_Function>
  // nothing to do

  // <Mixing_Factor>
  degree = DTVasp::INCAR::AMIX_def.getDegree
    (vasp.INCAR.AMIX);
  Common_Parameters.Calculation_Settings.Mixing_Factor
    = Common_Parameters::Calculation_Settings::Mixing_Factor_def.getValue(degree);

  // <Electron_Max_Iteration>
  degree = DTVasp::INCAR::NELM_def.getDegree
    (vasp.INCAR.NELM);
  Common_Parameters.Calculation_Settings.Electron_Max_Iteration
    = (int)Common_Parameters::Calculation_Settings::Electron_Max_Iteration_def.getValue(degree);

  // <Energy_Converge>
  degree = DTVasp::INCAR::EDIFF_def.getDegree
    (vasp.INCAR.EDIFF);
  Common_Parameters.Calculation_Settings.Energy_Converge
    = Common_Parameters::Calculation_Settings::Energy_Converge_def.getValue(degree);

  // <Force_Converge>
  degree = DTVasp::INCAR::EDIFFG_def.getDegree
    (vasp.INCAR.EDIFFG);
  Common_Parameters.Calculation_Settings.Force_Converge
    = Common_Parameters::Calculation_Settings::Force_Converge_def.getValue(degree);

  // <Number_Band>
  Common_Parameters.Calculation_Settings.Number_Band = 0;

  // <Smearing>
  if( false );
  else if( vasp.INCAR.ISMEAR == -5 ){
    Common_Parameters.Calculation_Settings.Smearing = "Recommend";
  }
  else if( vasp.INCAR.ISMEAR ==  0 ){
    Common_Parameters.Calculation_Settings.Smearing = "Recommend";
  }
  else if( vasp.INCAR.ISMEAR == +1 ){
    Common_Parameters.Calculation_Settings.Smearing = "Methfessel-Paxton";
  }
  else if( vasp.INCAR.ISMEAR == -1 ){
    Common_Parameters.Calculation_Settings.Smearing = "Fermi";
  }


  // <Spin>
  if( vasp.INCAR.ISPIN == 2 ){
    Common_Parameters.Calculation_Settings.Spin = true;
  }
  else{
    Common_Parameters.Calculation_Settings.Spin = false;
  }

  // <XC_Type>
  if( false );
  else if( vasp.INCAR.GGA == "None" ){
    Common_Parameters.Calculation_Settings.XC_Type = "LDA";
  }
  else if( vasp.INCAR.GGA == "PE" && !vasp.INCAR.LHFCAL ){
    Common_Parameters.Calculation_Settings.XC_Type = "PBE";
  }
  else if( vasp.INCAR.GGA == "PS" ){
    Common_Parameters.Calculation_Settings.XC_Type = "PBEsol";
  }
  else if( vasp.INCAR.GGA == "91" ){
    Common_Parameters.Calculation_Settings.XC_Type = "PW91";
  }
  else if( vasp.INCAR.GGA == "PE" && vasp.INCAR.LHFCAL ){
    Common_Parameters.Calculation_Settings.XC_Type = "PBE0";
  }
  else if( vasp.INCAR.GGA == "None" && vasp.INCAR.LHFCAL ){
    Common_Parameters.Calculation_Settings.XC_Type = "HF";
  }


  // <Symmetry>
  if( vasp.INCAR.ISYM == 2 || vasp.INCAR.ISYM == 1 ){
    Common_Parameters.Calculation_Settings.Symmetry = true;
  }
  else{
    Common_Parameters.Calculation_Settings.Symmetry = false;
  }

  // <Ion_Max_Iteration>
  Common_Parameters.Calculation_Settings.Ion_Max_Iteration
    = vasp.INCAR.NSW;

  // <Lattice_Constant>
  Common_Parameters.Structural_Parameters.Lattice_Constant
    = vasp.POSCAR.lattice_factor;

  // <Lattice_Vector>
  Common_Parameters.Structural_Parameters.Lattice_Vector[0]
    = vasp.POSCAR.lattice_list[0];
  Common_Parameters.Structural_Parameters.Lattice_Vector[1]
    = vasp.POSCAR.lattice_list[1];
  Common_Parameters.Structural_Parameters.Lattice_Vector[2]
    = vasp.POSCAR.lattice_list[2];

  // <Atom>
  Common_Parameters.Structural_Parameters.Atom
    = vasp.POSCAR.atom;

  updateAtom();


  // <Sampling_k_mesh>
  {
    const double A =
      Common_Parameters.Structural_Parameters.Lattice_Constant
      * Position::length(Common_Parameters.Structural_Parameters.Lattice_Vector[0]);

    // energy and optimize
    if( vasp.INCAR.ICHARG == 0 && vasp.KPOINT.number_band_traced == 0 ){
      if( false );
      else if( vasp.KPOINT.nkmesh[0] < int(15.0/A) ){
	Common_Parameters.K_points.Sampling_k_mesh = "Sparse";
      }
      else if( vasp.KPOINT.nkmesh[0] < int(25.0/A) ){
	Common_Parameters.K_points.Sampling_k_mesh = "Normal";
      }
      else{
	Common_Parameters.K_points.Sampling_k_mesh = "Dense";
      }
    }
    // dos
    if( vasp.INCAR.ICHARG == 11 && vasp.KPOINT.number_band_traced == 0 ){
      if( false );
      else if( vasp.KPOINT.nkmesh[0] < 2*int(10.0/A) ){
	Common_Parameters.K_points.Sampling_k_mesh = "Sparse";
      }
      else if( vasp.KPOINT.nkmesh[0] < 2*int(20.0/A) ){
	Common_Parameters.K_points.Sampling_k_mesh = "Normal";
      }
      else{
	Common_Parameters.K_points.Sampling_k_mesh = "Dense";
      }
    }

    // band
    if( vasp.INCAR.ICHARG == 11 && vasp.KPOINT.number_band_traced > 0 ){
      if( false );
      else if( vasp.KPOINT.number_band_traced <= 25 ){
	Common_Parameters.K_points.Sampling_k_mesh = "Sparse";
      }
      else if( vasp.KPOINT.number_band_traced <= 50 ){
	Common_Parameters.K_points.Sampling_k_mesh = "Normal";
      }
      else{
	Common_Parameters.K_points.Sampling_k_mesh = "Dense";
      }
    }

    updateKPoint();
  }
}

void DTUDF::convertTo( DTVasp& vasp ) const
{
  vasp.clear();

  // <Calculation_Type>
  if( false );
  else if( Common_Parameters.Calculation_Settings.Calculation_Type
      == "Energy" ){
    vasp.INCAR.ICHARG = 0;
    vasp.INCAR.NSW = 0;
    vasp.KPOINT.number_band_traced = 0;
  }
  else if( Common_Parameters.Calculation_Settings.Calculation_Type
      == "Band" ){
    vasp.INCAR.ICHARG = 11;
    vasp.INCAR.NSW = 0;
    vasp.KPOINT.number_band_traced = 1; // will be given just later
  }
  else if( Common_Parameters.Calculation_Settings.Calculation_Type
      == "DOS" ){
    vasp.INCAR.ICHARG = 11;
    vasp.INCAR.NSW = 0;
    vasp.KPOINT.number_band_traced = 0;
  }
  else if( Common_Parameters.Calculation_Settings.Calculation_Type
      == "Optimize" ){
    vasp.INCAR.ICHARG = 0;
    vasp.INCAR.NSW = Common_Parameters.Calculation_Settings.Ion_Max_Iteration;
    vasp.KPOINT.number_band_traced = 0;
  }

  // <Continue>
  if( Common_Parameters.Calculation_Settings.Continue == "New" ){
    vasp.INCAR.ISTART = 0;
  }
  else{ // "Restart"
    vasp.INCAR.ISTART = 1;
  }

  double degree;

  // <Cutoff_Wave_Function>
  const QString Accuracy =
    Common_Parameters::Calculation_Settings::Cutoff_Wave_Function_def.getAccuracy
    (Common_Parameters.Calculation_Settings.Cutoff_Wave_Function);
  if( false );
  else if( Accuracy == "Low" ){
    vasp.INCAR.PREC = "Single";
  }
  else if( Accuracy == "Normal" ){
    vasp.INCAR.PREC = "Normal";
  }
  else if( Accuracy == "High" ){
    vasp.INCAR.PREC = "High";
  }

  // <Mixing_Factor>
  degree = Common_Parameters::Calculation_Settings::Mixing_Factor_def
    .getDegree(Common_Parameters.Calculation_Settings.Mixing_Factor);
  vasp.INCAR.AMIX =
    DTVasp::INCAR::AMIX_def.getValue(degree);

  // <Electron_Max_Iteration>
  degree = Common_Parameters::Calculation_Settings::Electron_Max_Iteration_def
    .getDegree(Common_Parameters.Calculation_Settings.Electron_Max_Iteration);
  vasp.INCAR.NELM =
    (int)DTVasp::INCAR::NELM_def.getValue(degree);

  // <Energy_Converge>
  degree = Common_Parameters::Calculation_Settings::Energy_Converge_def
    .getDegree(Common_Parameters.Calculation_Settings.Energy_Converge);
  vasp.INCAR.EDIFF =
    DTVasp::INCAR::EDIFF_def.getValue(degree);

  // <Force_Converge>
  degree = Common_Parameters::Calculation_Settings::Force_Converge_def
    .getDegree(Common_Parameters.Calculation_Settings.Force_Converge);
  vasp.INCAR.EDIFFG =
    DTVasp::INCAR::EDIFFG_def.getValue(degree);

  // <Smearing>
  if( false );
  else if( Common_Parameters.Calculation_Settings.Smearing == "Recommend" ){
    if( Common_Parameters.Calculation_Settings.Calculation_Type == "Energy" ||
	Common_Parameters.Calculation_Settings.Calculation_Type == "DOS" ){
      vasp.INCAR.ISMEAR = -5;
    }
    if( Common_Parameters.Calculation_Settings.Calculation_Type == "Band" ||
	Common_Parameters.Calculation_Settings.Calculation_Type == "Optimize" ){
      vasp.INCAR.ISMEAR = 0;
    }
    vasp.INCAR.SIGMA = 0.1;
  }
  else if( Common_Parameters.Calculation_Settings.Smearing == "Methfessel-Paxton" ){
    vasp.INCAR.ISMEAR = +1;
    vasp.INCAR.SIGMA = 0.1;
  }
  else if( Common_Parameters.Calculation_Settings.Smearing == "Fermi" ){
    vasp.INCAR.ISMEAR = -1;
    vasp.INCAR.SIGMA = 0.1;
  }

  // <Spin>
  if( Common_Parameters.Calculation_Settings.Spin ){
    vasp.INCAR.ISPIN = 2;
  }
  else{
    vasp.INCAR.ISPIN = 1;
  }

  // <XC_Type>
  if( false );
  else if( Common_Parameters.Calculation_Settings.XC_Type == "LDA" ){
    vasp.INCAR.GGA = "None";
    vasp.INCAR.LHFCAL = false;
    vasp.INCAR.AEXX = 0.0;
    vasp.INCAR.AGGAC = 1.0;
  }
  else if( Common_Parameters.Calculation_Settings.XC_Type == "PBE" ){
    vasp.INCAR.GGA = "PE";
    vasp.INCAR.LHFCAL = false;
    vasp.INCAR.AEXX = 0.0;
    vasp.INCAR.AGGAC = 1.0;
  }
  else if( Common_Parameters.Calculation_Settings.XC_Type == "PBEsol" ){
    vasp.INCAR.GGA = "PS";
    vasp.INCAR.LHFCAL = false;
    vasp.INCAR.AEXX = 0.0;
    vasp.INCAR.AGGAC = 1.0;
  }
  else if( Common_Parameters.Calculation_Settings.XC_Type == "PW91" ){
    vasp.INCAR.GGA = "91";
    vasp.INCAR.LHFCAL = false;
    vasp.INCAR.AEXX = 0.0;
    vasp.INCAR.AGGAC = 1.0;
  }
  else if( Common_Parameters.Calculation_Settings.XC_Type == "PBE0" ){
    vasp.INCAR.GGA = "PE";
    vasp.INCAR.LHFCAL = true;
    vasp.INCAR.AEXX = 0.25;
    vasp.INCAR.AGGAC = 1.0;
  }
  else if( Common_Parameters.Calculation_Settings.XC_Type == "HF" ){
    vasp.INCAR.GGA = "None";
    vasp.INCAR.LHFCAL = true;
    vasp.INCAR.AEXX = 1.0;
    vasp.INCAR.AGGAC = 0.0;
  }

  // <Symmetry>
  if( Common_Parameters.Calculation_Settings.Symmetry ){
    vasp.INCAR.ISYM = 1;
  }
  else{
    vasp.INCAR.ISYM = 0;
  }

  // <Ion_Max_Iteration>
  if( Common_Parameters.Calculation_Settings.Calculation_Type
      == "Optimize" ){
    if( Common_Parameters.Calculation_Settings.Ion_Max_Iteration == 0 ){
      vasp.INCAR.NSW = 0;
    }
    else{
      vasp.INCAR.NSW =
	Common_Parameters.Calculation_Settings.Ion_Max_Iteration;
    }
  }
  else{
    vasp.INCAR.NSW = 0;
  }

  // <Lattice_Constant>
  vasp.POSCAR.lattice_factor =
    Common_Parameters.Structural_Parameters.Lattice_Constant;

  // <Lattice_Vector>
  vasp.POSCAR.lattice_list[0] =
    Common_Parameters.Structural_Parameters.Lattice_Vector[0];

  vasp.POSCAR.lattice_list[1] =
    Common_Parameters.Structural_Parameters.Lattice_Vector[1];

  vasp.POSCAR.lattice_list[2] =
    Common_Parameters.Structural_Parameters.Lattice_Vector[2];

  // <Atom>
  vasp.POSCAR.atom =
    Common_Parameters.Structural_Parameters.Atom;


  // <Sampling_k_mesh>
  if( Common_Parameters.Calculation_Settings.Calculation_Type == "Band" ){
    vasp.KPOINT.number_band_traced
      = Common_Parameters.K_points.Symmetric_k_points;
    vasp.KPOINT.nkmesh[0] = 0;
    vasp.KPOINT.nkmesh[1] = 0;
    vasp.KPOINT.nkmesh[2] = 0;
  }
  else{
    vasp.KPOINT.number_band_traced = 0;
    vasp.KPOINT.nkmesh[0] = Common_Parameters.K_points.nkmesh[0];
    vasp.KPOINT.nkmesh[1] = Common_Parameters.K_points.nkmesh[1];
    vasp.KPOINT.nkmesh[2] = Common_Parameters.K_points.nkmesh[2];

    if( Common_Parameters.Calculation_Settings.Calculation_Type == "DOS" ){
      vasp.KPOINT.nkmesh[0] *= 2;
      vasp.KPOINT.nkmesh[1] *= 2;
      vasp.KPOINT.nkmesh[2] *= 2;
    }
  }
}



void DTUDF::convertFrom( const DTOpenMX& openmx )
{
  clear();

  // <Calculation_Type>
  if( openmx.MD.Type != "nomd" ){
    Common_Parameters.Calculation_Settings.Calculation_Type = "Optimize";    
  }
  else{
    if( openmx.Band.dispersion ){
      Common_Parameters.Calculation_Settings.Calculation_Type = "Band";
    }
    if( openmx.Dos.fileout ){
      Common_Parameters.Calculation_Settings.Calculation_Type = "DOS";
    }
    else{
      Common_Parameters.Calculation_Settings.Calculation_Type = "Energy";    
    }
  }
  updateType();


  // <Continue>
  if( openmx.scf.restart ){
    Common_Parameters.Calculation_Settings.Continue = "Restart";
  }
  else{
    Common_Parameters.Calculation_Settings.Continue = "New";
  }

  // <Accuracy>
  Common_Parameters.Calculation_Settings.Accuracy
    = DTOpenMX::scf::energycutoff_def.getAccuracy
    (openmx.scf.energycutoff);
  updateAccuracy();

  double degree;

  // <Cutoff_Wave_Function>
  degree = DTOpenMX::scf::energycutoff_def.getDegree
    (openmx.scf.energycutoff);
  Common_Parameters.Calculation_Settings.Cutoff_Wave_Function
    = Common_Parameters::Calculation_Settings::Cutoff_Wave_Function_def.getValue(degree);

  // <Mixing_Factor>
  degree = DTOpenMX::scf::Max_Mixing_Weight_def.getDegree
    (openmx.scf.Max_Mixing_Weight);
  Common_Parameters.Calculation_Settings.Mixing_Factor
    = Common_Parameters::Calculation_Settings::Mixing_Factor_def.getValue(degree);

  // <Electron_Max_Iteration>
  degree = DTOpenMX::scf::maxIter_def.getDegree
    (openmx.scf.maxIter);
  Common_Parameters.Calculation_Settings.Electron_Max_Iteration
    = (int)Common_Parameters::Calculation_Settings::Electron_Max_Iteration_def.getValue(degree);

  // <Energy_Converge>
  degree = DTOpenMX::scf::criterion_def.getDegree
    (openmx.scf.criterion);
  Common_Parameters.Calculation_Settings.Energy_Converge
    = Common_Parameters::Calculation_Settings::Energy_Converge_def.getValue(degree);

  // <Force_Converge>
  degree = DTOpenMX::MD::Opt_criterion_def.getDegree
    (openmx.MD.Opt_criterion);
  Common_Parameters.Calculation_Settings.Force_Converge
    = Common_Parameters::Calculation_Settings::Force_Converge_def.getValue(degree);

  // <Number_Band>
  Common_Parameters.Calculation_Settings.Number_Band = 0;

  // <Smearing>
  Common_Parameters.Calculation_Settings.Smearing = "Recommend";


  // <Spin>
  if( openmx.scf.SpinPolarization ){
    Common_Parameters.Calculation_Settings.Spin = true;
  }
  else{
    Common_Parameters.Calculation_Settings.Spin = false;
  }

  // <XC_Type>
  if( false );
  else if( openmx.scf.XcType == "LDA" ||
	   openmx.scf.XcType == "LSDA-CA" ){
    Common_Parameters.Calculation_Settings.XC_Type = "LDA";
  }
  else if( openmx.scf.XcType == "GGA-PBE" ){
    Common_Parameters.Calculation_Settings.XC_Type = "PBE";
  }
  else if( openmx.scf.XcType == "LSDA-PW" ){
    Common_Parameters.Calculation_Settings.XC_Type = "PW91";
  }

  // <Symmetry>
  Common_Parameters.Calculation_Settings.Symmetry = false;

  // <Ion_Max_Iteration>
  Common_Parameters.Calculation_Settings.Ion_Max_Iteration
    = openmx.MD.maxIter-1;

  // <Lattice_Constant>
  Common_Parameters.Structural_Parameters.Lattice_Constant
    = 1.0;

  // <Lattice_Vector>
  Common_Parameters.Structural_Parameters.Lattice_Vector[0]
    = openmx.UnitVectors.lattice_list[0];
  Common_Parameters.Structural_Parameters.Lattice_Vector[1]
    = openmx.UnitVectors.lattice_list[1];
  Common_Parameters.Structural_Parameters.Lattice_Vector[2]
    = openmx.UnitVectors.lattice_list[2];

  // <Atom>
  Common_Parameters.Structural_Parameters.Atom
    = openmx.AtomicPositions.vatom;

  updateAtom();


  // <Sampling_k_mesh>
  {
    const double A =
      Common_Parameters.Structural_Parameters.Lattice_Constant
      * Position::length(Common_Parameters.Structural_Parameters.Lattice_Vector[0]);

    if( false );
    else if( openmx.scf.Kgrid[0] < int(15.0/A) ){
      Common_Parameters.K_points.Sampling_k_mesh = "Sparse";
    }
    else if( openmx.scf.Kgrid[0] < int(25.0/A) ){
      Common_Parameters.K_points.Sampling_k_mesh = "Normal";
    }
    else{
      Common_Parameters.K_points.Sampling_k_mesh = "Dense";
    }

    updateKPoint();
  }
}

void DTUDF::convertTo( DTOpenMX& openmx ) const
{
  openmx.clear();

  // <Calculation_Type>
  if( false );
  else if( Common_Parameters.Calculation_Settings.Calculation_Type
      == "Energy" ){
    openmx.Band.dispersion = false;
    openmx.Dos.fileout = false;
    openmx.MD.Type = "nomd";
  }
  else if( Common_Parameters.Calculation_Settings.Calculation_Type
      == "Band" ){
    openmx.Band.dispersion = true;
    openmx.Dos.fileout = false;
    openmx.MD.Type = "nomd";
  }
  else if( Common_Parameters.Calculation_Settings.Calculation_Type
      == "DOS" ){
    openmx.Band.dispersion = false;
    openmx.Dos.fileout = true;
    openmx.MD.Type = "nomd";
  }
  else if( Common_Parameters.Calculation_Settings.Calculation_Type
      == "Optimize" ){
    openmx.Band.dispersion = false;
    openmx.Dos.fileout = false;
    openmx.MD.Type = "Opt";
  }

  // <Continue>
  if( Common_Parameters.Calculation_Settings.Continue == "New" ){
    openmx.scf.restart = false;
  }
  else{ // "Restart"
    openmx.scf.restart = true;
  }

  double degree;

  // <Cutoff_Wave_Function>
  degree = Common_Parameters::Calculation_Settings::Cutoff_Wave_Function_def
    .getDegree(Common_Parameters.Calculation_Settings.Cutoff_Wave_Function);
  openmx.scf.energycutoff =
    DTOpenMX::scf::energycutoff_def.getValue(degree);

  // <Mixing_Factor>
  degree = Common_Parameters::Calculation_Settings::Mixing_Factor_def
    .getDegree(Common_Parameters.Calculation_Settings.Mixing_Factor);
  openmx.scf.Max_Mixing_Weight =
    DTOpenMX::scf::Max_Mixing_Weight_def.getValue(degree);

  // <Electron_Max_Iteration>
  degree = Common_Parameters::Calculation_Settings::Electron_Max_Iteration_def
    .getDegree(Common_Parameters.Calculation_Settings.Electron_Max_Iteration);
  openmx.scf.maxIter =
    (int)DTOpenMX::scf::maxIter_def.getValue(degree);

  // <Energy_Converge>
  degree = Common_Parameters::Calculation_Settings::Energy_Converge_def
    .getDegree(Common_Parameters.Calculation_Settings.Energy_Converge);
  openmx.scf.criterion =
    DTOpenMX::scf::criterion_def.getValue(degree);

  // <Force_Converge>
  degree = Common_Parameters::Calculation_Settings::Force_Converge_def
    .getDegree(Common_Parameters.Calculation_Settings.Force_Converge);
  openmx.MD.Opt_criterion =
    DTOpenMX::MD::Opt_criterion_def.getValue(degree);

  // <Smearing>
  {
    // nothing to output
  }

  // <Spin>
  if( Common_Parameters.Calculation_Settings.Spin ){
    openmx.scf.SpinPolarization = true;
  }
  else{
    openmx.scf.SpinPolarization = false;
  }

  // <XC_Type>
  if( false );
  else if( Common_Parameters.Calculation_Settings.XC_Type == "LDA" ){
    openmx.scf.XcType = "LDA";
  }
  else if( Common_Parameters.Calculation_Settings.XC_Type == "PBE" ){
    openmx.scf.XcType = "GGA-PBE";
  }
  else if( Common_Parameters.Calculation_Settings.XC_Type == "PBEsol" ){
    openmx.scf.XcType = "GGA-PBE"; // not appropriate
  }
  else if( Common_Parameters.Calculation_Settings.XC_Type == "PW91" ){
    openmx.scf.XcType = "LSDA-PW";
  }
  else if( Common_Parameters.Calculation_Settings.XC_Type == "PBE0" ){
    openmx.scf.XcType = "GGA-PBE"; // not appropriate
  }
  else if( Common_Parameters.Calculation_Settings.XC_Type == "HF" ){
    openmx.scf.XcType = "GGA-PBE"; // not appropriate
  }

  // <Symmetry>
  {
    // nothing to output
  }

  // <Ion_Max_Iteration>
  if( Common_Parameters.Calculation_Settings.Calculation_Type == "Optimize" ){
    openmx.MD.maxIter = Common_Parameters.Calculation_Settings.Ion_Max_Iteration+1;
  }
  else{
    openmx.MD.maxIter = 1;
  }

  // <Lattice_Constant>
  // <Lattice_Vector>
  openmx.UnitVectors.lattice_list[0] =
    + Common_Parameters.Structural_Parameters.Lattice_Vector[0]
    * Common_Parameters.Structural_Parameters.Lattice_Constant;
  openmx.UnitVectors.lattice_list[1] =
    + Common_Parameters.Structural_Parameters.Lattice_Vector[1]
    * Common_Parameters.Structural_Parameters.Lattice_Constant;
  openmx.UnitVectors.lattice_list[2] =
    + Common_Parameters.Structural_Parameters.Lattice_Vector[2]
    * Common_Parameters.Structural_Parameters.Lattice_Constant;

  // <Atom>
  openmx.AtomicPositions.vatom =
    Common_Parameters.Structural_Parameters.Atom;



  // <Sampling_k_mesh>
  {
    openmx.scf.Kgrid[0] = Common_Parameters.K_points.nkmesh[0];
    openmx.scf.Kgrid[1] = Common_Parameters.K_points.nkmesh[1];
    openmx.scf.Kgrid[2] = Common_Parameters.K_points.nkmesh[2];

    if( Common_Parameters.Calculation_Settings.Calculation_Type == "DOS" ){
      openmx.Dos.Kgrid[0] = openmx.scf.Kgrid[0]*2;
      openmx.Dos.Kgrid[1] = openmx.scf.Kgrid[1]*2;
      openmx.Dos.Kgrid[2] = openmx.scf.Kgrid[2]*2;
    }
    else{
      openmx.Dos.Kgrid[0] = 0;
      openmx.Dos.Kgrid[1] = 0;
      openmx.Dos.Kgrid[2] = 0;
    }
  }
}





void DTUDF::convertFrom( const DTRSDFT& rsdft )
{
  clear();

  // <Calculation_Type>
  if( rsdft.SWOPT > 0 ){
    Common_Parameters.Calculation_Settings.Calculation_Type = "Optimize";    
  }
  else if( rsdft.SWBAND > 0 ){
    Common_Parameters.Calculation_Settings.Calculation_Type = "Band";
  }
  else {
    Common_Parameters.Calculation_Settings.Calculation_Type = "Energy";    
  }

  updateType();

  // <Continue>
  if( rsdft.SWOPT == 2 ){
    Common_Parameters.Calculation_Settings.Continue = "Restart";
  }
  else{
    Common_Parameters.Calculation_Settings.Continue = "New";
  }

  // <Accuracy>
  Common_Parameters.Calculation_Settings.Accuracy
    = DTRSDFT::DGRID_def.getAccuracy
    (rsdft.DGRID);
  updateAccuracy();

  double degree;

  // <Cutoff_Wave_Function>
  degree = DTRSDFT::DGRID_def.getDegree
    (rsdft.DGRID);
  Common_Parameters.Calculation_Settings.Cutoff_Wave_Function
    = Common_Parameters::Calculation_Settings::Cutoff_Wave_Function_def.getValue(degree);

  // <Mixing_Factor>
  degree = DTRSDFT::BETA_def.getDegree
    (rsdft.BETA);
  Common_Parameters.Calculation_Settings.Mixing_Factor
    = Common_Parameters::Calculation_Settings::Mixing_Factor_def.getValue(degree);

  // <Electron_Max_Iteration>
  degree = DTRSDFT::DITER_def.getDegree
    (rsdft.DITER);
  Common_Parameters.Calculation_Settings.Electron_Max_Iteration
    = (int)Common_Parameters::Calculation_Settings::Electron_Max_Iteration_def.getValue(degree);

  // <Energy_Converge>
  degree = DTRSDFT::SCFCONV_def.getDegree
    (rsdft.SCFCONV);
  Common_Parameters.Calculation_Settings.Energy_Converge
    = Common_Parameters::Calculation_Settings::Energy_Converge_def.getValue(degree);

  // <Force_Converge>
  degree = DTRSDFT::ATOMOPT2_def.getDegree
    (rsdft.ATOMOPT2);
  Common_Parameters.Calculation_Settings.Force_Converge
    = Common_Parameters::Calculation_Settings::Force_Converge_def.getValue(degree);

  // <Spin>
  if( rsdft.NSPIN == 2 ){
    Common_Parameters.Calculation_Settings.Spin = true;
  }
  else{
    Common_Parameters.Calculation_Settings.Spin = false;
  }

  // <Number_Band>
  Common_Parameters.Calculation_Settings.Number_Band
    = rsdft.NBAND;

  // <Smearing>
  Common_Parameters.Calculation_Settings.Smearing = "Recommend";

  // <XC_Type>
  if( rsdft.XCTYPE == "'LDAPZ81'" ){
    Common_Parameters.Calculation_Settings.XC_Type = "LDA";
  }
  else if( rsdft.XCTYPE == "'GGAPBE96'" ){
    Common_Parameters.Calculation_Settings.XC_Type = "PBE";
  }
  else if( rsdft.XCTYPE == "'HSE'" ){
    Common_Parameters.Calculation_Settings.XC_Type = "HF";
  }

  // <Symmetry>
  if( rsdft.ISYM == 1 ){
    Common_Parameters.Calculation_Settings.Symmetry = true;
  }
  else{
    Common_Parameters.Calculation_Settings.Symmetry = false;
  }

  // <Ion_Max_Iteration>
  Common_Parameters.Calculation_Settings.Ion_Max_Iteration
    = rsdft.ATOMOPT1;

  // <Lattice_Constant>
  Common_Parameters.Structural_Parameters.Lattice_Constant
    = rsdft.AX * AU_TO_AA;

  // <Lattice_Vector>
  Common_Parameters.Structural_Parameters.Lattice_Vector[0]
    = rsdft.A1;
  Common_Parameters.Structural_Parameters.Lattice_Vector[1]
    = rsdft.A2;
  Common_Parameters.Structural_Parameters.Lattice_Vector[2]
    = rsdft.A3;

  // <Atom>
  Common_Parameters.Structural_Parameters.Atom
    = rsdft.Atom.atom;

  // <Number_Band>
  updateAtom();


  // <Sampling_k_mesh>
  {
    const double A =
      Common_Parameters.Structural_Parameters.Lattice_Constant
      * Position::length(Common_Parameters.Structural_Parameters.Lattice_Vector[0]);

    if( false );
    else if( rsdft.nkmesh[0] < int(15.0/A) ){
      Common_Parameters.K_points.Sampling_k_mesh = "Sparse";
    }
    else if( rsdft.nkmesh[0] < int(25.0/A) ){
      Common_Parameters.K_points.Sampling_k_mesh = "Normal";
    }
    else{
      Common_Parameters.K_points.Sampling_k_mesh = "Dense";
    }
    updateKPoint();
  }
}


void DTUDF::convertTo( DTRSDFT& rsdft ) const
{
  rsdft.clear();

  // <Calculation_Type>
  if( false );
  else if( Common_Parameters.Calculation_Settings.Calculation_Type
      == "Energy" ){
    rsdft.SWSCF = 1;
    rsdft.SWBAND = 0;
    rsdft.SWOPT = 0;
  }
  else if( Common_Parameters.Calculation_Settings.Calculation_Type
      == "Band" ){
    rsdft.SWSCF = 1;
    rsdft.SWBAND = 1;
    rsdft.SWOPT = 0;
  }
  else if( Common_Parameters.Calculation_Settings.Calculation_Type
      == "DOS" ){
    rsdft.SWSCF = 1;
    rsdft.SWBAND = 0;
    rsdft.SWOPT = 0;
  }
  else if( Common_Parameters.Calculation_Settings.Calculation_Type
      == "Optimize" ){
    rsdft.SWSCF = 1;
    rsdft.SWBAND = 0;
    rsdft.SWOPT = 1;
  }

  // <Continue>
  if( Common_Parameters.Calculation_Settings.Continue == "Restart" ){
    rsdft.SWOPT = 2;
  }

  double degree;

  // <Cutoff_Wave_Function>
  degree = Common_Parameters::Calculation_Settings::Cutoff_Wave_Function_def
    .getDegree(Common_Parameters.Calculation_Settings.Cutoff_Wave_Function);
  rsdft.DGRID = DTRSDFT::DGRID_def.getValue(degree);

  // <Mixing_Factor>
  degree = Common_Parameters::Calculation_Settings::Mixing_Factor_def
    .getDegree(Common_Parameters.Calculation_Settings.Mixing_Factor);
  rsdft.BETA = DTRSDFT::BETA_def.getValue(degree);

  // <Electron_Max_Iteration>
  degree = Common_Parameters::Calculation_Settings::Electron_Max_Iteration_def
    .getDegree(Common_Parameters.Calculation_Settings.Electron_Max_Iteration);
  rsdft.DITER = (int)DTRSDFT::DITER_def.getValue(degree);

  // <Energy_Converge>
  degree = Common_Parameters::Calculation_Settings::Energy_Converge_def
    .getDegree(Common_Parameters.Calculation_Settings.Energy_Converge);
  rsdft.SCFCONV = DTRSDFT::SCFCONV_def.getValue(degree);

  // <Force_Converge>
  degree = Common_Parameters::Calculation_Settings::Force_Converge_def
    .getDegree(Common_Parameters.Calculation_Settings.Force_Converge);
  rsdft.ATOMOPT2 = DTRSDFT::ATOMOPT2_def.getValue(degree);

  // <Spin>
  if( Common_Parameters.Calculation_Settings.Spin ){
    rsdft.NSPIN = 2;
  }
  else{
    rsdft.NSPIN = 1;
  }


  // <Number_Band>
  rsdft.NBAND =
    Common_Parameters.Calculation_Settings.Number_Band;

  // <Smearing>
  // "Recommend" only

  // <XC_Type>
  if( false );
  else if( Common_Parameters.Calculation_Settings.XC_Type == "LDA" ){
    rsdft.XCTYPE = "'LDAPZ81'";
  }
  else if( Common_Parameters.Calculation_Settings.XC_Type == "PBE" ){
    rsdft.XCTYPE = "'GGAPBE96'";
  }
  else if( Common_Parameters.Calculation_Settings.XC_Type == "PBEsol" ){
    rsdft.XCTYPE = "'GGAPBE96'";
  }
  else if( Common_Parameters.Calculation_Settings.XC_Type == "PW91" ){
    rsdft.XCTYPE = "'LDAPZ81'";
  }
  else if( Common_Parameters.Calculation_Settings.XC_Type == "PBE0" ){
    rsdft.XCTYPE = "'HSE'";
  }
  else if( Common_Parameters.Calculation_Settings.XC_Type == "HF" ){
    rsdft.XCTYPE = "'HSE'";
  }

  // <Ion_Max_Iteration>
  if( Common_Parameters.Calculation_Settings.Calculation_Type
      == "Optimize" ){
    if( Common_Parameters.Calculation_Settings.Ion_Max_Iteration == 0){
      rsdft.ATOMOPT1 = 3*Common_Parameters.Structural_Parameters.Atom.size();
    }
    else{
      rsdft.ATOMOPT1 =
	Common_Parameters.Calculation_Settings.Ion_Max_Iteration;
    }
  }
  else{
    rsdft.ATOMOPT1 = 0;
  }

  // <Lattice_Constant>
  rsdft.AX
    = Common_Parameters.Structural_Parameters.Lattice_Constant * AA_TO_AU;

  // <Lattice_Vector>
  rsdft.A1 = Common_Parameters.Structural_Parameters.Lattice_Vector[0];
  rsdft.A2 = Common_Parameters.Structural_Parameters.Lattice_Vector[1];
  rsdft.A3 = Common_Parameters.Structural_Parameters.Lattice_Vector[2];

  // <Atom>
  rsdft.Atom.atom
    = Common_Parameters.Structural_Parameters.Atom;

  // <Symmetry>
  rsdft.ISYM = 1;
  rsdft.findSymmetry();


  // <Sampling_k_mesh>
  {
    rsdft.nkmesh[0] = Common_Parameters.K_points.nkmesh[0];
    rsdft.nkmesh[1] = Common_Parameters.K_points.nkmesh[1];
    rsdft.nkmesh[2] = Common_Parameters.K_points.nkmesh[2];
    rsdft.skmesh[0] = 1;
    rsdft.skmesh[1] = 1;
    rsdft.skmesh[2] = 1;
  }
}

