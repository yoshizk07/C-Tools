/*
 Copyright (c) 2014 Shinji Tsuneyuki
 This file is distributed under the terms of the GNU General Public License version 3.
 */

/*!
 \file dtatoms.h
 \brief �i�q�̌��q�z�u�f�[�^�̃N���X
*/

#ifndef __DTATOMS_H_INCLUDED
#define __DTATOMS_H_INCLUDED

#include <vector>
using namespace std;

#include <QtCore/QString>
#include "position.h"

class DTCell;
class DTAtom
{
public:
  QString     name;   // ���f��
  int         number; // ���f�ԍ�
  Coordinates coords; // �Z���������W(A,B,C)
 
public:
  DTAtom( void ){}
};

class DTCell;

class DTAtoms
{
public:
  vector<DTAtom> vatom;    // ���q�Q

public:
  DTAtoms( void );

public:
  // �z�񏈗�
  void clear( void );
  bool empty( void ) const { return vatom.empty(); }
  int  size( void ) const { return vatom.size(); }
  void push_back( const DTAtom& atom ){ vatom.push_back(atom); }

  void update( void );

public:
  bool loadXYZ( DTCell& cell, const QString& fname );
  bool loadCIF( DTCell& cell, const QString& fname );


  int  iatom_selected;
  bool select( const int iatom );
  void unselect( void );
  bool isSelected( void ) const;
  int  getSelected( void ) const;
  bool changeSelected( const QString& name );
  bool changeSelected( const Coordinates& coords );
  bool deleteSelected( void );
  bool appendSelected( void );
};

#endif // __DTATOMS_H_INCLUDED
