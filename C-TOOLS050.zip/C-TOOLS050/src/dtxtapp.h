/*
 Copyright (c) 2014 Shinji Tsuneyuki
 This file is distributed under the terms of the GNU General Public License version 3.
 */

#ifndef __DTXTAPP_H_INCLUDED
#define __DTXTAPP_H_INCLUDED

#include <QtCore/QString>
#include "position.h"
#include "imatrix.h"
#include "dtatoms.h"
#include "table.h"

#include <vector>
using namespace std;

class DTLattice;

struct DTXTapp
{
  struct TappInput{
    double lattice_factor;
    Position lattice_list[3];
    int number_spin;
    double cutoff_wave_function;
    static Table cutoff_wave_function_def;
    double xtrap_beta;
    static Table xtrap_beta_def;
    int number_band;
    int chain_calc;
    double scf_converge;
    static Table scf_converge_def;
    int scf_number_iter;
    static Table scf_number_iter_def;
    QString xc_type;
  } TappInput;

  struct Symmetry{
    int  number_sym_op;
    bool has_inversion;
    int  denom_trans;
    vector<IMatrix> vmatrix;
  } Symmetry;

  struct Atom {
    vector<DTAtom> atom;
  } Atom;

  struct SmplKpt{
    QString dos_mode;
    int dos_mesh[3];
    int nkmesh[3];
    int skmesh[3];
  } SmplKpt;

  struct StructOpt{
    double converge_force;
    static Table converge_force_def;
    int number_cycle;
  } StructOpt;

  struct TraceBand{
    int number_band_traced;
  } TraceBand;

  DTXTapp( void ){
  }
  ~DTXTapp( void ){
    clear();
  }
  void clear( void );
  QString guess( const QString& fname );
  bool load( const QString& fname );
  bool save( const DTLattice& lattice, const QString& fname ) const;

  void findSymmetry( void );
};

#endif // __DTXTAPP_H_INCLUDED
