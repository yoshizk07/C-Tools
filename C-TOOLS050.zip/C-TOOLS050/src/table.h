/*
 Copyright (c) 2014 Shinji Tsuneyuki
 This file is distributed under the terms of the GNU General Public License version 3.
 */

#ifndef __TABLE_H_INCLUDED
#define __TABLE_H_INCLUDED

#include <QtCore/QString>

class Table
{
public:
  double value_low;
  double value_normal;
  double value_high;
  double value_min;
  double value_max;
  
  bool   lowsmaller;
  bool   exponential;
  double log_value_low;
  double log_value_normal;
  double log_value_high;

  Table( const double& vlow, const double& vnormal, const double& vhigh,
	    const double& vmin, const double& vmax );

  bool setTable( const double& vlow, const double& vnormal, const double& vhigh );

  double getDefault( const QString& Accuracy ) const;
  QString getAccuracy( const double v ) const;
  double getDegree( const double v ) const;
  double getValue( const double d ) const;
};

void output( const QString& fname, const Table& tableS, const Table& tableU );

#endif // __TABLE_H_INCLUDED
