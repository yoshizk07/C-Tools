import sys, os
import glob

def license_header(filename):
	ret_str = "/*\n " \
		    + "Copyright (c) 2014 Shinji Tsuneyuki\n " \
		    + "This file is distributed under the terms of the GNU General Public License version 3.\n " \
		    + "*/\n\n"
	
	return ret_str 

list_cc = glob.glob('*.cc')
list_cpp = glob.glob('*.cpp')
list_header = glob.glob('*.h')

#for target in list_header:
for target in list_cc:
	filename = os.path.basename(target)

	fin = open(target, "r+")
	data = fin.read()

	fin.seek(0,0)

	fin.write(license_header(filename))
	fin.write(data)

	fin.close()

	print target, " done"








