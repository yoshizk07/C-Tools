/*
 Copyright (c) 2014 Shinji Tsuneyuki
 This file is distributed under the terms of the GNU General Public License version 3.
 */

#include "dtmodel.h"
#include "dtlattice.h"
#include "dtopenmx.h"
#include "qtxml.h"
#include "qtexception.h"
#include "symbol.h"
#include <algorithm>

vector<DTOpenMX::AtomicSpecies::Element> DTOpenMX::AtomicSpecies::velement[3];

const double AU_TO_AA = 0.529177210818; // a.u. length to angstrom
const double AA_TO_AU = 1.0/AU_TO_AA;

Table DTOpenMX::scf::energycutoff_def( 120.0, 150.0, 180.0, 100.0, 200.0 );
Table DTOpenMX::scf::Max_Mixing_Weight_def( 0.4, 0.3, 0.2, 0.1, 0.9 );
Table DTOpenMX::scf::maxIter_def( 30, 40, 60, 10, 100 );
Table DTOpenMX::scf::criterion_def( 1.0e-4, 1.0e-6, 1.0e-8, 1.0e-10, 1.0e-2 );
Table DTOpenMX::MD::Opt_criterion_def( 3.0e-3, 3.0e-4, 3.0e-5, 3.0e-6, 3.0e-2 );

DTOpenMX::DTOpenMX( void )
{
}

DTOpenMX::~DTOpenMX( void )
{
}


void DTOpenMX::clear( void )
{
  AtomicPositions.vatom.clear();

  UnitVectors.lattice_list[0] = Position(1.0,0.0,0.0);
  UnitVectors.lattice_list[1] = Position(0.0,1.0,0.0);
  UnitVectors.lattice_list[2] = Position(0.0,0.0,1.0);

  scf.XcType = "LDA";
  scf.SpinPolarization = false;
  scf.restart = false;
  scf.energycutoff = scf::energycutoff_def.getDefault("Normal");
  scf.maxIter = scf::maxIter_def.getDefault("Normal");

  scf.Kgrid[0] = scf.Kgrid[1] = scf.Kgrid[2] = 4;
  scf.Mixing_Type = "Simple";
  scf.Max_Mixing_Weight = scf::Max_Mixing_Weight_def.getDefault("Normal");

  scf.criterion = scf::criterion_def.getDefault("Normal");

  MD.Type = "nomd";
  MD.maxIter = 1;
  MD.Opt_criterion = MD::Opt_criterion_def.getDefault("Normal");

  Band.dispersion = false;

  Dos.fileout = false;
  Dos.Kgrid[0] = scf.Kgrid[0];
  Dos.Kgrid[1] = scf.Kgrid[1];
  Dos.Kgrid[2] = scf.Kgrid[2];
}

QString DTOpenMX::guess( const QString& fname )
{
  FILE* fptr = fopen( fname, "rb" );
  if( fptr == NULL ){
    return "";
  }

  char buf[256];
  char svalue[32];

  bool match = false;
  while( fgets(buf,sizeof(buf),fptr) ){
    if( 1 == sscanf(buf," %s", svalue ) &&
	QString(svalue) == "System.CurrentDirectory" ){
      match = true;
      break;
    }
  }

  fclose(fptr);

  if( match ){
    return "solver openmx format";
  }

  return "";
}

bool DTOpenMX::load( const QString& fname )
{
  FILE* fptr = NULL;

  clear();

  try{
    char buf[1024];
    char svalue[64];
    double unit_coord  = 1.0;
    double unit_vector = 1.0;
    char name[64];
    Coordinates q;

    fptr = fopen( fname, "r" );
    if( fptr == NULL ){
      throw MyException("can not open a OpenMX file.", fname );
    }

    while(fgets(buf,sizeof(buf),fptr)){
      if( buf[0] == '#' ) continue;

      if( false );

      /* // ignore Atomic.Species
      else if( strncmp( buf, "<Definition.of.Atomic.Species",
			strlen("<Definition.of.Atomic.Species") ) == 0 ){
	while(fgets(buf,sizeof(buf),fptr)){
	  if( strncmp( buf, "Definition.of.Atomic.Species>",
		       strlen("Definition.of.Atomic.Species>") ) == 0 ){
	    break;
	  }

	  if( 1 == sscanf( buf, "%s", name ) ){
	    AtomicSpecies.velement.push_back(AtomicSpecies::Element(name));
	  }
	}
      }
      */

      else if( 1 == sscanf( buf, "Atoms.SpeciesAndCoordinates.Unit   %s", svalue ) ){
	if( strcmp( svalue, "AU" ) == 0 ){
	  unit_coord = AU_TO_AA;
	}
	else if( strcmp( svalue, "Ang" ) == 0 ){
	  unit_coord = 1.0;
	}
      }

      else if( strncmp( buf, "<Atoms.SpeciesAndCoordinates",
			strlen("<Atoms.SpeciesAndCoordinates") ) == 0 ){
	while(fgets(buf,sizeof(buf),fptr)){
	  if( strncmp( buf, "Atoms.SpeciesAndCoordinates>",
		       strlen("Atoms.SpeciesAndCoordinates>") ) == 0 ){
	    break;
	  }
	  if( 4 == sscanf( buf, "%*d %s %lf %lf %lf", name, &q.x, &q.y, &q.z ) ){
	    q *= unit_coord;

	    DTAtom atom;
	    atom.name = QString(name);
	    atom.number = ElementSymbol::getAtomicNumber(atom.name);
	    atom.coords = q;//converted to internal later

	    AtomicPositions.vatom.push_back(atom);
	  }
	}
      }

      else if( 1 == sscanf( buf, "Atoms.UnitVectors.Unit   %s", svalue ) ){
	if( strcmp( svalue, "AU" ) == 0 ){
	  unit_vector = AU_TO_AA;
	}
	else if( strcmp( svalue, "Ang" ) == 0 ){
	  unit_vector = 1.0;
	}
      }
      else if( strncmp( buf, "<Atoms.UnitVectors",
			strlen("<Atoms.UnitVectors") ) == 0 ){
	fgets(buf,sizeof(buf),fptr);
	sscanf( buf, "%lf %lf %lf",
		&UnitVectors.lattice_list[0].x,
		&UnitVectors.lattice_list[0].y,
		&UnitVectors.lattice_list[0].z );
	fgets(buf,sizeof(buf),fptr);
	sscanf( buf, "%lf %lf %lf",
		&UnitVectors.lattice_list[1].x,
		&UnitVectors.lattice_list[1].y,
		&UnitVectors.lattice_list[1].z );
	fgets(buf,sizeof(buf),fptr);
	sscanf( buf, "%lf %lf %lf",
		&UnitVectors.lattice_list[2].x,
		&UnitVectors.lattice_list[2].y,
		&UnitVectors.lattice_list[2].z );
	fgets(buf,sizeof(buf),fptr); // "Atoms.UnitVectors>"
	UnitVectors.lattice_list[0] *= unit_vector;
	UnitVectors.lattice_list[1] *= unit_vector;
	UnitVectors.lattice_list[2] *= unit_vector;
      }

      else if( 1 == XML::sscanf( buf, " scf.XcType  %s", &scf.XcType ) );
      else if( 1 == XML::sscanf( buf, " scf.SpinPolarization  %s", &scf.SpinPolarization ) );
      else if( 1 == XML::sscanf( buf, " scf.restart  %s", &scf.restart ) );

      else if( 1 == XML::sscanf( buf, " scf.energycutoff  %lf", &scf.energycutoff ) );
      else if( 1 == XML::sscanf( buf, " scf.maxIter  %d", &scf.maxIter ) );
      else if( 3 == XML::sscanf( buf, " scf.Kgrid  %d %d %d", &scf.Kgrid[0], &scf.Kgrid[1], &scf.Kgrid[2] ) ){
	Dos.Kgrid[0] = scf.Kgrid[0];
	Dos.Kgrid[1] = scf.Kgrid[1];
	Dos.Kgrid[2] = scf.Kgrid[2];
      }
      else if( 1 == XML::sscanf( buf, " scf.Mixing_Type  %s", &scf.Mixing_Type ) );
      else if( 1 == XML::sscanf( buf, " scf.Max_Mixing_Weight  %lf", &scf.Max_Mixing_Weight ) );
      else if( 1 == XML::sscanf( buf, " scf.criterion  %lf", &scf.criterion ) );

      else if( 1 == XML::sscanf( buf, " MD.Type  %s", &MD.Type ) );
      else if( 1 == XML::sscanf( buf, " MD.maxIter  %d", &MD.maxIter ) );
      else if( 1 == XML::sscanf( buf, " MD.Opt_criterion  %lf", &MD.Opt_criterion ) );

      else if( 1 == XML::sscanf( buf, " Band.dispersion  %s", &Band.dispersion ) );

      else if( 1 == XML::sscanf( buf, " Dos.fileout  %s", &Dos.fileout ) );
      else if( 3 == XML::sscanf( buf, " Dos.Kgrid  %d %d %d", &Dos.Kgrid[0], &Dos.Kgrid[1], &Dos.Kgrid[2] ) );
    }

    fclose(fptr);

    // convert atomic positions in internal coordinates
    {
      const Position& La = UnitVectors.lattice_list[0];
      const Position& Lb = UnitVectors.lattice_list[1];
      const Position& Lc = UnitVectors.lattice_list[2];
      const double V  = La*(Lb%Lc);
      const Position  Ka = (Lb%Lc)*(1.0/V);
      const Position  Kb = (Lc%La)*(1.0/V);
      const Position  Kc = (La%Lb)*(1.0/V);

      for( int ia=0; ia<(int)AtomicPositions.vatom.size(); ia++ ){
	Position& p = AtomicPositions.vatom[ia].coords;
	const Position q = p;
	p = Coordinates( q*Ka, q*Kb, q*Kc );
      }
    }
  }
  catch( const MyException& e ){
    MyException::critical(e);
    if(fptr) fclose(fptr);
    return false;
  }

  return true;
}

bool DTOpenMX::save( const DTLattice& lattice, const QString& fname ) const
{
  FILE* fptr = NULL;

  try{
    fptr = fopen( fname, "w" );
    if( fptr == NULL ){
      throw MyException("can not create a OpenMX file.", fname );
    }

    fprintf( fptr, "System.CurrentDirectory  ./\n");
    fprintf( fptr, "System.Name  %s\n", qPrintable(getFileName(fname)) );

    fprintf( fptr, "\n");

    {
      vector<QString> vname;
      vector<int>     vnumber;
      for( int ia=0; ia<(int)AtomicPositions.vatom.size(); ia++ ){
	const DTAtom& atom = AtomicPositions.vatom[ia];
	if( std::find( vname.begin(), vname.end(), atom.name ) == vname.end() ){
	  const int number = ElementSymbol::getAtomicNumber(atom.name);
	  vname.push_back(atom.name);
	  vnumber.push_back(number);
	}
      }

      const QString Accuracy = scf::energycutoff_def.getAccuracy(scf.energycutoff);

      const vector<AtomicSpecies::Element>& velement =
	Accuracy == "Low"    ? AtomicSpecies::velement[0] :
	Accuracy == "Normal" ? AtomicSpecies::velement[1] :
	Accuracy == "High"   ? AtomicSpecies::velement[2] :
	AtomicSpecies::velement[1];


      fprintf( fptr, "Species.Number  %d\n", (int)vname.size() );
      fprintf( fptr, "<Definition.of.Atomic.Species\n");
      for( int ie=0; ie<(int)vnumber.size(); ie++ ){
	const int number = vnumber[ie];
	const AtomicSpecies::Element& element = velement[number];
	fprintf( fptr, " %s %s-%s %s\n",
		 qPrintable(element.name), 
		 qPrintable(element.pao),
		 qPrintable(element.mode),
		 qPrintable(element.vps) );
      }
      fprintf( fptr, "Definition.of.Atomic.Species>\n");
    }
    fprintf( fptr, "\n");

    fprintf( fptr, "Atoms.Number  %d\n", (int)AtomicPositions.vatom.size() );
    fprintf( fptr, "Atoms.SpeciesAndCoordinates.Unit  Ang\n");

    // convert atomic positions in internal coordinates
    {
      const Position& La = UnitVectors.lattice_list[0];
      const Position& Lb = UnitVectors.lattice_list[1];
      const Position& Lc = UnitVectors.lattice_list[2];

      fprintf( fptr, "<Atoms.SpeciesAndCoordinates\n");
      for( int ia=0; ia<(int)AtomicPositions.vatom.size(); ia++ ){
	const DTAtom& atom =  AtomicPositions.vatom[ia];
	const Coordinates& q = atom.coords;
	const Position p = q.a*La + q.b*Lb + q.c*Lc;
	const int val = ElementSymbol::getAtomicValence(atom.name);
	fprintf( fptr, " %d %s %f %f %f %5.2f %5.2f\n",
		 ia+1,
		 qPrintable(atom.name),
		 p.x, p.y, p.z,
		 double(val)*0.5, double(val)*0.5 );
      }
      fprintf( fptr, "Atoms.SpeciesAndCoordinates>\n");
    }
    fprintf( fptr, "\n");

    fprintf( fptr, "Atoms.UnitVectors.Unit  Ang\n");
    fprintf( fptr, "<Atoms.UnitVectors\n");
    fprintf( fptr, " %f %f %f\n",
	     UnitVectors.lattice_list[0].x,
	     UnitVectors.lattice_list[0].y,
	     UnitVectors.lattice_list[0].z );
    fprintf( fptr, " %f %f %f\n",
	     UnitVectors.lattice_list[1].x,
	     UnitVectors.lattice_list[1].y,
	     UnitVectors.lattice_list[1].z );
    fprintf( fptr, " %f %f %f\n",
	     UnitVectors.lattice_list[2].x,
	     UnitVectors.lattice_list[2].y,
	     UnitVectors.lattice_list[2].z );
    fprintf( fptr, "Atoms.UnitVectors>\n");
    fprintf( fptr, "\n");

    fprintf( fptr, "scf.XcType  %s\n", qPrintable(scf.XcType) );
    fprintf( fptr, "scf.SpinPolarization  %s\n", scf.SpinPolarization ? "on" : "off" );
    fprintf( fptr, "scf.restart  %s\n", scf.restart ? "on" : "off" );
    fprintf( fptr, "scf.energycutoff  %f\n", scf.energycutoff );
    fprintf( fptr, "scf.maxIter  %d\n", scf.maxIter );
    fprintf( fptr, "scf.EigenvalueSolver  band\n");
    fprintf( fptr, "scf.Kgrid  %d %d %d\n", 
	     scf.Kgrid[0], scf.Kgrid[1], scf.Kgrid[2] );
    fprintf( fptr, "scf.Mixing_Type  %s\n",
	     qPrintable(scf.Mixing_Type) );
    fprintf( fptr, "scf.Max_Mixing_Weight  %f\n", scf.Max_Mixing_Weight );
    fprintf( fptr, "scf.criterion  %e\n", scf.criterion );
    fprintf( fptr, "\n");

    fprintf( fptr, "MD.Type  %s\n", qPrintable(MD.Type) );
    fprintf( fptr, "MD.maxIter  %d\n", MD.maxIter );
    fprintf( fptr, "MD.Opt_criterion  %f\n", MD.Opt_criterion );
    fprintf( fptr, "\n");

    fprintf( fptr, "Band.dispersion  %s\n", Band.dispersion ? "on" : "off" );

    {
      const vector<BrillouinSegment> vsymmL 
	= lattice.cell.vsymmL;

      fprintf(fptr, "Band.Nkpath  %d\n", (int)vsymmL.size() );
      fprintf(fptr, "<Band.kpath\n");
      for( int i=0; i<(int)vsymmL.size(); i++ ){
	const BrillouinSegment& symmL = vsymmL[i];

	fprintf(fptr, "%2d %5.3f %5.3f %5.3f  %5.3f %5.3f %5.3f %s %s\n",
		symmL.npoint,
		symmL.positions.x,
		symmL.positions.y,
		symmL.positions.z,
		symmL.positione.x,
		symmL.positione.y,
		symmL.positione.z,
		qPrintable(symmL.labelPs),
		qPrintable(symmL.labelPe) );
      }
      fprintf(fptr, "Band.kpath>\n");
    }
    fprintf( fptr, "\n");

    fprintf( fptr, "Dos.fileout  %s\n", Dos.fileout ? "on" : "off" );
    fprintf( fptr, "Dos.Kgrid  %d %d %d\n", 
	     Dos.Kgrid[0], Dos.Kgrid[1], Dos.Kgrid[2] );

    fclose(fptr);
  }
  catch( const MyException& e ){
    MyException::critical(e);
    if(fptr) fclose(fptr);
    return false;
  }

  return true;
}


