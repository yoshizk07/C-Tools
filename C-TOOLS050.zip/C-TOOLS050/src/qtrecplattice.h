/*
 Copyright (c) 2014 Shinji Tsuneyuki
 This file is distributed under the terms of the GNU General Public License version 3.
 */

/*!
 \file qtrecplattice.h
 \brief �t�i�q��GUI�\���̃N���X
*/

#ifndef __QTRECPLATTICE_H_INCLUDED
#define __QTRECPLATTICE_H_INCLUDED

#include "qtwidgets.h"

class DTModel;

class QTRecpLattice : public MyQTab
{
  Q_OBJECT

private:
  DTModel& model;
  QTableWidget* table;

  enum { ID_NUMBER };

public:
  QTRecpLattice( DTModel& _model, const int id );
signals:
  void changed(const MyEvent&);
public slots:
  void update( void );
private slots:
  void edit( const MyEvent& ev );
};

#endif // __QTRECPLATTICE_H_INCLUDED


