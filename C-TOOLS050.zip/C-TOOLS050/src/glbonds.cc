/*
 Copyright (c) 2014 Shinji Tsuneyuki
 This file is distributed under the terms of the GNU General Public License version 3.
 */

/*!
 \file glbonds.cc
 \brief �i�q�̌�����GL�\���̃N���X
*/

#include <GL/gl.h>
#include "dtmodel.h"
#include "glbonds.h"
#include "symbol.h"

void GLBonds::update( void )
{
  //  const Position& La = model.lattice.cell.La;
  //  const Position& Lb = model.lattice.cell.Lb;
  //  const Position& Lc = model.lattice.cell.Lc;
  const Position& Lo = model.lattice.cell.Lo;
  const vector<DTAtom>& vatom = model.lattice.getAtoms();

  GLBase::beginNewList();

  glPushMatrix();
  glTranslated( Lo.x, Lo.y, Lo.z );

  // in case a small molecule
  if( (int)vatom.size()<100 ){
    for( int i=0; i<(int)vatom.size(); i++ ){
      for( int j=i+1; j<(int)vatom.size(); j++ ){
	makeBond( vatom[i], vatom[j] );
      }
    }
  }
  glPopMatrix();

  GLBase::endNewList();
}


void GLBonds::makeBond( const DTAtom& atom1, const DTAtom& atom2 )
{
  const int  number1 = atom1.number;
  const int  number2 = atom2.number;

  const Position pos1 = model.lattice.cell.getPositionLocal(atom1.coords);
  const Position pos2 = model.lattice.cell.getPositionLocal(atom2.coords);

  const GLOption::Lattice::Bond::byElement& element = model.gloption.lattice.bond.element(number1,number2);
  const double& length = element.length;
  const GLcolor& color = element.color;

  const double scale   = model.gloption.lattice.bond.scale;
  const int    slices  = (int)model.gloption.lattice.bond.slices;
  const bool   lines   = model.gloption.lattice.bond.lines;

  if( Position::distance2( pos1, pos2 ) > length*length ) return;

  glColor4dv( color );
  glMaterialdv( GL_FRONT, GL_AMBIENT_AND_DIFFUSE, color );

  if( lines ){
    glDisable( GL_LIGHTING );
    glLineWidth( scale*16.0);
    glBegin( GL_LINES );
    glVertex3dv( pos1 );
    glVertex3dv( pos2 );
    glEnd();
    glLineWidth(1.0);
    glEnable( GL_LIGHTING );
  }else{
    gluSolidStick( scale, pos1, pos2, slices );
  }
}

