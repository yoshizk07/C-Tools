/*
 Copyright (c) 2014 Shinji Tsuneyuki
 This file is distributed under the terms of the GNU General Public License version 3.
 */

/*!
 \file dtlattice.h
 \brief �i�q�f�[�^�̓����N���X
*/

#ifndef __DTLATTICE_H_INCLUDED
#define __DTLATTICE_H_INCLUDED

#include <vector>
using namespace std;

#include "dtcell.h"
#include "dtatoms.h"

// �����̃f�[�^���Ǘ�����N���X
class DTLattice
{
public:
  DTCell   cell;     // �Z���`��
  DTAtoms  molecule;

  int getAtomsSize( void ) const {
    return 1;
  }
  DTAtoms& getData( void ){
    return molecule;
  }
  const DTAtoms& getData( void ) const {
    return molecule;
  }

public:
  DTLattice( void );

public:
  void update( void );
private:
  void updateAtoms( void );

public:
  void clear( void );
  bool isset( void ) const {
    return true;
  }

public:
  // atoms�f�[�^�ɑ΂��鑀��
  const vector<DTAtom>& getAtoms( void ) const {
    return molecule.vatom;
  }
  int getAtomSize( void ) const {
    return molecule.size();
  }

  double getScale( void ) const;
  double getReciprocalScale( void ) const;
};


#endif // __DTLATTICE_H_INCLUDED
