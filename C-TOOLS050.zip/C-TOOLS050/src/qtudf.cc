/*
 Copyright (c) 2014 Shinji Tsuneyuki
 This file is distributed under the terms of the GNU General Public License version 3.
 */

/*!
  \file qtudf.cc
  \brief UDF�̐ݒ��GUI�\���̃N���X
*/

#include "qtudf.h"
#include "dtmodel.h"
#include "symbol.h"

//------------------------------------------------------------

QTUDF::QTUDF( DTModel& _model, const int _id ) :
  model(_model), id(_id)
{
  QHBoxLayout* hlayout = new QHBoxLayout(this);
  hlayout->setSizeConstraint( QLayout::SetFixedSize );

  setFixedSize(800,500);
  setWindowTitle("UDF settings");

  {
    QVBoxLayout* layout = new QVBoxLayout;

    // <Calculation_Type>
    {
      MyQGroupBox* widget = new MyQGroupBox("Calculation_Type");
      QGridLayout* box = new QGridLayout;
      int row=0,col=0;

      {
	MyQRadioButton* swidget = new MyQRadioButton
	  ( "Energy", model.udf.Common_Parameters.Calculation_Settings.Calculation_Type,
	    this, SLOT(edit(const MyEvent&)), ID_TYPE );
	box->addWidget(swidget,row,col++);
	vwidget.push_back(swidget);
      }
      {
	MyQRadioButton* swidget = new MyQRadioButton
	  ( "Band", model.udf.Common_Parameters.Calculation_Settings.Calculation_Type,
	    this, SLOT(edit(const MyEvent&)), ID_TYPE );
	box->addWidget(swidget,row,col++);
	vwidget.push_back(swidget);
      }
      row++,col=0;
      {
	MyQRadioButton* swidget = new MyQRadioButton
	  ( "DOS", model.udf.Common_Parameters.Calculation_Settings.Calculation_Type,
	    this, SLOT(edit(const MyEvent&)), ID_TYPE );
	box->addWidget(swidget,row,col++);
	vwidget.push_back(swidget);
      }
      {
	MyQRadioButton* swidget = new MyQRadioButton
	  ( "Optimize", model.udf.Common_Parameters.Calculation_Settings.Calculation_Type,
	    this, SLOT(edit(const MyEvent&)), ID_TYPE );
	box->addWidget(swidget,row,col++);
	vwidget.push_back(swidget);
      }

      widget->setLayout(box);
      widget->setFixedWidth(250);
      layout->addWidget(widget);
      vwidget.push_back(widget);
    }

    // <Continue>
    {
      MyQGroupBox* widget = new MyQGroupBox("Continue");
      QHBoxLayout* box = new QHBoxLayout;

      {
	MyQRadioButton* swidget = new MyQRadioButton
	  ( "New", model.udf.Common_Parameters.Calculation_Settings.Continue,
	    this, SLOT(edit(const MyEvent&)), ID_PARAM );
	box->addWidget(swidget);
	vwidget.push_back(swidget);
      }
      {
	MyQRadioButton* swidget = new MyQRadioButton
	  ( "Restart", model.udf.Common_Parameters.Calculation_Settings.Continue,
	    this, SLOT(edit(const MyEvent&)), ID_PARAM );
	box->addWidget(swidget);
	vwidget.push_back(swidget);
      }

      widget->setLayout(box);
      widget->setFixedWidth(250);
      layout->addWidget(widget);
      vwidget.push_back(widget);
    }


    // <Accuracy>
    {
      MyQGroupBox* group = new MyQGroupBox("Accuracy");
      QHBoxLayout* box = new QHBoxLayout;

      {
	MyQRadioButton* swidget = new MyQRadioButton
	  ( "Low",
	    model.udf.Common_Parameters.Calculation_Settings.Accuracy,
	    this, SLOT(edit(const MyEvent&)), ID_ACCURACY );
	box->addWidget(swidget);
	vwidget.push_back(swidget);
      }
      {
	MyQRadioButton* swidget = new MyQRadioButton
	  ( "Normal",
	    model.udf.Common_Parameters.Calculation_Settings.Accuracy,
	    this, SLOT(edit(const MyEvent&)), ID_ACCURACY );
	box->addWidget(swidget);
	vwidget.push_back(swidget);
      }
      {
	MyQRadioButton* swidget = new MyQRadioButton
	  ( "High",
	    model.udf.Common_Parameters.Calculation_Settings.Accuracy,
	    this, SLOT(edit(const MyEvent&)), ID_ACCURACY );
	box->addWidget(swidget);
	vwidget.push_back(swidget);
      }

      group->setLayout(box);
      group->setFixedWidth(250);
      layout->addWidget(group);
      vwidget.push_back(group);
    }


    hlayout->addLayout(layout);
    hlayout->setAlignment(layout,Qt::AlignTop);
  }

  {
    QVBoxLayout* layout = new QVBoxLayout;

    // <Cutoff_Wave_Function>
    {
      MyQEditSliderGroup* widget = new MyQEditSliderGroup
	( "Cutoff_Wave_Function", "cutoff:", "Ry", "low", "high",
	  model.udf.Common_Parameters.Calculation_Settings.Cutoff_Wave_Function,
	  DTUDF::Common_Parameters::Calculation_Settings::Cutoff_Wave_Function_def.value_min,
	  DTUDF::Common_Parameters::Calculation_Settings::Cutoff_Wave_Function_def.value_max,
	  this, SLOT(edit(const MyEvent&)), ID_PARAM );
      widget->setFixedWidth(250);
      widget->setFormat("%%.2f");
      vwidget.push_back(widget);
      layout->addWidget(widget);
    }

    // <Mixing_Factor>
    {
      MyQEditSliderGroup* widget = new MyQEditSliderGroup
	( "Mixing_Factor", "factor:", "", "high", "low",
	  model.udf.Common_Parameters.Calculation_Settings.Mixing_Factor,
	  DTUDF::Common_Parameters::Calculation_Settings::Mixing_Factor_def.value_min,
	  DTUDF::Common_Parameters::Calculation_Settings::Mixing_Factor_def.value_max,
	  this, SLOT(edit(const MyEvent&)), ID_PARAM );
      widget->setFixedWidth(250);
      widget->setFormat("%%.2f");
      vwidget.push_back(widget);
      layout->addWidget(widget);
    }

    // <Electron_Max_Iteration>
    {
      MyQSpinBoxGroup* widget = new MyQSpinBoxGroup
	( "Electron_Max_Iteration", "iteration:",
	  model.udf.Common_Parameters.Calculation_Settings.Electron_Max_Iteration,
	  (int)DTUDF::Common_Parameters::Calculation_Settings::Electron_Max_Iteration_def.value_min,
	  (int)DTUDF::Common_Parameters::Calculation_Settings::Electron_Max_Iteration_def.value_max,
	  this, SLOT(edit(const MyEvent&)), ID_PARAM );
      widget->setFixedWidth(250);
      layout->addWidget(widget);
      vwidget.push_back(widget);
    }

    // <Energy_Converge>
    {
      MyQEditSliderGroup* widget = new MyQEditSliderGroup
	( "Energy_Converge", "threshold:", "a.u.", "high", "low",
	  model.udf.Common_Parameters.Calculation_Settings.Energy_Converge,
	  DTUDF::Common_Parameters::Calculation_Settings::Energy_Converge_def.value_min,
	  DTUDF::Common_Parameters::Calculation_Settings::Energy_Converge_def.value_max,
	  this, SLOT(edit(const MyEvent&)), ID_PARAM );
      widget->setFixedWidth(250);
      widget->setFormat("%%.2e");
      vwidget.push_back(widget);
      layout->addWidget(widget);
    }

    // <Force_Converge>
    {
      MyQEditSliderGroup* widget = new MyQEditSliderGroup
	( "Force_Converge", "threshold:", "", "high", "low",
	  model.udf.Common_Parameters.Calculation_Settings.Force_Converge,
	  DTUDF::Common_Parameters::Calculation_Settings::Force_Converge_def.value_min,
	  DTUDF::Common_Parameters::Calculation_Settings::Force_Converge_def.value_max,
	  this, SLOT(edit(const MyEvent&)), ID_PARAM );
      widget->setFixedWidth(250);
      widget->setFormat("%%.2e");
      layout->addWidget(widget);
      vwidget.push_back(widget);
    }

    hlayout->addLayout(layout);
    hlayout->setAlignment(layout,Qt::AlignTop);
  }

  {
    QVBoxLayout* layout = new QVBoxLayout;


    // <Ion_Max_Iteration>
    {
      MyQSpinBoxGroup* widget = new MyQSpinBoxGroup
	( "Ion_Max_Iteration", "iteration:",
	  model.udf.Common_Parameters.Calculation_Settings.Ion_Max_Iteration,
	  0, 1000,
	  this, SLOT(edit(const MyEvent&)), ID_PARAM );
      widget->setFixedWidth(250);
      layout->addWidget(widget);
      vwidget.push_back(widget);
    }


    // <Sampling_k_mesh>
    {
      MyQGroupBox* widget = new MyQGroupBox("Sampling_k_mesh");
      QHBoxLayout* box = new QHBoxLayout;

      {
	MyQRadioButton* swidget = new MyQRadioButton
	  ( "Sparse",
	    model.udf.Common_Parameters.K_points.Sampling_k_mesh,
	    this, SLOT(edit(const MyEvent&)), ID_KPOINT );
	box->addWidget(swidget);
	vwidget.push_back(swidget);
      }
      {
	MyQRadioButton* swidget = new MyQRadioButton
	  ( "Normal",
	    model.udf.Common_Parameters.K_points.Sampling_k_mesh,
	    this, SLOT(edit(const MyEvent&)), ID_KPOINT );
	box->addWidget(swidget);
	vwidget.push_back(swidget);
      }
      {
	MyQRadioButton* swidget = new MyQRadioButton
	  ( "Dense",
	    model.udf.Common_Parameters.K_points.Sampling_k_mesh,
	    this, SLOT(edit(const MyEvent&)), ID_KPOINT );
	box->addWidget(swidget);
	vwidget.push_back(swidget);
      }

      widget->setLayout(box);
      widget->setFixedWidth(250);
      layout->addWidget(widget);
      vwidget.push_back(widget);
    }

    // <Symmetry>
    {
      MyQGroupBox* widget = new MyQGroupBox("Symmetry");
      QHBoxLayout* box = new QHBoxLayout;

      {
	MyQCheckBox* swidget = new MyQCheckBox
	  ( "symmetry",
	    model.udf.Common_Parameters.Calculation_Settings.Symmetry,
	    this, SLOT(edit(const MyEvent&)), ID_PARAM );
	box->addWidget(swidget);
	vwidget.push_back(widget);
      }

      widget->setLayout(box);
      widget->setFixedWidth(250);
      layout->addWidget(widget);
      vwidget.push_back(widget);
    }

    // <Spin>
    {
      MyQGroupBox* widget = new MyQGroupBox("Spin");
      QHBoxLayout* box = new QHBoxLayout;

      {
	MyQCheckBox* swidget = new MyQCheckBox
	  ( "spin", model.udf.Common_Parameters.Calculation_Settings.Spin,
	    this, SLOT(edit(const MyEvent&)), ID_SPIN );
	box->addWidget(swidget);
	vwidget.push_back(widget);
      }

      widget->setLayout(box);
      widget->setFixedWidth(250);
      layout->addWidget(widget);
      vwidget.push_back(widget);
    }


    // <Number_Band>
    {
      MyQSpinBoxGroup* widget = new MyQSpinBoxGroup
	( "Number_Band", "band:",
	  model.udf.Common_Parameters.Calculation_Settings.Number_Band,
	  0, 1000,
	  this, SLOT(edit(const MyEvent&)), ID_PARAM );
      widget->setFixedWidth(250);
      layout->addWidget(widget);
      vwidget.push_back(widget);
    }


    // <Smearing>
    {
      MyQGroupBox* widget = new MyQGroupBox("Smearing");
      QVBoxLayout* box = new QVBoxLayout;

      {
	MyQRadioButton* swidget = new MyQRadioButton
	  ( "Recommend",
	    model.udf.Common_Parameters.Calculation_Settings.Smearing,
	    this, SLOT(edit(const MyEvent&)), ID_PARAM );
	box->addWidget(swidget);
	vwidget.push_back(swidget);
      }

      {
	MyQRadioButton* swidget = new MyQRadioButton
	  ( "Methfessel-Paxton",
	    model.udf.Common_Parameters.Calculation_Settings.Smearing,
	    this, SLOT(edit(const MyEvent&)), ID_PARAM );
	box->addWidget(swidget);
	vwidget.push_back(swidget);
      }
      {
	MyQRadioButton* swidget = new MyQRadioButton
	  ( "Fermi",
	    model.udf.Common_Parameters.Calculation_Settings.Smearing,
	    this, SLOT(edit(const MyEvent&)), ID_PARAM );
	box->addWidget(swidget);
	vwidget.push_back(swidget);
      }

      widget->setLayout(box);
      widget->setFixedWidth(250);
      layout->addWidget(widget);
      vwidget.push_back(widget);
    }



    // <XC_Type>
    {
      MyQGroupBox* widget = new MyQGroupBox("XC_Type");
      QGridLayout* box = new QGridLayout;
      int row=0,col=0;

      {
	MyQRadioButton* swidget = new MyQRadioButton
	  ( "LDA",
	    model.udf.Common_Parameters.Calculation_Settings.XC_Type,
	    this, SLOT(edit(const MyEvent&)), ID_PARAM );
	box->addWidget(swidget,row,col++);
	vwidget.push_back(swidget);
      }
      {
	MyQRadioButton* swidget = new MyQRadioButton
	  ( "PBE",
	    model.udf.Common_Parameters.Calculation_Settings.XC_Type,
	    this, SLOT(edit(const MyEvent&)), ID_PARAM );
	box->addWidget(swidget,row,col++);
	vwidget.push_back(swidget);
      }
      row++,col=0;
      {
	MyQRadioButton* swidget = new MyQRadioButton
	  ( "PBEsol",
	    model.udf.Common_Parameters.Calculation_Settings.XC_Type,
	    this, SLOT(edit(const MyEvent&)), ID_PARAM );
	box->addWidget(swidget,row,col++);
	vwidget.push_back(swidget);
      }
      {
	MyQRadioButton* swidget = new MyQRadioButton
	  ( "PW91",
	    model.udf.Common_Parameters.Calculation_Settings.XC_Type,
	    this, SLOT(edit(const MyEvent&)), ID_PARAM );
	box->addWidget(swidget,row,col++);
	vwidget.push_back(swidget);
      }
      row++,col=0;
      {
	MyQRadioButton* swidget = new MyQRadioButton
	  ( "PBE0",
	    model.udf.Common_Parameters.Calculation_Settings.XC_Type,
	    this, SLOT(edit(const MyEvent&)), ID_PARAM );
	box->addWidget(swidget,row,col++);
	vwidget.push_back(swidget);
      }
      {
	MyQRadioButton* swidget = new MyQRadioButton
	  ( "HF",
	    model.udf.Common_Parameters.Calculation_Settings.XC_Type,
	    this, SLOT(edit(const MyEvent&)), ID_PARAM );
	box->addWidget(swidget,row,col++);
	vwidget.push_back(swidget);
      }
      row++,col=0;
      widget->setLayout(box);
      widget->setFixedWidth(250);
      layout->addWidget(widget);
      vwidget.push_back(widget);
    }

    hlayout->addLayout(layout);
    hlayout->setAlignment(layout,Qt::AlignTop);
  }

  setLayout(hlayout);
}

void QTUDF::edit( const MyEvent& ev )
{
  switch(ev.id){
  case ID_TYPE : {
    model.udf.updateType();
    emit changed(MyEvent(id));
  } break;

  case ID_ACCURACY : {
    model.udf.updateAccuracy();
    emit changed(MyEvent(id));
  } break;

  case ID_SPIN : {
    model.udf.updateAtom();
    emit changed(MyEvent(id));
  } break;

  case ID_KPOINT : {
    model.udf.updateKPoint();
    emit changed(MyEvent(id));
  } break;

  case ID_PARAM : {
    emit changed(MyEvent(id));
  } break;
  default: break;
  }
}

void QTUDF::update( void )
{
  for( int i=0; i<(int)vwidget.size(); i++ ){
    vwidget[i]->update();
  }
}
