/*
 Copyright (c) 2014 Shinji Tsuneyuki
 This file is distributed under the terms of the GNU General Public License version 3.
 */

/*!
 \file dtcell.h
 \brief �i�q�̒P�ʖE�f�[�^�̃N���X
*/

#ifndef __DTCELL_H_INCLUDED
#define __DTCELL_H_INCLUDED

#include <vector>
using namespace std;

#include <QtCore/QString>
#include "position.h"

#ifndef M_SQRT3
const double M_SQRT3 = sqrt(3.0);
#endif

struct BrillouinPlane
{
  Position normal;
  double distance;
public:
  BrillouinPlane( void );
  BrillouinPlane( const Position& normal );
  double equation( const Position& position ) const;
};

struct BrillouinSegment
{
  QString   labelL;
  QString   labelPs;
  Position positions;
  QString   labelPe;
  Position positione;
  Position positionc;
  bool     cutted;
  int      npoint;
public:
  BrillouinSegment( void );
  BrillouinSegment( const QString& labelL,
		    const QString& labelPs,
		    const double xs, const double ys, const double zs,
		    const QString& labelPe,
		    const double xe, const double ye, const double ze );
  BrillouinSegment( const Position& positions,
		    const Position& positione );
  bool cut( const BrillouinPlane& plane );
  BrillouinSegment reverse( void ) const;

  static bool match( const BrillouinSegment& segment1, const BrillouinSegment& segment2 );
  static bool find( const vector<BrillouinSegment>& vs, const BrillouinSegment& s );
};


struct BrillouinFacet
{
  vector<BrillouinSegment> vsegment;
  BrillouinSegment          segmentc;
  bool                      cutted;
public:
  BrillouinFacet( const Position& position0,
		  const Position& position1,
		  const Position& position2,
		  const Position& position3 );
  BrillouinFacet( const vector<BrillouinSegment>& vs );
  bool cut( const BrillouinPlane& plane );
  void order( void );
};

struct BrillouinPoint
{
  QString  label;
  Position position;

  BrillouinPoint( void ){
    this->label = "G";
    this->position = Position(0.0,0.0,0.0);
  }
  BrillouinPoint( const Position& position ){
    this->label = "";
    this->position = position;
  }
  BrillouinPoint( const QString& label, const Position& position ){
    this->label = label;
    this->position = position;
  }
};


// �P�ʖE�̌`��Ɋւ���f�[�^��ێ�����N���X
class DTCell
{
public:
  struct Bravais{
    QString shape;
    QString center;
    QString subtype;
  } bravais;
  struct KPathDefaults
  {
    QString shape, center, subtype;
    vector<BrillouinSegment> kpath;
  };
  vector<KPathDefaults> kpath_defaults;

  double   length;
  Position Ea, Eb, Ec;
  Position La, Lb, Lc, Lo;
  Position Ka, Kb, Kc;
  Position La_conv, Lb_conv, Lc_conv;
  Position Ka_conv, Kb_conv, Kc_conv;
  double   V;

  static double length_min, length_max;
  static double E_min, E_max;

  vector<BrillouinPlane>   vplane;
  vector<BrillouinFacet>   vfacet;
  vector<BrillouinSegment> vsymmL;

  int                      nsymmK;
  vector<BrillouinPoint>   vsymmK;

  int                      nsampK[3];
  int                      ssampK[3];
  vector<BrillouinPoint>   vsampK;


public:
  DTCell( void );

  void clear( void );

  Position getPosition( const Coordinates& q ) const;
  Position getPositionLocal( const Coordinates& q ) const;
  Coordinates getCoordinates( const Position& p ) const;
  Coordinates getCoordinatesLocal( const Position& p ) const;
  Coordinates getCoordinatesNormalized( const Position& p ) const;
  Coordinates getCoordinatesLocalNormalized( const Position& p ) const;

public:
  void update( void );

private:
  void loadKPathDefaults( void );
  void checkBravais( void );
  void constructBrillouin( void );
  void setupKPoints( void );
  void setupKPathDefault( void );
};

#endif // __DTCELL_H_INCLUDED
