/*
 Copyright (c) 2014 Shinji Tsuneyuki
 This file is distributed under the terms of the GNU General Public License version 3.
 */

/*!
 \file dtmodel.h
 \brief �f�[�^�̓����N���X
*/

#ifndef __DTMODEL_H_INCLUDED
#define __DTMODEL_H_INCLUDED

#include <QtGui/QtGui>
#include "dtlattice.h"
#include "dtudf.h"
#include "dtxtapp.h"
#include "dtvasp.h"
#include "dtopenmx.h"
#include "dtrsdft.h"
#include "gloption.h"

class DTModel : public QWidget
{
  Q_OBJECT

public:
  DTLattice    lattice;
  DTUDF        udf;
  DTXTapp      xtapp;
  DTVasp       vasp;
  DTOpenMX     openmx;
  DTRSDFT      rsdft;
  GLOption     gloption;

public:
  DTModel( void );

signals:
  void changed( void );
public slots:
  void update( void );

public:
  void clear( void );

  QString guess( const QString& fname );

  bool loadXYZ( const QString& fname );
  bool loadCIF( const QString& fname );

  bool loadUDF( const QString& fname );
  bool loadXTAPP( const QString& fname );
  bool loadVASP( const QString& fname );
  bool loadOpenMX( const QString& fname );
  bool loadRSDFT( const QString& fname );

  bool saveUDF( const QString& fname );
  bool saveXTAPP( const QString& fname );
  bool saveVASP( const QString& fname );
  bool saveOpenMX( const QString& fname );
  bool saveRSDFT( const QString& fname );

  bool convert( const QString& informat, const QString& infile,
		const QString& outformat, const QString& outfile );

  double getScale( void ) const;

  static bool loadDefaults( void );
};

QString getDirName( const QString& path );
QString getFileName( const QString& path );

#endif
