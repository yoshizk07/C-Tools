/*
 Copyright (c) 2014 Shinji Tsuneyuki
 This file is distributed under the terms of the GNU General Public License version 3.
 */

/*!
 \file qtunitlattice.h
 \brief ���i�q�̒P�ʖE��GUI�\���̃N���X
*/

#ifndef __QTUNITLATTICE_H_INCLUDED
#define __QTUNITLATTICE_H_INCLUDED

#include "qtwidgets.h"

class DTModel;

class QTUnitLattice : public MyQTab
{
  Q_OBJECT

private:
  DTModel& model;
  QTableWidget* table;
  MyQPushButton* pb_delete;
  MyQPushButton* pb_append;

  enum { ID_UNIT, ID_VECTOR, ID_DELETE, ID_APPEND };

public:
  QTUnitLattice( DTModel& _model, const int id );
signals:
  void changed(const MyEvent&);
public slots:
  void update( void );
private slots:
  void edit( const MyEvent& ev );
  void itemSelected( void );
  void itemEdited( QTableWidgetItem* item );
};

#endif // __QTUNITLATTICE_H_INCLUDED
