/*
 Copyright (c) 2014 Shinji Tsuneyuki
 This file is distributed under the terms of the GNU General Public License version 3.
 */

/*!
 \file qtbrillouin.cc
 \brief �u�����A���]�[����GUI�\���̃N���X
*/

#include "qtrecplattice.h"
#include "dtmodel.h"
#include "glrecplattice.h"
#include "qtmisc.h"

QTRecpLattice::QTRecpLattice( DTModel& _model, const int id ) : MyQTab(id), model(_model)
{
  QHBoxLayout* layout = new QHBoxLayout(this);
  //  layout->setSizeConstraint( QLayout::SetFixedSize );

  {
    QGroupBox* group = new QGroupBox("reciprocal space view");
    QVBoxLayout* box = new QVBoxLayout;

    {
      GLRecpLattice* widget = new GLRecpLattice(model);
      box->addWidget(widget);
    }

    group->setLayout(box);
    layout->addWidget(group);
  }

  {
    QGroupBox* group = new QGroupBox("reciprocal space parameters");
    QVBoxLayout* box = new QVBoxLayout;

    {
      MyQGroupBox* sgroup = new MyQGroupBox("sampling K points");
      QGridLayout* grid = new QGridLayout;
      int row=0,col=0;

      grid->addWidget(new QLabel("Nkx:"),row,col++);
      {
	MyQSpinBox* swidget = new MyQSpinBox
	  ( model.lattice.cell.nsampK[0], 0, 100,
	    this, SLOT(edit(const MyEvent&)), ID_NUMBER );
	swidget->setFixedWidth(50);
	swidget->setEnabled(false);
	vwidget.push_back(swidget);
	grid->addWidget(swidget,row,col++);
      }
      grid->addWidget(new QLabel("Nky:"),row,col++);
      {
	MyQSpinBox* swidget = new MyQSpinBox
	  ( model.lattice.cell.nsampK[1], 0, 100,
	    this, SLOT(edit(const MyEvent&)), ID_NUMBER );
	swidget->setFixedWidth(50);
	swidget->setEnabled(false);
	vwidget.push_back(swidget);
	grid->addWidget(swidget,row,col++);
      }
      grid->addWidget(new QLabel("Nkz:"),row,col++);
      {
	MyQSpinBox* swidget = new MyQSpinBox
	  ( model.lattice.cell.nsampK[2], 0, 100,
	    this, SLOT(edit(const MyEvent&)), ID_NUMBER );
	swidget->setFixedWidth(50);
	swidget->setEnabled(false);
	vwidget.push_back(swidget);
	grid->addWidget(swidget,row,col++);
      }
      row++,col=0;

      /*
      grid->addWidget(new QLabel("Skx:"),row,col++);
      {
	MyQSpinBox* swidget = new MyQSpinBox
	  ( model.lattice.cell.ssampK[0], 0, 1,
	    this, SLOT(edit(const MyEvent&)), ID_NUMBER );
	swidget->setFixedWidth(50);
	vwidget.push_back(swidget);
	grid->addWidget(swidget,row,col++);
      }
      grid->addWidget(new QLabel("Sky:"),row,col++);
      {
	MyQSpinBox* swidget = new MyQSpinBox
	  ( model.lattice.cell.ssampK[1], 0, 1,
	    this, SLOT(edit(const MyEvent&)), ID_NUMBER );
	swidget->setFixedWidth(50);
	vwidget.push_back(swidget);
	grid->addWidget(swidget,row,col++);
      }
      grid->addWidget(new QLabel("Skz:"),row,col++);
      {
	MyQSpinBox* swidget = new MyQSpinBox
	  ( model.lattice.cell.ssampK[2], 0, 1,
	    this, SLOT(edit(const MyEvent&)), ID_NUMBER );
	swidget->setFixedWidth(50);
	vwidget.push_back(swidget);
	grid->addWidget(swidget,row,col++);
      }
      row++,col=0;
      */

      sgroup->setLayout(grid);
      box->addWidget(sgroup);
    }

    {
      MyQGroupBox* sgroup = new MyQGroupBox("symmetric K points");
      QGridLayout* grid = new QGridLayout;
      int row=0,col=0;

      grid->addWidget(new QLabel("total:"),row,col++);
      {
	MyQSpinBox* swidget = new MyQSpinBox
	  ( model.lattice.cell.nsymmK, 0, 1000,
	    this, SLOT(edit(const MyEvent&)), ID_NUMBER );
	swidget->setFixedWidth(50);
	swidget->setEnabled(false);
	vwidget.push_back(swidget);
	grid->addWidget(swidget,row,col++);
      }
      row++,col=0;

      grid->addWidget(new QLabel("symmetric lines"),row,col++,1,2);
      row++,col=0;

      {
	// Label, kx, ky, kz
	table = new QTableWidget( 0, 5, this );
	table->setFixedWidth(300);
	table->setMinimumHeight(300);
	//      table->setSelectionMode( QAbstractItemView::NoSelection );
	table->setSelectionBehavior( QAbstractItemView::SelectRows );

	int column=0;
	table->setHorizontalHeaderItem(column,new QTableWidgetItem("P"));
	table->setColumnWidth(column++,35);
	table->setHorizontalHeaderItem(column,new QTableWidgetItem("ka"));
	table->setColumnWidth(column++,55);
	table->setHorizontalHeaderItem(column,new QTableWidgetItem("kb"));
	table->setColumnWidth(column++,55);
	table->setHorizontalHeaderItem(column,new QTableWidgetItem("kc"));
	table->setColumnWidth(column++,55);
	table->setHorizontalHeaderItem(column,new QTableWidgetItem("L"));
	table->setColumnWidth(column++,70);

	grid->addWidget(table,row,col++,1,2);
      }
      sgroup->setLayout(grid);
      box->addWidget(sgroup);
    }

    group->setLayout(box);
    layout->addWidget(group);
    layout->setAlignment(group,Qt::AlignTop);
  }

  setLayout(layout);

  update();
}

void QTRecpLattice::edit( const MyEvent& ev )
{
  switch(ev.id){
  case ID_NUMBER : {
  } break;
  default : break;
  }

  emit changed(MyEvent(id));
}

void QTRecpLattice::update( void )
{
  char value[8];
  const vector<BrillouinSegment>& vsymmL = model.lattice.cell.vsymmL;

  table->blockSignals(true);

  table->clearContents();

  table->setRowCount(vsymmL.size()+1);

  int row=0;
  for( int i=0; i<(int)vsymmL.size(); i++ ){
    const BrillouinSegment& symmL = vsymmL[i];

    int column=0;
    { // point
      QTableWidgetItem* item = new QTableWidgetItem;
      item->setText( tr("%1").arg(symmL.labelPs) );
      item->setFlags( Qt::NoItemFlags );
      table->setItem(row,column++,item);
    }
    { // ka
      QTableWidgetItem* item = new QTableWidgetItem;
      sprintf(value,"%5.3f",symmL.positions.a);
      item->setText( tr("%1").arg(value) );
      item->setFlags( Qt::NoItemFlags );
      table->setItem(row,column++,item);
    }
    { // kb
      QTableWidgetItem* item = new QTableWidgetItem;
      sprintf(value,"%5.3f",symmL.positions.b);
      item->setText( tr("%1").arg(value) );
      item->setFlags( Qt::NoItemFlags );
      table->setItem(row,column++,item);
    }
    { // kc
      QTableWidgetItem* item = new QTableWidgetItem;
      sprintf(value,"%5.3f",symmL.positions.c);
      item->setText( tr("%1").arg(value) );
      item->setFlags( Qt::NoItemFlags );
      table->setItem(row,column++,item);
    }
    { // line
      QTableWidgetItem* item = new QTableWidgetItem;
      item->setText( tr("%1").arg(symmL.labelL) );
      item->setFlags( Qt::NoItemFlags );
      table->setItem(row,column++,item);
    }
    row++;
  }

  // the end point of the last segment
  if( !vsymmL.empty() ){
    const BrillouinSegment& symmL = vsymmL.back();

    int column=0;
    { // name
      QTableWidgetItem* item = new QTableWidgetItem;
      item->setText( tr("%1").arg(symmL.labelPe) );
      item->setFlags( Qt::NoItemFlags );
      table->setItem(row,column++,item);
    }
    { // ka
      QTableWidgetItem* item = new QTableWidgetItem;
      sprintf(value,"%5.3f",symmL.positione.a);
      item->setText( tr("%1").arg(value) );
      item->setFlags( Qt::NoItemFlags );
      table->setItem(row,column++,item);
    }
    { // kb
      QTableWidgetItem* item = new QTableWidgetItem;
      sprintf(value,"%5.3f",symmL.positione.b);
      item->setText( tr("%1").arg(value) );
      item->setFlags( Qt::NoItemFlags );
      table->setItem(row,column++,item);
    }
    { // kc
      QTableWidgetItem* item = new QTableWidgetItem;
      sprintf(value,"%5.3f",symmL.positione.c);
      item->setText( tr("%1").arg(value) );
      item->setFlags( Qt::NoItemFlags );
      table->setItem(row,column++,item);
    }
    { // line
      QTableWidgetItem* item = new QTableWidgetItem;
      item->setText( tr("%1").arg("") );
      item->setFlags( Qt::NoItemFlags );
      table->setItem(row,column++,item);
    }
    row++;
  }
  table->blockSignals(false);

  for( int i=0; i<(int)vwidget.size(); i++ ){
    vwidget[i]->update();
  }
}

