/*
 Copyright (c) 2014 Shinji Tsuneyuki
 This file is distributed under the terms of the GNU General Public License version 3.
 */

/*!
 \file glatoms.cc
 \brief �i�q�̌��q��GL�\���̃N���X
*/

#include <QtOpenGL/QGLWidget>
#include "dtmodel.h"
#include "glatoms.h"

void GLAtoms::update( void )
{
  const Position& Lo = model.lattice.cell.Lo;
  const vector<DTAtom>& vatom = model.lattice.getAtoms();

  GLBase::beginNewList();

  glPushMatrix();
  glTranslated( Lo.x, Lo.y, Lo.z );

  glPushName(GLuint(-1));
  for( int n=0; n<(int)vatom.size(); n++ ){
    glLoadName(n);
    makeAtom( vatom[n] );
  }
  glLoadName(GLuint(-1));

  if( model.lattice.molecule.isSelected() ){
    const int iatom = model.lattice.molecule.getSelected();
    makeAtomSelected( vatom[iatom] );
  }

  glPopMatrix();

  GLBase::endNewList();
}

void GLAtoms::makeAtom( const DTAtom& atom )
{
  const int  number = atom.number;
  const Position pos = model.lattice.cell.getPositionLocal(atom.coords);

  const GLOption::Lattice::Atom::byElement& element = model.gloption.lattice.atom.element(number);
  const double& radius = element.radius;
  const GLcolor& color = element.color;
  const double& scale  = model.gloption.lattice.atom.scale;
  const int     slices = (int)model.gloption.lattice.atom.slices;

  const bool&   points = model.gloption.lattice.atom.points;

  glColor4dv(color);
  glMaterialdv( GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, color );

  if( points ){
    glDisable( GL_LIGHTING );
    glPointSize(scale*32.0*radius);
    glBegin( GL_POINTS );
    glVertex3dv(pos);
    glEnd();
    glPointSize(1.0);
    glEnable( GL_LIGHTING );
  }
  else{
    gluSolidBall( scale*radius, pos, slices );
  }
}

void GLAtoms::makeAtomSelected( const DTAtom& atom )
{
  const int  number = atom.number;
  const Position pos = model.lattice.cell.getPositionLocal(atom.coords);

  const GLOption::Lattice::Atom::byElement& element = model.gloption.lattice.atom.element(number);
  const double& radius = element.radius;
  const GLcolor& color = model.gloption.lattice.atom.color_selected;
  const double& scale  = model.gloption.lattice.atom.scale;

  glColor4dv( color );
  glDisable( GL_LIGHTING );
  gluWireCube( scale*2*radius, pos );
  glEnable( GL_LIGHTING );
}

