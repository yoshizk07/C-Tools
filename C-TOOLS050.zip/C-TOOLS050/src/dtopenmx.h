/*
 Copyright (c) 2014 Shinji Tsuneyuki
 This file is distributed under the terms of the GNU General Public License version 3.
 */

#ifndef __DTOPENMX_H_INCLUDED
#define __DTOPENMX_H_INCLUDED

#include <QtCore/QString>
#include "position.h"
#include "dtatoms.h"
#include "table.h"

#include <vector>
using namespace std;

struct DTOpenMX
{
  struct AtomicSpecies {
    struct Element {
      QString name;
      QString pao;
      QString mode;
      QString vps;
      Element( void ){
      }
      Element( const QString& name ){
	this->name = name;
      }
      Element( const QString& name,
	       const QString& pao,
	       const QString& mode,
	       const QString& vps ){
	this->name = name;
	this->pao  = pao;
	this->mode = mode;
	this->vps  = vps;
      }
    };
    static vector<Element> velement[3];
  } AtomicSpecies;

  struct AtomicPositions {
    vector<DTAtom> vatom;
  } AtomicPositions;

  struct UnitVectors {
    Position lattice_list[3];
  } UnitVectors;

  struct scf {
    QString XcType;
    bool SpinPolarization;
    bool restart;
    double energycutoff;
    static Table energycutoff_def;
    int maxIter;
    static Table maxIter_def;
    int Kgrid[3];
    QString Mixing_Type;
    double Max_Mixing_Weight;
    static Table Max_Mixing_Weight_def;
    double criterion;
    static Table criterion_def;
  } scf;

  struct MD {
    QString Type;
    int maxIter;
    double Opt_criterion;
    static Table Opt_criterion_def;
  } MD;

  struct Band {
    bool dispersion;
  } Band;

  struct Dos {
    bool fileout;
    int Kgrid[3];
  } Dos;

  DTOpenMX( void );
  ~DTOpenMX( void );

  void clear( void );
  QString guess( const QString& fname );
  bool load( const QString& fname );
  bool save( const DTLattice& lattice, const QString& fname ) const;

  static bool loadDefaults( void );
};

#endif // __DTOPENMX_H_INCLUDED
