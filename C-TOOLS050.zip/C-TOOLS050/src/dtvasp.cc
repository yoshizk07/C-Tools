/*
 Copyright (c) 2014 Shinji Tsuneyuki
 This file is distributed under the terms of the GNU General Public License version 3.
 */

#include "dtmodel.h"
#include "dtlattice.h"
#include "dtvasp.h"
#include "qtxml.h"
#include "qtexception.h"
#include "symbol.h"
#include <algorithm>


QString DTVasp::INCAR::SYSTEM_def = "";
QString DTVasp::INCAR::GGA_def = "";

Table   DTVasp::INCAR::AMIX_def( 0.4, 0.3, 0.2, 0.1, 0.9 );
Table   DTVasp::INCAR::NELM_def( 50, 60, 80, 30, 100 );
Table   DTVasp::INCAR::EDIFF_def( 1.0e-2, 1.0e-4, 1.0e-6, 1.0e-8, 1.0e-0 );
Table   DTVasp::INCAR::EDIFFG_def( 1.0e-1, 1.0e-2, 1.0e-3, 1.0e-4, 1.0e-0 );


double  DTVasp::INCAR::AEXX_def = 0.0;
double  DTVasp::INCAR::AGGAC_def = 1.0;
double  DTVasp::INCAR::ALDAC_def = 1.0;
double  DTVasp::INCAR::SIGMA_def = 0.2;
int     DTVasp::INCAR::ICHARG_def = 0;
int     DTVasp::INCAR::ISMEAR_def = 1;
int     DTVasp::INCAR::ISPIN_def = 1;
int     DTVasp::INCAR::ISTART_def = 0;
int     DTVasp::INCAR::ISYM_def = 1;
int     DTVasp::INCAR::NBANDS_def = 0;
int     DTVasp::INCAR::NSW_def = 0;
bool    DTVasp::INCAR::LHFCAL_def = false;

void DTVasp::clear( void )
{
  INCAR.SYSTEM = INCAR::SYSTEM_def;
  INCAR.GGA = INCAR::GGA_def;

  INCAR.PREC   = "Normal";
  INCAR.AMIX   = INCAR::AMIX_def.getDefault("Normal");
  INCAR.NELM   = INCAR::NELM_def.getDefault("Normal");
  INCAR.EDIFF  = INCAR::EDIFF_def.getDefault("Normal");
  INCAR.EDIFFG = INCAR::EDIFFG_def.getDefault("Normal");

  INCAR.AEXX   = INCAR::AEXX_def;
  INCAR.AGGAC  = INCAR::AGGAC_def;
  INCAR.ALDAC  = INCAR::ALDAC_def;
  INCAR.SIGMA  = INCAR::SIGMA_def;
  INCAR.ICHARG = INCAR::ICHARG_def;
  INCAR.ISMEAR = INCAR::ISMEAR_def;
  INCAR.ISPIN  = INCAR::ISPIN_def;
  INCAR.ISTART = INCAR::ISTART_def;
  INCAR.ISYM   = INCAR::ISYM_def;
  INCAR.NBANDS = INCAR::NBANDS_def;


  INCAR.NSW = INCAR::NSW_def;
  INCAR.LHFCAL = INCAR::LHFCAL_def;

  POSCAR.lattice_factor = 1.0;
  POSCAR.lattice_list[0] = Position(1.0,0.0,0.0);
  POSCAR.lattice_list[1] = Position(0.0,1.0,0.0);
  POSCAR.lattice_list[2] = Position(0.0,0.0,1.0);
  POSCAR.atom.clear();

  KPOINT.nkmesh[0] = 0;
  KPOINT.nkmesh[1] = 0;
  KPOINT.nkmesh[2] = 0;
  KPOINT.number_band_traced = 0;
}

QString DTVasp::guess( const QString& fname )
{
  if( !fname.endsWith( "INCAR" ) ) return "";

  FILE* fptr = fopen( getDirName(fname)+"/INCAR", "rb" );
  if( fptr == NULL ){
    return "";
  }

  char buf[256];
  char svalue[32];

  bool match = false;

  while( fgets(buf,sizeof(buf),fptr) ){
    if( 1 == sscanf(buf," %s", svalue ) &&
	QString(svalue) == "SYSTEM" ){
      match = true;
      break;
    }
  }

  fclose(fptr);

  if( match ){
    return "solver vasp format";
  }

  return "";
}

bool DTVasp::load( const QString& fname )
{
  FILE* fptr = NULL;

  clear();

  try{
    char buf[1024];
    QString fname2 = getDirName(fname)+"/INCAR";

    fptr = fopen( fname2, "r" );
    if( fptr == NULL ){
      throw MyException("can not open a VASP file.", fname2 );
    }

    while(fgets(buf,sizeof(buf),fptr)){
      if( buf[0] == '#' ) continue;

      if( false );
      else if( 1 == XML::sscanf( buf, " SYSTEM = %s", &INCAR.SYSTEM ) );
      else if( 1 == XML::sscanf( buf, " PREC = %s", &INCAR.PREC ) );
      else if( 1 == XML::sscanf( buf, " GGA = %s", &INCAR.GGA ) );
      else if( 1 == XML::sscanf( buf, " AEXX = %lf", &INCAR.AEXX ) );
      else if( 1 == XML::sscanf( buf, " AGGAC = %lf", &INCAR.AGGAC ) );
      else if( 1 == XML::sscanf( buf, " ALDAC = %lf", &INCAR.ALDAC ) );
      else if( 1 == XML::sscanf( buf, " AMIX = %lf", &INCAR.AMIX ) );
      else if( 1 == XML::sscanf( buf, " EDIFF = %lf", &INCAR.EDIFF ) );
      else if( 1 == XML::sscanf( buf, " EDIFFG = %lf", &INCAR.EDIFFG ) ){
	if( INCAR.EDIFFG<0.0 ) INCAR.EDIFFG *= -1.0;
      }
      else if( 1 == XML::sscanf( buf, " SIGMA = %lf", &INCAR.SIGMA ) );
      else if( 1 == XML::sscanf( buf, " ICHARG = %d", &INCAR.ICHARG ) );
      else if( 1 == XML::sscanf( buf, " ISMEAR = %d", &INCAR.ISMEAR ) );
      else if( 1 == XML::sscanf( buf, " ISPIN = %d", &INCAR.ISPIN ) );
      else if( 1 == XML::sscanf( buf, " ISTART = %d", &INCAR.ISTART ) );
      else if( 1 == XML::sscanf( buf, " ISYM = %d", &INCAR.ISYM ) );
      else if( 1 == XML::sscanf( buf, " NBANDS = %d", &INCAR.NBANDS ) );
      else if( 1 == XML::sscanf( buf, " NELM = %d", &INCAR.NELM ) );
      else if( 1 == XML::sscanf( buf, " NSW = %d", &INCAR.NSW ) );
      else if( 1 == XML::sscanf( buf, " LHFCAL = %s", &INCAR.LHFCAL ) );
    }

    fclose(fptr);
  }
  catch( const MyException& e ){
    MyException::critical(e);
    if(fptr) fclose(fptr);
    return false;
  }

  try{
    char buf[1024],str[32];

    fptr = fopen( getDirName(fname)+"/POSCAR", "r" );

    if( fptr == NULL ){
      throw MyException("can not open a VASP file.",fname);
    }

    fgets(buf,sizeof(buf),fptr); // comment
    fgets(buf,sizeof(buf),fptr); // lattice_factor
    if( 1 != sscanf(buf,"%lf",&POSCAR.lattice_factor) ){
      throw MyException("broken lattice_factor.");
    }
    fgets(buf,sizeof(buf),fptr); // lattice_list
    if( 3 != sscanf(buf,"%lf %lf %lf",
		  &POSCAR.lattice_list[0].x,
		  &POSCAR.lattice_list[0].y,
		  &POSCAR.lattice_list[0].z ) ){
      throw MyException("broken lattice_list.");
    }
    fgets(buf,sizeof(buf),fptr); // lattice_list
    if( 3 != sscanf(buf,"%lf %lf %lf",
		  &POSCAR.lattice_list[1].x,
		  &POSCAR.lattice_list[1].y,
		  &POSCAR.lattice_list[1].z ) ){
      throw MyException("broken lattice_list.");
    }
    fgets(buf,sizeof(buf),fptr); // lattice_list
    if( 3 != sscanf(buf,"%lf %lf %lf",
		  &POSCAR.lattice_list[2].x,
		  &POSCAR.lattice_list[2].y,
		  &POSCAR.lattice_list[2].z ) ){
      throw MyException("broken lattice_list.");
    }

    vector<QString> vname;
    vector<int>   vnumber;
    vector<int>     vsize;
    fgets(buf,sizeof(buf),fptr); // names
    {
      char* ptr = buf;
      char  name[32];
      int   len=0;
      while( 1 == sscanf(ptr,"%s%n", name, &len ) ){
	vname.push_back(QString(name));
	int number = ElementSymbol::getAtomicNumber(name);
	vnumber.push_back(number);
	ptr+=len;
      }
    }

    fgets(buf,sizeof(buf),fptr); // sizes
    {
      char* ptr = buf;
      int   size;
      int   len=0;
      while( 1 == sscanf(ptr,"%d%n", &size, &len ) ){
	vsize.push_back(size);
	ptr+=len;
      }
    }

    if( vname.size() != vsize.size() ){
      throw MyException("broken element.");
    }

    fgets(buf,sizeof(buf),fptr); // only Direct is acceptable
    sscanf(buf,"%s",str);
    if( QString(str) == "Direct" ){
      for( int ie=0; ie<(int)vsize.size(); ie++ ){
	for( int ia=0; ia<vsize[ie]; ia++ ){
	  fgets(buf,sizeof(buf),fptr); // atoms

	  DTAtom atom;
	  if( 3 != sscanf(buf,"%lf %lf %lf",
			  &atom.coords.a,
			  &atom.coords.b,
			  &atom.coords.c ) ){
	    throw MyException("broken atom data.");
	  }
	  atom.name = vname[ie];
	  atom.number = vnumber[ie];
	  POSCAR.atom.push_back(atom);
	}
      }
    }
    else if( QString(str) == "Cartesian" ){
      const Position La = POSCAR.lattice_factor
	* POSCAR.lattice_list[0];
      const Position Lb = POSCAR.lattice_factor
	* POSCAR.lattice_list[1];
      const Position Lc = POSCAR.lattice_factor
	* POSCAR.lattice_list[2];

      Position Ka = Position::outer_product( Lb, Lc );
      Position Kb = Position::outer_product( Lc, La );
      Position Kc = Position::outer_product( La, Lb );

      double V = Position::outer_product( La, Lb ) * Lc;
      if ( V<0.0 ) V *= -1.0;
      Ka *= 1.0/V;
      Kb *= 1.0/V;
      Kc *= 1.0/V;

      for( int ie=0; ie<(int)vsize.size(); ie++ ){
	for( int ia=0; ia<vsize[ie]; ia++ ){
	  fgets(buf,sizeof(buf),fptr); // atoms

	  DTAtom atom;
	  Position r;
	  if( 3 != sscanf(buf,"%lf %lf %lf",
			  &r.x,
			  &r.y,
			  &r.z ) ){
	    throw MyException("broken atom data.");
	  }
	  atom.name = vname[ie];
	  atom.number = vnumber[ie];
	  atom.coords.a = Ka*r;
	  atom.coords.b = Kb*r;
	  atom.coords.c = Kc*r;
	  POSCAR.atom.push_back(atom);
	}
      }
    }
    else{
      throw MyException("broken atom header.");
    }
    fclose(fptr);
  }
  catch( const MyException& e ){
    MyException::critical(e);
    if(fptr) fclose(fptr);
    return false;
  }


  try{
    char buf[1024];

    fptr = fopen( getDirName(fname)+"/KPOINTS", "r" );
    if( fptr == NULL ){
      throw MyException("can not open a VASP file.",fname);
    }

    // energy and optimize
    fgets(buf,sizeof(buf),fptr); // comment
    fgets(buf,sizeof(buf),fptr); // number of symmetric kpoints
    KPOINT.number_band_traced=0;
    KPOINT.nkmesh[0]=0;
    KPOINT.nkmesh[1]=0;
    KPOINT.nkmesh[2]=0;
    if( sscanf(buf,"%d",&KPOINT.number_band_traced) &&
	KPOINT.number_band_traced>0 ){
      // band
    }
    else{
      fgets(buf,sizeof(buf),fptr); // Gamma
      fgets(buf,sizeof(buf),fptr); // Nx Ny Nz
      sscanf(buf, "%d %d %d\n",
	     &KPOINT.nkmesh[0],
	     &KPOINT.nkmesh[1],
	     &KPOINT.nkmesh[2] );
    }

    fclose(fptr);
  }
  catch( const MyException& e ){
    MyException::critical(e);
    if(fptr) fclose(fptr);
    return false;
  }

  return true;
}

bool DTVasp::save( const DTLattice& lattice, const QString& fname ) const
{
  FILE* fptr = NULL;
  QString fname2 = getDirName(fname)+"/INCAR";

  try{
    fptr = fopen( fname2, "w" );
    if( fptr == NULL ){
      throw MyException("can not create a VASP file.",fname2);
    }

    fprintf( fptr, " SYSTEM = %s\n", INCAR.SYSTEM == "" ? qPrintable(getFileName(fname)) : qPrintable(INCAR.SYSTEM));
    fprintf( fptr, " PREC = %s\n", qPrintable(INCAR.PREC) );
    if( INCAR.GGA != INCAR::GGA_def ){
      fprintf( fptr, " GGA = %s\n", qPrintable(INCAR.GGA) );
    }
    if( INCAR.AEXX != INCAR::AEXX_def ){
      fprintf( fptr, " AEXX = %lf\n", INCAR.AEXX );
    }
    if( INCAR.AGGAC != INCAR::AGGAC_def ){
      fprintf( fptr, " AGGAC = %lf\n", INCAR.AGGAC );
    }
    if( INCAR.ALDAC != INCAR::ALDAC_def ){
      fprintf( fptr, " ALDAC = %lf\n", INCAR.ALDAC );
    }
    {
      fprintf( fptr, " AMIX = %lf\n", INCAR.AMIX );
    }
    {
      fprintf( fptr, " EDIFF = %e\n", INCAR.EDIFF );
    }
    {
      fprintf( fptr, " EDIFFG = %e\n", INCAR.EDIFFG*(-1.0) );
    }
    if( INCAR.SIGMA != INCAR::SIGMA_def ){
      fprintf( fptr, " SIGMA = %lf\n", INCAR.SIGMA );
    }
    if( INCAR.ICHARG != INCAR::ICHARG_def ){
      fprintf( fptr, " ICHARG = %d\n", INCAR.ICHARG );
    }
    if( INCAR.ISMEAR != INCAR::ISMEAR_def ){
      fprintf( fptr, " ISMEAR = %d\n", INCAR.ISMEAR );
    }
    if( INCAR.ISPIN != INCAR::ISPIN_def ){
      fprintf( fptr, " ISPIN = %d\n", INCAR.ISPIN );
    }
    if( INCAR.ISTART != INCAR::ISTART_def ){
      fprintf( fptr, " ISTART = %d\n", INCAR.ISTART );
    }
    if( INCAR.ISYM != INCAR::ISYM_def ){
      fprintf( fptr, " ISYM = %d\n", INCAR.ISYM );
    }
    if( INCAR.NBANDS != INCAR::NBANDS_def ){
      fprintf( fptr, " NBANDS = %d\n", INCAR.NBANDS );
    }
    {
      fprintf( fptr, " NELM = %d\n", INCAR.NELM );
    }
    if( INCAR.NSW != INCAR::NSW_def ){
      fprintf( fptr, " NSW = %d\n", INCAR.NSW );
    }
    if( INCAR.LHFCAL != INCAR::LHFCAL_def ){
      fprintf( fptr, " LHFCAL = %s\n", INCAR.LHFCAL ? ".TRUE." : ".FALSE." );
    }
    if( INCAR.NSW != 0 ){
      fprintf( fptr, " IBRION = 1\n");
      fprintf( fptr, " ISIF = 2\n");
    }

    fclose(fptr);
  }
  catch( const MyException& e ){
    MyException::critical(e);
    if(fptr) fclose(fptr);
    return false;
  }

  try{
    fptr = fopen( getDirName(fname)+"/POSCAR", "w" );
    if( fptr == NULL ){
      throw MyException("can not create a VASP file.",fname);
    }

    vector<QString> vname;
    vector<int>     vsize;
    
    for( int ia=0; ia<(int)POSCAR.atom.size(); ia++ ){
      const QString& name = POSCAR.atom[ia].name;
      if( std::find( vname.begin(), vname.end(), name ) == vname.end() ){
	vname.push_back(name);
	vsize.push_back(0);
      }
    }
    for( int ie=0; ie<(int)vsize.size(); ie++ ){
      for( int ia=0; ia<(int)POSCAR.atom.size(); ia++ ){
	if( vname[ie] == POSCAR.atom[ia].name ){
	  vsize[ie]++;
	}
      }
    }

    fprintf(fptr,"%s\n", qPrintable(INCAR.SYSTEM) );
    fprintf(fptr,"%12.6f\n", POSCAR.lattice_factor );
    fprintf(fptr,"%12.6f %12.6f %12.6f\n",
	    POSCAR.lattice_list[0].x,
	    POSCAR.lattice_list[0].y,
	    POSCAR.lattice_list[0].z );
    fprintf(fptr,"%12.6f %12.6f %12.6f\n",
	    POSCAR.lattice_list[1].x,
	    POSCAR.lattice_list[1].y,
	    POSCAR.lattice_list[1].z );
    fprintf(fptr,"%12.6f %12.6f %12.6f\n",
	    POSCAR.lattice_list[2].x,
	    POSCAR.lattice_list[2].y,
	    POSCAR.lattice_list[2].z );
    for( int ie=0; ie<(int)vname.size(); ie++ ){
      fprintf(fptr,"%5s", qPrintable(vname[ie]) );
    }
    fprintf(fptr,"\n");
    for( int ie=0; ie<(int)vsize.size(); ie++ ){
      fprintf(fptr,"%6d", vsize[ie] );
    }
    fprintf(fptr,"\n");

    fprintf(fptr,"Direct ! internal coordinates\n");
    for( int ia=0; ia<(int)POSCAR.atom.size(); ia++ ){
      fprintf(fptr,"%12.6f %12.6f %12.6f  ! %s\n",
	      POSCAR.atom[ia].coords.a,
	      POSCAR.atom[ia].coords.b,
	      POSCAR.atom[ia].coords.c,
	      qPrintable(POSCAR.atom[ia].name) );
    }

    fclose(fptr);
  }
  catch( const MyException& e ){
    MyException::critical(e);
    if(fptr) fclose(fptr);
    return false;
  }

  try{
    fptr = fopen( getDirName(fname)+"/KPOINTS", "w" );
    if( fptr == NULL ){
      throw MyException("can not create a VASP file.",fname);
    }

    // energy and optimize
    if( INCAR.ICHARG == 0 && KPOINT.number_band_traced == 0 ){
      fprintf(fptr,"sampling mesh\n");
      fprintf(fptr, "0\n");
      fprintf(fptr, "Gamma\n");
      fprintf(fptr, "%2d %2d %2d\n",
	      KPOINT.nkmesh[0],
	      KPOINT.nkmesh[1],
	      KPOINT.nkmesh[2] );
      fprintf(fptr, " 0.  0.  0.\n");
    }
    // dos
    else if( INCAR.ICHARG == 11 && KPOINT.number_band_traced == 0 ){
      fprintf(fptr,"sampling mesh\n");
      fprintf(fptr, "0\n");
      fprintf(fptr, "Gamma\n");
      fprintf(fptr, "%2d %2d %2d\n",
	      2*KPOINT.nkmesh[0],
	      2*KPOINT.nkmesh[1],
	      2*KPOINT.nkmesh[2] );
      fprintf(fptr, " 0.  0.  0.\n");
    }
    // band
    else if( INCAR.ICHARG == 11 && KPOINT.number_band_traced > 0 ){
      const vector<BrillouinPoint> vsymmK 
	= lattice.cell.vsymmK;

      fprintf(fptr, "symmetric kpath\n");
      fprintf(fptr, " %d\n", (int)vsymmK.size() );
      fprintf(fptr, "reciprocal\n");

      for( int i=0; i<(int)vsymmK.size(); i++ ){
	fprintf( fptr, " %+f %+f %+f 1.0 %s\n",
		 vsymmK[i].position.x,
		 vsymmK[i].position.y,
		 vsymmK[i].position.z,
		 qPrintable(vsymmK[i].label) );
      }
    }
    else{
    }

    fclose(fptr);
  }
  catch( const MyException& e ){
    MyException::critical(e);
    if(fptr) fclose(fptr);
    return false;
  }


  return true;
}
