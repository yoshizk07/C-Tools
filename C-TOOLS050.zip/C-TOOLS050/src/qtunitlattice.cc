/*
 Copyright (c) 2014 Shinji Tsuneyuki
 This file is distributed under the terms of the GNU General Public License version 3.
 */

/*!
 \file qtunitlattice.cc
 \brief �i�q�̒P�ʖE��GUI�\���̃N���X
*/

#include "qtunitlattice.h"
#include "dtmodel.h"
#include "glunitlattice.h"
#include "qtmisc.h"

QTUnitLattice::QTUnitLattice( DTModel& _model, const int id ) : MyQTab(id), model(_model)
{
  QHBoxLayout* layout = new QHBoxLayout(this);
  //  layout->setSizeConstraint( QLayout::SetFixedSize );

  {
    QGroupBox* group = new QGroupBox("real space view");
    QVBoxLayout* box = new QVBoxLayout;

    {
      GLUnitLattice* widget = new GLUnitLattice(model);
      box->addWidget(widget);
    }

    group->setLayout(box);
    layout->addWidget(group);
  }

  {
    QGroupBox* group = new QGroupBox("real space parameters");
    QVBoxLayout* box = new QVBoxLayout;
    box->setSizeConstraint( QLayout::SetFixedSize );
 

    // cell vectors
    {
      QGroupBox* sgroup = new QGroupBox("unit length");
      QGridLayout* grid = new QGridLayout;
      int row=0,col=0;

      grid->addWidget(new QLabel("length:"),row,col++);
      {
	MyQLineEdit* swidget = new MyQLineEdit
	  (
	   model.lattice.cell.length, DTCell::length_min, DTCell::length_max,
	   this, SLOT(edit(const MyEvent&)), ID_UNIT );
	swidget->setFormat("%%.3f");
	vwidget.push_back(swidget);
	grid->addWidget(swidget,row,col++);
      }
      grid->addWidget(new QLabel("angstrom"),row,col++);
      sgroup->setLayout(grid);
      box->addWidget(sgroup);
    }

    // cell vectors
    {
      QGroupBox* sgroup = new QGroupBox("unit vectors");
      QGridLayout* grid = new QGridLayout;

      int row=0;

      grid->addWidget(new QLabel("x"),row,1);
      grid->addWidget(new QLabel("y"),row,2);
      grid->addWidget(new QLabel("z"),row,3);
      row++;

      grid->addWidget(new QLabel("Ea:"),row,0);
      {
	MyQLineEdit* widget = new MyQLineEdit
	  (
	   model.lattice.cell.Ea.x, DTCell::E_min, DTCell::E_max,
	   this, SLOT(edit(const MyEvent&)), ID_VECTOR );
	widget->setFixedWidth(60);
	widget->setFormat("%%.3f");
	grid->addWidget(widget,row,1);

	vwidget.push_back(widget);
      }
      {
	MyQLineEdit* widget = new MyQLineEdit
	  (
	   model.lattice.cell.Ea.y, DTCell::E_min, DTCell::E_max,
	   this, SLOT(edit(const MyEvent&)), ID_VECTOR );
	widget->setFixedWidth(60);
	widget->setFormat("%%.3f");
	grid->addWidget(widget,row,2);

	vwidget.push_back(widget);
      }
      {
	MyQLineEdit* widget = new MyQLineEdit
	  (
	   model.lattice.cell.Ea.z, DTCell::E_min, DTCell::E_max,
	   this, SLOT(edit(const MyEvent&)), ID_VECTOR );
	widget->setFixedWidth(60);
	widget->setFormat("%%.3f");
	grid->addWidget(widget,row,3);

	vwidget.push_back(widget);
      }
      row++;


      grid->addWidget(new QLabel("Eb:"),row,0);
      {
	MyQLineEdit* widget = new MyQLineEdit
	  (
	   model.lattice.cell.Eb.x, DTCell::E_min, DTCell::E_max,
	   this, SLOT(edit(const MyEvent&)), ID_VECTOR );
	widget->setFixedWidth(60);
	widget->setFormat("%%.3f");
	grid->addWidget(widget,row,1);

	vwidget.push_back(widget);
      }
      {
	MyQLineEdit* widget = new MyQLineEdit
	  (
	   model.lattice.cell.Eb.y, DTCell::E_min, DTCell::E_max,
	   this, SLOT(edit(const MyEvent&)), ID_VECTOR );
	widget->setFixedWidth(60);
	widget->setFormat("%%.3f");
	grid->addWidget(widget,row,2);

	vwidget.push_back(widget);
      }
      {
	MyQLineEdit* widget = new MyQLineEdit
	  (
	   model.lattice.cell.Eb.z, DTCell::E_min, DTCell::E_max,
	   this, SLOT(edit(const MyEvent&)), ID_VECTOR );
	widget->setFixedWidth(60);
	widget->setFormat("%%.3f");
	grid->addWidget(widget,row,3);

	vwidget.push_back(widget);
      }
      row++;


      grid->addWidget(new QLabel("Ec:"),row,0);
      {
	MyQLineEdit* widget = new MyQLineEdit
	  (
	   model.lattice.cell.Ec.x, DTCell::E_min, DTCell::E_max,
	   this, SLOT(edit(const MyEvent&)), ID_VECTOR );
	widget->setFixedWidth(60);
	widget->setFormat("%%.3f");
	grid->addWidget(widget,row,1);

	vwidget.push_back(widget);
      }
      {
	MyQLineEdit* widget = new MyQLineEdit
	  (
	   model.lattice.cell.Ec.y, DTCell::E_min, DTCell::E_max,
	   this, SLOT(edit(const MyEvent&)), ID_VECTOR );
	widget->setFixedWidth(60);
	widget->setFormat("%%.3f");
	grid->addWidget(widget,row,2);

	vwidget.push_back(widget);
      }
      {
	MyQLineEdit* widget = new MyQLineEdit
	  (
	   model.lattice.cell.Ec.z, DTCell::E_min, DTCell::E_max,
	   this, SLOT(edit(const MyEvent&)), ID_VECTOR );
	widget->setFixedWidth(60);
	widget->setFormat("%%.3f");
	grid->addWidget(widget,row,3);

	vwidget.push_back(widget);
      }
      row++;

      sgroup->setLayout(grid);
      box->addWidget(sgroup);
    }

    {
      MyQGroupBox* sgroup = new MyQGroupBox("atom list");
      QVBoxLayout* vbox = new QVBoxLayout;

      // atom list
      {
	// elem, a, b, c
	table = new QTableWidget( 0, 1+3, this );
	table->setFixedWidth(300);
	table->setMinimumHeight(200);
	table->setSelectionMode( QAbstractItemView::SingleSelection );
	table->setSelectionBehavior( QAbstractItemView::SelectRows );

	connect(table,SIGNAL(itemChanged(QTableWidgetItem*)),this,SLOT(itemEdited(QTableWidgetItem*)) );
	connect(table,SIGNAL(itemSelectionChanged()),this,SLOT(itemSelected()) );

	int column=0;
	table->setHorizontalHeaderItem(column,new QTableWidgetItem("elem"));
	table->setColumnWidth(column++,50);
	table->setHorizontalHeaderItem(column,new QTableWidgetItem("A"));
	table->setColumnWidth(column++,60);
	table->setHorizontalHeaderItem(column,new QTableWidgetItem("B"));
	table->setColumnWidth(column++,60);
	table->setHorizontalHeaderItem(column,new QTableWidgetItem("C"));
	table->setColumnWidth(column++,60);
	
	vbox->addWidget(table);
      }

      {
	MyQPushButton* widget = new MyQPushButton
	  ( "delete the selected atom", this, SLOT(edit(const MyEvent&)), ID_DELETE );
	widget->setFixedWidth(200);
	vbox->addWidget(widget);
	pb_delete = widget;
      }
      {
	MyQPushButton* widget = new MyQPushButton
	  ( "append the selected atom", this, SLOT(edit(const MyEvent&)), ID_APPEND );
	widget->setFixedWidth(200);
	vbox->addWidget(widget);
	pb_append = widget;
      }

      sgroup->setLayout(vbox);
      box->addWidget(sgroup);
    }

    group->setLayout(box);
    layout->addWidget(group);
    layout->setAlignment(group,Qt::AlignTop);
  }
  setLayout(layout);

  update();
}


void QTUnitLattice::edit( const MyEvent& ev )
{
  switch(ev.id){
  case ID_UNIT : {
  } break;
  case ID_VECTOR : {
  } break;
  case ID_DELETE : {
    model.lattice.molecule.deleteSelected();
  } break;
  case ID_APPEND : {
    model.lattice.molecule.appendSelected();
  } break;
  default : break;
  }

  emit changed(MyEvent(id));
}

void QTUnitLattice::update( void )
{
  const vector<DTAtom>& vatom = model.lattice.molecule.vatom;

  table->blockSignals(true);
  table->clearContents();
  table->setRowCount(vatom.size());

  int row=0;
  for( int iatom=0; iatom<(int)vatom.size(); iatom++ ){
    const QString& name = vatom[iatom].name;
    const Coordinates& coords = vatom[iatom].coords;

    char value[32];
    int column=0;
    { // name
      QTableWidgetItem* item = new QTableWidgetItem;
      item->setText( tr("%1").arg(name) );
      //      item->setFlags( Qt::NoItemFlags );
      table->setItem(row,column++,item);
    }
    { // a
      QTableWidgetItem* item = new QTableWidgetItem;
      sprintf(value,"%5.3f",coords.a);
      item->setText( tr("%1").arg(value) );
      //      item->setFlags( Qt::NoItemFlags );
      table->setItem(row,column++,item);
    }
    { // b
      QTableWidgetItem* item = new QTableWidgetItem;
      sprintf(value,"%5.3f",coords.b);
      item->setText( tr("%1").arg(value) );
      //      item->setFlags( Qt::NoItemFlags );
      table->setItem(row,column++,item);
    }
    { // c
      QTableWidgetItem* item = new QTableWidgetItem;
      sprintf(value,"%5.3f",coords.c);
      item->setText( tr("%1").arg(value) );
      //      item->setFlags( Qt::NoItemFlags );
      table->setItem(row,column++,item);
    }
    row++;
  }

  if( model.lattice.molecule.isSelected() ){
    table->clearSelection();
    const int iatom = model.lattice.molecule.getSelected();
    table->selectRow(iatom);
  }
  else{
    table->clearSelection();
  }

  table->blockSignals(false);

  if( model.lattice.molecule.isSelected() ){
    pb_delete->setEnabled(true);
    pb_append->setEnabled(true);
  }
  else{
    pb_delete->setEnabled(false);
    pb_append->setEnabled(false);
  }

  for( int i=0; i<(int)vwidget.size(); i++ ){
    vwidget[i]->update();
  }
}

void QTUnitLattice::itemSelected( void )
{
  const QList<QTableWidgetItem*> litem = table->selectedItems();

  const int iatom = litem.front()->row();

  if( model.lattice.molecule.select(iatom) ){
    emit changed(MyEvent(id));
  }
}

void QTUnitLattice::itemEdited( QTableWidgetItem* item )
{
  const vector<DTAtom>& vatom = model.lattice.molecule.vatom;
  const int iatom = item->row();

  table->blockSignals(true);
  switch( item->column() ){

  case 0 : { // element
    char name[8];
    if( 1 == sscanf( qPrintable(item->text()), "%s", name ) &&
	model.lattice.molecule.changeSelected(name) ){
      item->setText( tr("%1").arg(name) );
      emit changed(MyEvent(id));
    }else{
      item->setText( tr("%1").arg(vatom[iatom].name) );
    }
  } break;

  case 1 : { // a
    Coordinates coords;
    coords = vatom[iatom].coords;
    if( 1 == sscanf( qPrintable(item->text()), "%lf", &coords.a ) &&
	model.lattice.molecule.changeSelected(coords) ){
      item->setText( tr("%1").arg(coords.a) );
      emit changed(MyEvent(id));
    }else{
      item->setText( tr("%1").arg(vatom[iatom].coords.a) );
    }
  } break;

  case 2 : { // b
    Coordinates coords;
    coords = vatom[iatom].coords;
    if( 1 == sscanf( qPrintable(item->text()), "%lf", &coords.b ) &&
	model.lattice.molecule.changeSelected(coords) ){
      item->setText( tr("%1").arg(coords.b) );
      emit changed(MyEvent(id));
    }else{
      item->setText( tr("%1").arg(vatom[iatom].coords.b) );
    }
  } break;

  case 3 : { // c
    Coordinates coords;
    coords = vatom[iatom].coords;
    if( 1 == sscanf( qPrintable(item->text()), "%lf", &coords.c ) &&
	model.lattice.molecule.changeSelected(coords) ){
      item->setText( tr("%1").arg(coords.c) );
      emit changed(MyEvent(id));
    }else{
      item->setText( tr("%1").arg(vatom[iatom].coords.c) );
    }
  } break;

  }
  table->blockSignals(false);
}
