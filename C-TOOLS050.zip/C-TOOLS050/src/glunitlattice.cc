/*
 Copyright (c) 2014 Shinji Tsuneyuki
 This file is distributed under the terms of the GNU General Public License version 3.
 */

/*!
 \file glunitlattice.cc
 \brief ���i�q��GL�\���̓����N���X
*/


#include "glunitlattice.h"
#include "dtmodel.h"
#include "qtmisc.h"
#include "qtexception.h"

GLUnitLattice::GLUnitLattice( DTModel& _model ) :
  model(_model),
  atoms(_model),
  bonds(_model),
  cell (_model,this)
{
  setFocusPolicy( Qt::ClickFocus );
  setMinimumSize( 512, 512 );
  setSizePolicy( QSizePolicy::Expanding, QSizePolicy::Expanding );

  connect( &model, SIGNAL(changed()),   this, SLOT(update()) );
  connect(   this, SIGNAL(changed()), &model, SLOT(update()) );

  popupmenu = new QMenu(this);
  popupmenu->addSeparator();
  popupmenu->addAction( new QAction(tr("reset to xy-plane"),this) );
  popupmenu->addAction( new QAction(tr("reset to yz-plane"),this) );
  popupmenu->addAction( new QAction(tr("reset to zx-plane"),this) );
  popupmenu->addSeparator();
  popupmenu->addAction( new QAction(tr("change perspective/orthogonal"),this) );
  popupmenu->addAction( new QAction(tr("save image"),this) );
  connect(popupmenu, SIGNAL(triggered(QAction*)), this, SLOT(menuEvent(QAction*)));

  perspective = true;
}

void GLUnitLattice::initializeGL( void )
{
  glClearColor( model.gloption.window.background );

  glMatrixMode( GL_MODELVIEW );
  glLoadIdentity();
  gluLookAt( model.gloption.location.eye,
	     model.gloption.location.gaze,
	     model.gloption.location.up );

  glEnable( GL_DEPTH_TEST );
  glEnable( GL_NORMALIZE );

  glShadeModel( GL_SMOOTH );
  glLightModeli(  GL_LIGHT_MODEL_TWO_SIDE, 1 );
  glLightModeli(  GL_LIGHT_MODEL_LOCAL_VIEWER, 1 );
  glLightModeldv( GL_LIGHT_MODEL_AMBIENT, model.gloption.light.ambient );
  glEnable( GL_LIGHTING );

  glLightdv( GL_LIGHT0, GL_POSITION, model.gloption.light.direction );
  glLightdv( GL_LIGHT0, GL_DIFFUSE,  model.gloption.light.diffuse );
  glLightdv( GL_LIGHT0, GL_SPECULAR, model.gloption.light.specular );
  glEnable( GL_LIGHT0 );

  glLightdv( GL_LIGHT1, GL_POSITION, model.gloption.light.second_direction );

  glLightdv( GL_LIGHT1, GL_DIFFUSE,  model.gloption.light.diffuse );
  glLightdv( GL_LIGHT1, GL_SPECULAR, model.gloption.light.specular );
  if( model.gloption.light.second ){
    glEnable( GL_LIGHT1 );
  }

  glFogf( GL_FOG_MODE, GL_LINEAR );
  glFogf( GL_FOG_START,   model.gloption.location.world );
  glFogf( GL_FOG_END, 1.6*model.gloption.location.world );
  glFogfv( GL_FOG_COLOR,  model.gloption.window.background );
  if( model.gloption.light.fog ){
    glEnable( GL_FOG );
  }

  glMaterialdv( GL_FRONT_AND_BACK, GL_SPECULAR,  model.gloption.light.specular  );
  glMateriald ( GL_FRONT_AND_BACK, GL_SHININESS, model.gloption.light.shininess );

  glClearColor( model.gloption.window.background );
  glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
}


void GLUnitLattice::gluProjection( int width, int height, bool perspective )
{
  if( perspective ){
    const double aspect = (double)width/height;
    gluPerspective( model.gloption.location.pangle,
		    aspect,
		    model.gloption.location.pnear,
		    model.gloption.location.pfar );
  }else{
    const double t = tan(model.gloption.location.pangle*0.5*M_PI/180.0);
    const double aspect = (double)width/height;
    const double top    = 1.00*sqrt(model.gloption.location.pnear*model.gloption.location.pfar) * t;
    const double bottom = -top;
    const double right  = top*aspect;
    const double left   = -right;

    glOrtho( left, right, bottom, top, 
	     model.gloption.location.pnear,
	     model.gloption.location.pfar );
  }
}

void GLUnitLattice::resizeGL(int width, int height)
{
  glViewport( 0, 0, width, height );

  glMatrixMode( GL_PROJECTION );
  glLoadIdentity();

  gluProjection( width, height, perspective );

  glMatrixMode( GL_MODELVIEW );
  
  glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
}

void GLUnitLattice::paintGL( void )
{
  if( model.gloption.light.second ){
    glEnable( GL_LIGHT1 );
  }else{
    glDisable( GL_LIGHT1 );
  }
  if( model.gloption.light.fog ){
    glFogfv( GL_FOG_COLOR, model.gloption.window.background );
    glEnable( GL_FOG );
  }else{
    glDisable( GL_FOG );
  }
  glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );

  draw();
}

// mouse drag begin
void GLUnitLattice::mousePressEvent( QMouseEvent* ev )
{
  if( !(ev->buttons()&Qt::LeftButton) ) return;

  int x = ev->x(), y = ev->y();

  x_down = x, y_down = y;
}

// mouse selection
void GLUnitLattice::mouseDoubleClickEvent( QMouseEvent* ev )
{
  static GLuint data[1024];
  glSelectBuffer( sizeof(data)/sizeof(GLuint), data );

  glRenderMode(GL_SELECT);
  glInitNames();

  glMatrixMode(GL_PROJECTION);
  glPushMatrix();
  glLoadIdentity();

  struct { GLint xo, yo, width, height; } viewport;
  glGetIntegerv( GL_VIEWPORT, (GLint*)&viewport );
  gluPickMatrix( ev->x(), viewport.height-1-ev->y(),
		 4, 4, (GLint*)&viewport );
  gluProjection( viewport.width, viewport.height, perspective );
  glMatrixMode(GL_MODELVIEW);

  select();

  glMatrixMode(GL_PROJECTION);
  glPopMatrix();
  glMatrixMode(GL_MODELVIEW);

  GLuint hits = glRenderMode(GL_RENDER);
  GLuint name = GLuint(-1);
  GLuint zminmin  = GLuint(-1);

  if( hits == 0 ){
    model.lattice.molecule.unselect();
    emit changed();
  }
  else{
    for( GLuint i=0,j=0; i<hits; i++ ){
      GLuint n    = data[j++];
      GLuint zmin = data[j++];
      GLuint zmax = data[j++]; // not used
      if( n==1 ){
	if( zminmin>=zmin && zmax>0 ){
	  zminmin = zmin;
	  name = data[j++];
	}
	else{
	  j++;
	}
      }
    }

    if( model.lattice.molecule.select((int)name) ){
      emit changed();
    }
    else{
      model.lattice.molecule.unselect();
      emit changed();
    }
  }

  makeCurrent();
  x_down = ev->x(), y_down = ev->y();
}

// mouse drag end
void GLUnitLattice::mouseReleaseEvent( QMouseEvent* ev )
{
}

// mouse drag
void GLUnitLattice::mouseMoveEvent( QMouseEvent* ev )
{
  if( !(ev->buttons()&Qt::LeftButton) ) return;

  int x = ev->x(), y = ev->y();

  const double dx = (1.0/4)*(x-x_down);
  const double dy = (1.0/4)*(y-y_down);

  if( fabs(dx) < 1.0 && fabs(dy) < 1.0 ) return;

  glRotateR( dy, 1.0, 0.0, 0.0 );
  glRotateR( dx, 0.0, 1.0, 0.0 );

  x_down = x, y_down = y;

  updateGL();
}

void GLUnitLattice::wheelEvent( QWheelEvent* ev )
{
  if( ev->orientation() == Qt::Horizontal ) return;

  const double dy = (-2.0) * (double)ev->delta() / 120.0;

  {
    const double f = 1.0 + (1.0/256)*dy;
    glScaled(f,f,f);
  }

  updateGL();
}

void GLUnitLattice::keyPressEvent( QKeyEvent* ev )
{
  double dx=0.0, dy=0.0, dz=0.0;
  switch( ev->key() ){
  case Qt::Key_Left     : dx=-1.0; break;
  case Qt::Key_Right    : dx=+1.0; break;
  case Qt::Key_Up       : dy=-1.0; break;
  case Qt::Key_Down     : dy=+1.0; break;
  case Qt::Key_PageDown : dz=-1.0; break;
  case Qt::Key_PageUp   : dz=+1.0; break;
  default : break;
  }

  if( ev->modifiers() & Qt::ControlModifier ) {
    glRotateR( 15*dy, 1.0, 0.0, 0.0 );
    glRotateR( 15*dx, 0.0, 1.0, 0.0 );
    glRotateR( 15*dz, 0.0, 0.0, 1.0 );
  }
  else{
    switch( ev->key() ){
    case Qt::Key_PageDown :  {
      const double f = 1.0 + (1.0/8);
      glScaled(f,f,f);
    } break; 
    case Qt::Key_PageUp :  {
      const double f = 1.0 - (1.0/8);
      glScaled(f,f,f);
    } break;
    case Qt::Key_Down     : {
      const double dy=-15.0;
      glTranslateR( 0.0, (1.0/4)*(dy), 0.0 );
    } break;
    case Qt::Key_Up       : {
      const double dy=+15.0;
      glTranslateR( 0.0, (1.0/4)*(dy), 0.0 );
    } break;
    case Qt::Key_Left     : {
      const double dx=-15.0;
      glTranslateR( (1.0/4)*(dx), 0.0, 0.0 );
    } break;
    case Qt::Key_Right    : {
      const double dx=+15.0;
      glTranslateR( (1.0/4)*(dx), 0.0, 0.0 );
    } break;

    default : break;
    }
  }

  updateGL();
}


void GLUnitLattice::keyReleaseEvent( QKeyEvent* ev )
{
  if( ev->isAutoRepeat() ) return;

  switch( ev->key() ){
  case Qt::Key_Left   : break;
  case Qt::Key_Right  : break;
  case Qt::Key_Down   : break;
  case Qt::Key_Up     : break;
  case Qt::Key_PageDown : break;
  case Qt::Key_PageUp   : break;
  default             : return;
  }
}

void GLUnitLattice::contextMenuEvent( QContextMenuEvent* ev )
{
  popupmenu->exec(ev->globalPos());
}

void GLUnitLattice::menuEvent( QAction* action )
{
  static bool first = true;
  if( first ){
    path = QDir::currentPath();
    first = false;
  }

  if( false ){
  }
  else if( action->text() == "reset to xy-plane" ||
	   action->text() == "reset to yz-plane" ||
	   action->text() == "reset to zx-plane" ){
    glLoadIdentity();
    gluLookAt( model.gloption.location.eye,
	       model.gloption.location.gaze,
	       model.gloption.location.up );
    model.gloption.light.direction =
      model.gloption.light.direction_orig;
    glLightdv( GL_LIGHT0, GL_POSITION,
	       model.gloption.light.direction );

    if( action->text() == "reset to xy-plane" ){
    }
    if( action->text() == "reset to yz-plane" ){
      glRotateR( -90.0, 0.0, 0.0, 1.0 );
      glRotateR( -90.0, 1.0, 0.0, 0.0 );
    }
    if( action->text() == "reset to zx-plane" ){
      glRotateR( 90.0, 0.0, 1.0, 0.0 );
      glRotateR( 90.0, 1.0, 0.0, 0.0 );
    }
  }
  else if( action->text() == "change perspective/orthogonal" ){
    perspective = !perspective;
    resizeGL( glGetWindowWidth(), glGetWindowHeight() );
  }
  else if( action->text() == "save image" ){
    const QString fname = QFileDialog::getSaveFileName
      ( this, tr("Save image in file"), path,
	tr("Windows Bitmap file(*.bmp);;"
	   "All files(*)"));
    
    if( fname.endsWith( ".bmp" ) ){
      if( glSavePixels( qPrintable(fname) ) ){
	path = getDirName(fname);
      }
      else{
	MyException::critical("can not create a file.",fname);
      }
    }
    else if( fname !="" ){
      MyException::critical("unknown suffix.",fname);
    }
  }
}

void GLUnitLattice::update( void )
{
  atoms.change();
  bonds.change();
  cell .change();

  makeCurrent();
  updateGL();
}

void GLUnitLattice::draw( void )
{
  const double L = model.lattice.getScale(); // �n�̂����܂��ȑ傫��
  const double f = model.gloption.location.world/L*(0.5);

  glPushMatrix();
  glScaled(f,f,f);

  atoms.draw();
  bonds.draw();
  cell.draw();

  glPopMatrix();
}

void GLUnitLattice::select( void )
{
  const double L = model.lattice.getScale(); // �n�̂����܂��ȑ傫��
  const double f = model.gloption.location.world/L*(0.5);

  glPushMatrix();
  glScaled(f,f,f);

  atoms.draw();

  glPopMatrix();
}
