/*
 Copyright (c) 2014 Shinji Tsuneyuki
 This file is distributed under the terms of the GNU General Public License version 3.
 */

#include <stdio.h>
#include <ctype.h>
#include "dtlattice.h"
#include "dtrsdft.h"
#include "qtxml.h"
#include "qtexception.h"
#include "symbol.h"
#include <algorithm>

extern QString getDirName( const QString& path );
extern QString getFileName( const QString& path );


// Fortran�̎w���`�� 1.0d2 ��C�̎w���`�� 1.0e2 �ɕϊ�����֐�
static bool change_exp_format( char* ptr )
{
  bool effective = true;
  while( *ptr ){
    if( *ptr == '\'' ){
      effective = !effective;
    }

    if( effective ){
      *ptr = toupper(*ptr);
    }
    if( ptr[0] == 'D' ){
      if( ptr[1] == '+' || ptr[1] == '-' || ptr[1] == '0' ){
	ptr[0] = 'e';
      }
    }
    ptr++;
  }

  return true;
}


namespace std {
  template<typename T> inline T max( const T&a, const T&b, const T&c )
  {
    return std::max(std::max(a,b),c);
  }

  inline int GCD( int a, int b )
  {
    int na, nb, nr;
    na = a;
    nb = b;

    while( nb>0 ){
      nr = na%nb;
      na = nb;
      nb = nr;
    }

    return na;
  }

  inline int LCM( int a, int b )
  {
    int g = GCD(a,b);
    return (a/g)*(b/g)*g;
  }

  inline int LCM( int a, int b, int c )
  {
    return LCM(LCM(a,b),c);
  }
};

Table DTRSDFT::DGRID_def( 0.5, 0.4, 0.3, 0.2, 1.0 );
Table DTRSDFT::BETA_def( 0.4, 0.3, 0.2, 0.1, 0.9 );
Table DTRSDFT::DITER_def( 80, 120, 200, 40, 200 );
Table DTRSDFT::SCFCONV_def( 1.0e-12, 1.0e-15, 1.0e-18, 1.0e-21, 1.0e-9 );
Table DTRSDFT::ATOMOPT2_def( 5.0e-3, 5.0e-4, 5.0e-5, 5.0e-6, 5.0e-2 );


void DTRSDFT::clear( void )
{
  ISYM    = 1;
  XCTYPE  = "LDAPZ81";
  NBAND   = 0;
  NSPIN   = 1;
  DGRID   = DGRID_def.getDefault("Normal");
  BETA    = BETA_def.getDefault("Normal");
  DITER   = DITER_def.getDefault("Normal");
  SCFCONV = SCFCONV_def.getDefault("Normal");
  ATOMOPT2 = ATOMOPT2_def.getDefault("Normal");
  SWSCF   = 1;
  SWOPT   = 0;
  SWBAND  = 0;
  ATOMOPT1 = 100;

  nkmesh[0] = nkmesh[1] = nkmesh[2] = 1;
  skmesh[0] = skmesh[1] = skmesh[2] = 1;

  Symmetry.number_sym_op = 1;
  Atom.atom.clear();
}

QString DTRSDFT::guess( const QString& fname )
{
  char buf[256];
  bool match;

  FILE* fptr;
  {
    match = false;
    fptr = fopen(fname, "rb" );
    if( fptr == NULL ){
      return "";
    }
    fgets(buf,sizeof(buf),fptr);
    if( strncmp( buf, "# RSDFT", sizeof("# RSDFT") ) == 0 ){
      match = true;
    }
    fclose(fptr);
    if( !match ) return "";
  }

  {
    match = false;
    QString fname_sub = getDirName(fname) + "/fort.970";
    fptr = fopen(fname, "rb" );
    if( fptr == NULL ){
      return "";
    }
    fgets(buf,sizeof(buf),fptr);
    int idummy;
    if( 2 == sscanf( buf, "%d %d", &idummy, &idummy ) ){
      match = true;
    }
    fclose(fptr);
    if( !match ) return "";
  }

  if( match ){
    return "solver rsdft format";
  }

  return "";
}

bool DTRSDFT::load( const QString& fname )
{
  FILE* fptr = NULL;
  const QString fname2 = getDirName(fname) + "/fort.1";
  const QString fname3 = getDirName(fname) + "/fort.970";

  char buf[1024];

  int NGRID[3];
  int NK = 2;
  int MMM1[3] = {2, 2, 2};
  int MMM2[3] = {2, 2, 2};

  QString name;
  vector<QString> vname;
  int number_atom = 0;
  int number_element = 0;

  clear();

  try{
    fptr = fopen( fname2, "r" );
    if( fptr == NULL ){
      throw MyException("can not open a RSDFT file.", fname2 );
    }

    while(fgets(buf,sizeof(buf),fptr)){
      if( buf[0] == '#' ||  buf[0] == '/' ) continue;
      change_exp_format(buf);

      if( false );
      else if( 1 == XML::sscanf( buf, " ISYM %d", &ISYM ) );
      else if( 1 == XML::sscanf( buf, " XCTYPE %s", &XCTYPE ) );
      else if( 1 == XML::sscanf( buf, " AX %lf", &AX ) );
      else if( 3 == XML::sscanf( buf, " A1 %lf %lf %lf", &A1.x, &A1.y, &A1.z ) );
      else if( 3 == XML::sscanf( buf, " A2 %lf %lf %lf", &A2.x, &A2.y, &A2.z ) );
      else if( 3 == XML::sscanf( buf, " A3 %lf %lf %lf", &A3.x, &A3.y, &A3.z ) );
      else if( 1 == XML::sscanf( buf, " NSPIN %d", &NSPIN ) );
      else if( 1 == XML::sscanf( buf, " NK %d", &NK ) );
      else if( 3 == XML::sscanf( buf, " MMM1 %d %d %d", &MMM1[0], &MMM1[1], &MMM1[2] ) );
      else if( 3 == XML::sscanf( buf, " MMM2 %d %d %d", &MMM2[0], &MMM2[1], &MMM2[2] ) );
      else if( 3 == XML::sscanf( buf, " NGRID %d %d %d",
				 &NGRID[0], &NGRID[1], &NGRID[2] ) );
      else if( 1 == XML::sscanf( buf, " BETA %lf", &BETA ) );
      else if( 1 == XML::sscanf( buf, " SCFCONV %lg", &SCFCONV ) );
      else if( 1 == XML::sscanf( buf, " DITER %d", &DITER ) );
      else if( 1 == XML::sscanf( buf, " SWSCF %d", &SWSCF ) );
      else if( 1 == XML::sscanf( buf, " SWOPT %d", &SWOPT ) );
      else if( 1 == XML::sscanf( buf, " SWBAND %d", &SWBAND ) );
      else if( 1 == XML::sscanf( buf, " ATOMOPT1 %d", &ATOMOPT1 ) );
      else if( 1 == XML::sscanf( buf, " ATOMOPT2 %*f %*f %lf %*f", &ATOMOPT2 ) );
      else if( 1 == XML::sscanf( buf, " PP %*d '%[A-Za-z]'", &name ) ){
	vname.push_back( ElementSymbol::getAtomicName(name) );
      }
    } // end while;
    fclose(fptr);


    fptr = fopen(fname3, "rb" );
    if( fptr == NULL ){
      throw MyException("can not open a RSDFT atomic file.", fname3 );
    }

    fgets(buf,sizeof(buf),fptr); // MKI, MI
    if( 2 != sscanf( buf, "%d %d", &number_element, &number_atom ) ){
      throw MyException("broken header in atomic file.");
    }
    if( number_element != (int)vname.size() ){
      throw MyException("invalid number of elements.");
    }
    Atom.atom.resize(number_atom);
    for( int ia=0,ie; ia<number_atom; ia++ ){
      fgets(buf,sizeof(buf),fptr);
      if( 4 == sscanf(buf,"%d %lf %lf %lf",
		      &ie,
		      &Atom.atom[ia].coords.a,
		      &Atom.atom[ia].coords.b,
		      &Atom.atom[ia].coords.c ) ){
	ie--;
	if( ie<0 || number_element<=ie ){
	  throw MyException("broken element number.");
	}
	Atom.atom[ia].name = vname[ie];
	Atom.atom[ia].number = ElementSymbol::getAtomicNumber(vname[ie]);
      }
      else{
	throw MyException("broken coordinates in atomic file.");
      }
    }
    fclose(fptr);

    // derive DGRID
    {
      const double dA1 = 1.0/NGRID[0]*AX*Position::length(A1);
      const double dA2 = 1.0/NGRID[1]*AX*Position::length(A2);
      const double dA3 = 1.0/NGRID[2]*AX*Position::length(A3);

      DGRID = dA1;
      if( DGRID > dA2 ) DGRID = dA2;
      if( DGRID > dA3 ) DGRID = dA3;
    }

    // translate NK,MMM to nkmesh,skmesh
    {
      for( int i=0; i<3; i++ ){
	nkmesh[i] = 0;
	skmesh[i] = 0;

	for( int m=-MMM1[i]; m<=+MMM1[i]; m+=MMM2[i] ){
	  if( 2*m<-NK || +NK<2*m ) continue;
	  nkmesh[i]++;
	  if( m==0 ) skmesh[i] = 1;
	}
      }
    } // nkmesh,skmesh
  }
  catch( const MyException& e ){
    MyException::critical(e);
    return false;
  }

  return true;
}

bool DTRSDFT::save( const DTLattice& lattice, const QString& fname ) const
{
  int NGRID[3];
  int NK;
  int MMM1[3];
  int MMM2[3];
  
  // translate DGRID to NGRID
  {
    NGRID[0] = int(ceil(AX*Position::length(A1)/DGRID));
    NGRID[1] = int(ceil(AX*Position::length(A2)/DGRID));
    NGRID[2] = int(ceil(AX*Position::length(A3)/DGRID));
    while( NGRID[0] % Symmetry.denom_trans != 0 ) NGRID[0]++;
    while( NGRID[1] % Symmetry.denom_trans != 0 ) NGRID[1]++;
    while( NGRID[2] % Symmetry.denom_trans != 0 ) NGRID[2]++;
  }


  // translate NK,MMM to nkmesh,skmesh
  {
    NK = std::LCM( 2*nkmesh[0], 2*nkmesh[1], 2*nkmesh[2] );

    for( int i=0; i<3; i++ ){
      if( skmesh[i] == 1 ){
	if( nkmesh[i]%2 == 0 ){
	  MMM1[i] = nkmesh[i]+0;
	}
	else{
	  MMM1[i] = nkmesh[i]+1;
	}
      }
      else{
	if( nkmesh[i]%2 == 0 ){
	  MMM1[i] = nkmesh[i]+1;
	}
	else{
	  MMM1[i] = nkmesh[i]+0;
	}
      }
      MMM1[i] *= NK/(2*nkmesh[i]);
      MMM2[i] = 2;
    }
  }

  vector<QString> vname;
  for( int ia=0; ia<(int)Atom.atom.size(); ia++ ){
    const QString& name = Atom.atom[ia].name;
    if( std::find( vname.begin(), vname.end(), name ) == vname.end() ){
      vname.push_back(name);
    }
  }

  int number_atom = (int)Atom.atom.size();
  int number_element = (int)vname.size();


  FILE* fptr = NULL;
  const QString fname2 = getDirName(fname)+"/fort.1";
  const QString fname3 = getDirName(fname)+"/fort.970";
  const QString fname4 = getDirName(fname)+"/symdat";

  try{
    fptr = fopen( fname2, "w" );
    if( fptr == NULL ){
      throw MyException("can not create a RSDFT file.",fname2);
    }

    fprintf(fptr, "# RSDFT\n");
    if( ISYM ){
      fprintf(fptr,"ISYM %d '%s'\n", ISYM, "symdat" );
    }
    else{
      fprintf(fptr,"ISYM %d\n", ISYM );
    }
    fprintf(fptr,"XCTYPE %s\n", qPrintable(XCTYPE) );
    fprintf(fptr,"SYSTYPE 0\n");
    fprintf(fptr,"AX     %f  / a.u.\n", AX );
    fprintf(fptr,"A1     %+15.10f %+15.10f %+15.10f\n", A1.x, A1.y, A1.z );
    fprintf(fptr,"A2     %+15.10f %+15.10f %+15.10f\n", A2.x, A2.y, A2.z );
    fprintf(fptr,"A3     %+15.10f %+15.10f %+15.10f\n", A3.x, A3.y, A3.z );
    fprintf(fptr,"NBAND  %d\n", NBAND );
    fprintf(fptr,"NSPIN  %d\n", NSPIN );
    fprintf(fptr,"NDSPIN 0.0\n");
    fprintf(fptr,"NFIXED 0\n");
    fprintf(fptr,"NEXTE  0.0\n");
    fprintf(fptr,"NK     %d\n", NK );
    fprintf(fptr,"MMM1   %d %d %d\n", MMM1[0], MMM1[1], MMM1[2] );
    fprintf(fptr,"MMM2   %d %d %d\n", MMM2[0], MMM2[1], MMM2[2] );
    fprintf(fptr,"NCG    2\n");
    fprintf(fptr,"NGRID  %d %d %d\n", NGRID[0], NGRID[1], NGRID[2] );
    fprintf(fptr,"MD     6\n");
    fprintf(fptr,"PSELECT 2\n");
    for( int ie=0; ie<(int)vname.size(); ie++ ){
      fprintf(fptr,"PP 2 '%s_psv.dat'\n", qPrintable(vname[ie]) );
    }
    fprintf(fptr,"IMIX   20\n");
    fprintf(fptr,"BETA   %f\n", BETA );
    fprintf(fptr,"SCFCONV %e\n", SCFCONV );
    fprintf(fptr,"PROCS  1 1 1 1 1 1\n");
    fprintf(fptr,"EKBT   1.0d-5\n");
    fprintf(fptr,"KINTEG 5\n");
    fprintf(fptr,"DITER  %d\n", DITER );
    fprintf(fptr,"NSWEEP 5\n");
    fprintf(fptr,"IC     0\n");
    fprintf(fptr,"OC     3\n");
    fprintf(fptr,"OC2    100\n");
    fprintf(fptr,"IOCTRL 0\n");
    fprintf(fptr,"SWSCF  %d\n", SWSCF );
    fprintf(fptr,"SWOPT  %d\n", SWOPT );
    fprintf(fptr,"SWBAND %d\n", SWBAND );
    fprintf(fptr,"ETLIMIT 10000.0\n");
    fprintf(fptr,"ATOMOPT1 %d 6 5\n", ATOMOPT1 );
    fprintf(fptr,"ATOMOPT2 0.5 1.0e-10 %e 0.1\n", ATOMOPT2 );
    fprintf(fptr,"ATOMOPT3 %d\n", DITER );
    fprintf(fptr,"HF     0.4 0 0 0\n");

    if( SWBAND ){
      const vector<BrillouinSegment> vsymmL 
	= lattice.cell.vsymmL;

      Position last;
      int number_band_traced;
      int number_trace_block;

      number_band_traced = 0;
      for( int i=0; i<(int)vsymmL.size(); i++ ){
	const BrillouinSegment& symmL = vsymmL[i];

	if( i==0 ){
	  number_band_traced++;
	  number_band_traced++;
	}
	else{
	  if( last != symmL.positions ){
	    number_band_traced++;
	  }
	  number_band_traced++;
	}
	last = symmL.positione;
      }
      number_trace_block = number_band_traced-1;

      fprintf(fptr,"\n");
      fprintf(fptr,"BAND %d %d %d 1.0e-7 100\n",
	      number_trace_block, int(ceil(NBAND*1.1)), NBAND );

      for( int i=0; i<(int)vsymmL.size(); i++ ){
	const BrillouinSegment& symmL = vsymmL[i];

	if( i==0 ){
	  fprintf(fptr, "%5.3f ", symmL.positions.x ); 
	  fprintf(fptr, "%5.3f ", symmL.positione.x ); 
	}
	else{
	  if( last != symmL.positions ){
	    fprintf(fptr, "%5.3f ", symmL.positions.x ); 
	  }
	  fprintf(fptr, "%5.3f ", symmL.positione.x ); 
	}
	last = symmL.positione;
      }
      if( !vsymmL.empty() ){
	fprintf(fptr, "# ak(1,1:nbk+1)\n");
      }

      for( int i=0; i<(int)vsymmL.size(); i++ ){
	const BrillouinSegment& symmL = vsymmL[i];

	if( i==0 ){
	  fprintf(fptr, "%5.3f ", symmL.positions.y ); 
	  fprintf(fptr, "%5.3f ", symmL.positione.y ); 
	}
	else{
	  if( last != symmL.positions ){
	    fprintf(fptr, "%5.3f ", symmL.positions.y ); 
	  }
	  fprintf(fptr, "%5.3f ", symmL.positione.y ); 
	}
	last = symmL.positione;
      }
      if( !vsymmL.empty() ){
	fprintf(fptr, "# ak(2,1:nbk+1)\n");
      }

      for( int i=0; i<(int)vsymmL.size(); i++ ){
	const BrillouinSegment& symmL = vsymmL[i];

	if( i==0 ){
	  fprintf(fptr, "%5.3f ", symmL.positions.z ); 
	  fprintf(fptr, "%5.3f ", symmL.positione.z ); 
	}
	else{
	  if( last != symmL.positions ){
	    fprintf(fptr, "%5.3f ", symmL.positions.z ); 
	  }
	  fprintf(fptr, "%5.3f ", symmL.positione.z ); 
	}
	last = symmL.positione;
      }
      if( !vsymmL.empty() ){
	fprintf(fptr, "# ak(3,1:nbk+1)\n");
      }


      fprintf(fptr, "     ");
      for( int i=0; i<(int)vsymmL.size(); i++ ){
	const BrillouinSegment& symmL = vsymmL[i];

	if( i==0 ){
	  fprintf(fptr, "%-5d ", symmL.npoint ); 
	}
	else{
	  if( last != symmL.positions ){
	    fprintf(fptr, "%-5d ", 0 );
	  }
	  fprintf(fptr, "%-5d ", symmL.npoint );
	}
	last = symmL.positione;
      }
      if( !vsymmL.empty() ){
	fprintf(fptr, " # nkfi(1:nbk)\n");
      }
    }
    fclose(fptr);


    {
      fptr = fopen( fname3, "w" );
      if( fptr == NULL ){
	throw MyException("can not create a RSDFT atomic file.",fname3);
      }

      fprintf(fptr," %d  %d / MKI MI\n", number_element, number_atom );
      for( int ia=0; ia<number_atom; ia++ ){
	int ie;
	for( ie=0; ie<number_element; ie++ ){
	  if( vname[ie] == Atom.atom[ia].name ){
	    break;
	  }
	}
	fprintf(fptr, " %d %15.10f %15.10f %15.10f 1 / Kion(%d) asi(1:3,%d), %2s\n",
		ie+1,
		Atom.atom[ia].coords.a,
		Atom.atom[ia].coords.b,
		Atom.atom[ia].coords.c,
		ia+1, ia+1,
		qPrintable(Atom.atom[ia].name) );
      }
      fclose(fptr);
    }

    if( ISYM ){
      fptr = fopen( fname4, "w" );
      if( fptr == NULL ){
	throw MyException("can not create a RSDFT symdat file.",fname4);
      }

      {
	fprintf(fptr, " %d  %d\n",
		(int)Symmetry.vmatrix.size(),
		Symmetry.denom_trans );
	for( int n=0; n<(int)Symmetry.vmatrix.size(); n++ ){
//	  const IMatrix imatrix = Symmetry.vmatrix[n].getTransInverse();
	  for( int i=0; i<3; i++ ){
	    for( int j=0; j<3; j++ ){
	      fprintf(fptr, " %2d", Symmetry.vmatrix[n].M[i][j] );
	    }
	    fprintf(fptr,"  ");
	  }
	  fprintf(fptr," ");
	  for( int i=0; i<3; i++ ){
	    fprintf(fptr, " %d", (Symmetry.vmatrix[n].T[i]*Symmetry.denom_trans).toInteger() );
	  }
	  fprintf(fptr, " ! %s\n", Symmetry.vmatrix[n].name() );
	}
      }
      fclose(fptr);
    }
  }
  catch( const MyException& e ){
    MyException::critical(e);
    if(fptr) fclose(fptr);
    return false;
  }
  return true;
}


static inline int nabs( const int n )
{
  return n<0 ? -n : n;
}

static bool match( const double matrixA[3][3], const double matrixB[3][3] )
{
  const double tolerance = 1.0e-5;
  double residue = 0.0;
  for( int i=0; i<3; i++ ){
    for( int j=0; j<3; j++ ){
      const double diff = matrixA[i][j] - matrixB[i][j];
      residue += diff*diff;
    }
  }
  return residue<tolerance*tolerance;
}

static bool match( const Coordinates& coordsA, const Coordinates& coordsB )
{
  const double tolerance = 1.0e-8;
  const double residue = Coordinates::normalize5(coordsA-coordsB).norm();
  return residue<tolerance*tolerance;
}

static bool checkChanged( const vector<DTAtom>& vatom, const Position latvec[3] )
{
  static vector<DTAtom> vatom_prev;
  static Position latvec_prev[3] = {
    Position(0.0,0.0,0.0),
    Position(0.0,0.0,0.0),
    Position(0.0,0.0,0.0)
  };
  bool status = false;

  if( latvec_prev[0] != latvec[0] ||
      latvec_prev[1] != latvec[1] ||
      latvec_prev[2] != latvec[2] ){
    status = true;
    goto end_block;
  }

  for( int ia=0; ia<(int)vatom.size(); ia++ ){
    if( ia>=(int)vatom_prev.size() ){
      status = true;
      goto end_block;
    }
    if( vatom_prev[ia].number != vatom[ia].number ||
	vatom_prev[ia].coords != vatom[ia].coords ){
      status = true;
      goto end_block;
    }
  }

end_block:
  vatom_prev = vatom;
  latvec_prev[0] = latvec[0];
  latvec_prev[1] = latvec[1];
  latvec_prev[2] = latvec[2];

  return status;
}

void DTRSDFT::findSymmetry( void )
{
  Position latvec[3];
  vector<DTAtom>& vatom = Atom.atom;

  if( vatom.empty() ) return;

  double metric_original[3][3];
  double metric_rotated[3][3];

  latvec[0] = A1;
  latvec[1] = A2;
  latvec[2] = A3;

  // check lattice is not changed
  if( !checkChanged( vatom, latvec ) ) return;

  // check this lattice has_inversion symmetry.
  // move all atoms so that the inversion center locates at the origin
  {
    Symmetry.has_inversion = false;

    const int ia = 0;
    const Coordinates coords0_transformed = vatom[ia].coords*(-1.0);

    for( int ja=0; ja<(int)vatom.size(); ja++ ){
      if( vatom[ja].number != vatom[ia].number ) continue;
      const Coordinates difference =
	Coordinates::normalize5(vatom[ja].coords - coords0_transformed);

      bool is_acceptable = true;
      for( int ka=0; ka<(int)vatom.size(); ka++ ){
	const Coordinates coords_transformed = vatom[ka].coords*(-1.0) + difference;
	const int element_number_transformed = vatom[ka].number;

	bool is_match = false;
	for( int la=0; la<(int)vatom.size(); la++ ){
	  if( vatom[la].number != element_number_transformed ) continue;
	  if( match( vatom[la].coords, coords_transformed ) ){
	    is_match = true;
	    break;
	  }
	} // end for la
	if( !is_match ){
	  is_acceptable = false;
	  break;
	}
      } // end for ka

      if( is_acceptable ){
	// it has inversion symmetry
	Symmetry.has_inversion = true;

	/*
	const Coordinates translation = difference*(-0.5);
	if( translation != Coordinates( 0.0, 0.0, 0.0 ) &&
	    MyException::question( "Move atoms for symmetry?" ) ){
	  // translate all atoms so that the inversion center locates on the origin
	  for( int ka=0; ka<(int)vatom.size(); ka++ ){
	    vatom[ka].coords += translation;
	    Coordinates::normalize(vatom[ka].coords);
	  }
	}
	*/
	break; // end of check
      }
    }
  } // end of check

  for( int i=0; i<3; i++ ){
    for( int j=0; j<3; j++ ){
      metric_original[i][j] = latvec[i] * latvec[j];
    }
  }

  IMatrix matrix;

  Symmetry.vmatrix.clear();
  matrix.initCanditate();
  do{
    if( nabs(matrix.determinant()) != 1 ){
      continue;
    }

    matrix.transformUnitary( metric_rotated, metric_original );

    if( !match( metric_rotated, metric_original ) ){
      continue;
    }

    const int ia = 0;
    const Coordinates coords0_transformed = matrix * vatom[ia].coords;

    for( int ja=0; ja<(int)vatom.size(); ja++ ){
      if( vatom[ja].number != vatom[ia].number ) continue;

      const Coordinates difference =
	Coordinates::normalize(vatom[ja].coords - coords0_transformed);

      matrix.T[0] = fraction(difference.a);
      matrix.T[1] = fraction(difference.b);
      matrix.T[2] = fraction(difference.c);
      if( !matrix.T[0].isvalid() ) continue;
      if( !matrix.T[1].isvalid() ) continue;
      if( !matrix.T[2].isvalid() ) continue;


      bool is_acceptable = true;

      for( int ka=0; ka<(int)vatom.size(); ka++ ){
	const Coordinates coords_transformed = matrix * vatom[ka].coords;
	const int element_number_transformed = vatom[ka].number;

	bool is_match = false;
	for( int la=0; la<(int)vatom.size(); la++ ){
	  if( vatom[la].number != element_number_transformed ) continue;
	  if( match( vatom[la].coords, coords_transformed ) ){
	    is_match = true;
	    break;
	  }
	} // end for la
	if( !is_match ){
	  is_acceptable = false;
	  break;
	}
      } // end for ka

      if( is_acceptable ){
	Symmetry.vmatrix.push_back(matrix);
      }
    } // end for ja
  }while( matrix.nextCanditate() );

  Symmetry.denom_trans=1;
  for( int n=0; n<(int)Symmetry.vmatrix.size(); n++ ){
    Symmetry.denom_trans = fraction::common_denominator
      ( Symmetry.denom_trans, Symmetry.vmatrix[n].T[0].denominator );
    Symmetry.denom_trans = fraction::common_denominator
      ( Symmetry.denom_trans, Symmetry.vmatrix[n].T[1].denominator );
    Symmetry.denom_trans = fraction::common_denominator
      ( Symmetry.denom_trans, Symmetry.vmatrix[n].T[2].denominator );
  }

  Symmetry.number_sym_op = Symmetry.vmatrix.size();

}
