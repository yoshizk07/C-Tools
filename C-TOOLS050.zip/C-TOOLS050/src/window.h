/*
 Copyright (c) 2014 Shinji Tsuneyuki
 This file is distributed under the terms of the GNU General Public License version 3.
 */

#ifndef __MAINWINDOW_H_INCLUDED
#define __MAINWINDOW_H_INCLUDED

#include <QtOpenGL/QGLWidget>
#include <QtCore/QString>

#include "dtmodel.h"

class MyEvent;
class QTFile;
class QTUnitLattice;
class QTRecpLattice;
class QTUDF;

class MainWindow : public QMainWindow
{
  Q_OBJECT

  DTModel model;
  QTabWidget*    tab;
  QTFile*        file;
  QTUnitLattice* unitlattice;
  QTRecpLattice* recplattice;
  QTUDF*         udf;

private:
  enum { ID_UNITLATTICE, ID_RECPLATTICE, ID_SOLVER };

public:
  MainWindow( void );

signals:
  void changed( void );
private slots:
  void edit( const MyEvent& ev );
  void editFile( const MyEvent& ev );
public slots:
  void update( void );

public:
  bool load( const QString& fname );
  bool load( const QString& format, const QString& fname );
  bool convert( const QString& informat, const QString& infile,
		const QString& outformat, const QString& outfile );
};

#endif // __MAINWINDOW_H_INCLUDED
