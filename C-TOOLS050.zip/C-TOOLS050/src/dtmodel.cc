/*
 Copyright (c) 2014 Shinji Tsuneyuki
 This file is distributed under the terms of the GNU General Public License version 3.
 */

/*!
 \file dtmodel.cc
 \brief �f�[�^�̓����N���X
*/

#include <vector>
using namespace std;

#include "dtmodel.h"
#include "qtxml.h"
#include "qtexception.h"
#include "symbol.h"

QString getDirName( const QString& path )
{
  int index;
  index = path.lastIndexOf("/");
  if( index == -1 ){
    index = path.lastIndexOf("\\");
  }
  if( index == -1 ){
    return QString(".");
  }
  return path.mid(0,index);
}

QString getFileName( const QString& path )
{
  int index;
  index = path.lastIndexOf("/");
  if( index == -1 ){
    index = path.lastIndexOf("\\");
  }
  return path.mid(index+1);
}


DTModel::DTModel( void )
{
  loadDefaults();
  clear();
}

void DTModel::update( void )
{
  lattice.update();
  udf.update();

  /*
  if( udf.isset() ){
    udf.getLattice(lattice);
  }
  */
  udf.setLattice( lattice );
  udf.getLattice( lattice );

  emit changed();
}

void DTModel::clear( void )
{
  lattice.clear();
  udf.clear();
  xtapp.clear();
  vasp.clear();
  openmx.clear();
  rsdft.clear();
  update();
}

QString DTModel::guess( const QString& fname )
{
  QString format;

  format = udf.guess(fname);
  if( format != "" ) return format;

  format = xtapp.guess(fname);
  if( format != "" ) return format;

  format = vasp.guess(fname);
  if( format != "" ) return format;

  format = openmx.guess(fname);
  if( format != "" ) return format;

  format = rsdft.guess(fname);
  if( format != "" ) return format;

  format = "";
  return format;
}

bool DTModel::convert
( const QString& informat, const QString& infile,
  const QString& outformat, const QString& outfile )
{
  if( false );
  else if( informat=="-udf" ){
    udf.load(infile);
  }
  else if( informat=="-xtapp" ){
    xtapp.load(infile);
    udf.convertFrom(xtapp);
  }
  else if( informat=="-vasp" ){
    vasp.load(infile);
    udf.convertFrom(vasp);
  }
  else if( informat=="-openmx" ){
    openmx.load(infile);
    udf.convertFrom(openmx);
  }
  else if( informat=="-rsdft" ){
    rsdft.load(infile);
    udf.convertFrom(rsdft);
  }
  else{
    throw MyException("unknown input format: %s\n", informat );
  }

  udf.getLattice(lattice);

  if( false );
  else if( outformat=="-udf" ){
    udf.save(outfile);
  }
  else if( outformat=="-xtapp" ){
    udf.convertTo(xtapp);
    xtapp.save(lattice,outfile);
  }
  else if( outformat=="-vasp" ){
    udf.convertTo(vasp);
    vasp.save(lattice,outfile);
  }
  else if( outformat=="-openmx" ){
    udf.convertTo(openmx);
    openmx.save(lattice,outfile);
  }
  else if( outformat=="-rsdft" ){
    udf.convertTo(rsdft);
    rsdft.save(lattice,outfile);
  }
  else{
    throw MyException("unknown output format: %s\n", outformat );
  }

  return true;
}



bool DTModel::loadXYZ( const QString& fname )
{
  if( lattice.molecule.loadXYZ(lattice.cell,fname) ){
    udf.setLattice(lattice);
    udf.getLattice(lattice);
    update();
    return true;
  }

  return false;
}

bool DTModel::loadCIF( const QString& fname )
{
  if( lattice.molecule.loadCIF(lattice.cell,fname) ){
    udf.setLattice(lattice);
    udf.getLattice(lattice);
    update();
    return true;
  }

  return false;
}

bool DTModel::loadUDF( const QString& fname )
{
  if( udf.load(fname) ){
    udf.getLattice(lattice);
    update();
    return true;
  }

  return false;
}

bool DTModel::saveUDF( const QString& fname )
{
  if( udf.save(fname) ){
    return true;
  }

  return false;
}

bool DTModel::loadXTAPP( const QString& fname )
{
  if( xtapp.load(fname) ){
    udf.convertFrom(xtapp);
    udf.getLattice(lattice);
    update();
    return true;
  }

  return false;
}

bool DTModel::saveXTAPP( const QString& fname )
{
  udf.convertTo(xtapp);
  if( xtapp.save(lattice,fname) ){
    return true;
  }

  return false;
}


bool DTModel::loadVASP( const QString& fname )
{
  if( vasp.load(fname) ){
    udf.convertFrom(vasp);
    udf.getLattice(lattice);
    update();
    return true;
  }

  return false;
}

bool DTModel::saveVASP( const QString& fname )
{
  udf.convertTo(vasp);
  if( vasp.save(lattice,fname) ){
    return true;
  }

  return false;
}

bool DTModel::loadOpenMX( const QString& fname )
{
  if( openmx.load(fname) ){
    udf.convertFrom(openmx);
    udf.getLattice(lattice);
    update();
    return true;
  }

  return false;
}

bool DTModel::saveOpenMX( const QString& fname )
{
  udf.convertTo(openmx);
  if( openmx.save(lattice,fname) ){
    return true;
  }

  return false;
}

bool DTModel::loadRSDFT( const QString& fname )
{
  if( rsdft.load(fname) ){
    udf.convertFrom(rsdft);
    udf.getLattice(lattice);
    update();
    return true;
  }

  return false;
}

bool DTModel::saveRSDFT( const QString& fname )
{
  udf.convertTo(rsdft);
  if( rsdft.save(lattice,fname) ){
    return true;
  }

  return false;
}

double DTModel::getScale( void ) const
{
  return lattice.getScale();
}


bool DTModel::loadDefaults( void )
{
  QDomDocument doc;
  const QString fname = "defaults.qtml";

  double value_low, value_normal, value_high;

  try{
    if( !XML::load( doc, fname) ){
      throw MyException("can not open the default file.",fname);
    }

    QDomNode root = XML::getRoot(doc);

    // UDF defaults
    {
      QDomElement group = XML::getFirstElementByTagName(root,"UDF");
      QDomElement node;

      node = XML::getFirstElementByTagName(group,"Cutoff_Wave_Function");
      XML::sscanf( XML::getAttribute(node,"value_low"), "%lf", &value_low );
      XML::sscanf( XML::getAttribute(node,"value_normal"), "%lf", &value_normal );
      XML::sscanf( XML::getAttribute(node,"value_high"), "%lf", &value_high );
      DTUDF::Common_Parameters::Calculation_Settings::Cutoff_Wave_Function_def
	.setTable( value_low, value_normal, value_high );

      node = XML::getFirstElementByTagName(group,"Mixing_Factor");
      XML::sscanf( XML::getAttribute(node,"value_low"), "%lf", &value_low );
      XML::sscanf( XML::getAttribute(node,"value_normal"), "%lf", &value_normal );
      XML::sscanf( XML::getAttribute(node,"value_high"), "%lf", &value_high );
      DTUDF::Common_Parameters::Calculation_Settings::Mixing_Factor_def
	.setTable( value_low, value_normal, value_high );

      node = XML::getFirstElementByTagName(group,"Electron_Max_Iteration");
      XML::sscanf( XML::getAttribute(node,"value_low"), "%lf", &value_low );
      XML::sscanf( XML::getAttribute(node,"value_normal"), "%lf", &value_normal );
      XML::sscanf( XML::getAttribute(node,"value_high"), "%lf", &value_high );
      DTUDF::Common_Parameters::Calculation_Settings::Electron_Max_Iteration_def
	.setTable( value_low, value_normal, value_high );

      node = XML::getFirstElementByTagName(group,"Energy_Converge");
      XML::sscanf( XML::getAttribute(node,"value_low"), "%lf", &value_low );
      XML::sscanf( XML::getAttribute(node,"value_normal"), "%lf", &value_normal );
      XML::sscanf( XML::getAttribute(node,"value_high"), "%lf", &value_high );
      DTUDF::Common_Parameters::Calculation_Settings::Energy_Converge_def
	.setTable( value_low, value_normal, value_high );

      node = XML::getFirstElementByTagName(group,"Force_Converge");
      XML::sscanf( XML::getAttribute(node,"value_low"), "%lf", &value_low );
      XML::sscanf( XML::getAttribute(node,"value_normal"), "%lf", &value_normal );
      XML::sscanf( XML::getAttribute(node,"value_high"), "%lf", &value_high );
      DTUDF::Common_Parameters::Calculation_Settings::Force_Converge_def
	.setTable( value_low, value_normal, value_high );
    }


    // xTAPP defaults
    {
      QDomElement group = XML::getFirstElementByTagName(root,"xTAPP");
      QDomElement node;

      node = XML::getFirstElementByTagName(group,"cutoff_wave_function");
      XML::sscanf( XML::getAttribute(node,"value_low"), "%lf", &value_low );
      XML::sscanf( XML::getAttribute(node,"value_normal"), "%lf", &value_normal );
      XML::sscanf( XML::getAttribute(node,"value_high"), "%lf", &value_high );
      DTXTapp::TappInput::cutoff_wave_function_def
	.setTable( value_low, value_normal, value_high );

      node = XML::getFirstElementByTagName(group,"xtrap_beta");
      XML::sscanf( XML::getAttribute(node,"value_low"), "%lf", &value_low );
      XML::sscanf( XML::getAttribute(node,"value_normal"), "%lf", &value_normal );
      XML::sscanf( XML::getAttribute(node,"value_high"), "%lf", &value_high );
      DTXTapp::TappInput::xtrap_beta_def
	.setTable( value_low, value_normal, value_high );

      node = XML::getFirstElementByTagName(group,"scf_number_iter");
      XML::sscanf( XML::getAttribute(node,"value_low"), "%lf", &value_low );
      XML::sscanf( XML::getAttribute(node,"value_normal"), "%lf", &value_normal );
      XML::sscanf( XML::getAttribute(node,"value_high"), "%lf", &value_high );
      DTXTapp::TappInput::scf_number_iter_def
	.setTable( value_low, value_normal, value_high );

      node = XML::getFirstElementByTagName(group,"scf_converge");
      XML::sscanf( XML::getAttribute(node,"value_low"), "%lf", &value_low );
      XML::sscanf( XML::getAttribute(node,"value_normal"), "%lf", &value_normal );
      XML::sscanf( XML::getAttribute(node,"value_high"), "%lf", &value_high );
      DTXTapp::TappInput::scf_converge_def
	.setTable( value_low, value_normal, value_high );

      node = XML::getFirstElementByTagName(group,"converge_force");
      XML::sscanf( XML::getAttribute(node,"value_low"), "%lf", &value_low );
      XML::sscanf( XML::getAttribute(node,"value_normal"), "%lf", &value_normal );
      XML::sscanf( XML::getAttribute(node,"value_high"), "%lf", &value_high );
      DTXTapp::StructOpt::converge_force_def
	.setTable( value_low, value_normal, value_high );
    }

    // VASP defaults
    {
      QDomElement group = XML::getFirstElementByTagName(root,"VASP");
      QDomElement node;

      node = XML::getFirstElementByTagName(group,"AMIX");
      XML::sscanf( XML::getAttribute(node,"value_low"), "%lf", &value_low );
      XML::sscanf( XML::getAttribute(node,"value_normal"), "%lf", &value_normal );
      XML::sscanf( XML::getAttribute(node,"value_high"), "%lf", &value_high );
      DTVasp::INCAR::AMIX_def.setTable( value_low, value_normal, value_high );

      node = XML::getFirstElementByTagName(group,"NELM");
      XML::sscanf( XML::getAttribute(node,"value_low"), "%lf", &value_low );
      XML::sscanf( XML::getAttribute(node,"value_normal"), "%lf", &value_normal );
      XML::sscanf( XML::getAttribute(node,"value_high"), "%lf", &value_high );
      DTVasp::INCAR::NELM_def.setTable( value_low, value_normal, value_high );

      node = XML::getFirstElementByTagName(group,"EDIFF");
      XML::sscanf( XML::getAttribute(node,"value_low"), "%lf", &value_low );
      XML::sscanf( XML::getAttribute(node,"value_normal"), "%lf", &value_normal );
      XML::sscanf( XML::getAttribute(node,"value_high"), "%lf", &value_high );
      DTVasp::INCAR::EDIFF_def.setTable( value_low, value_normal, value_high );

      node = XML::getFirstElementByTagName(group,"EDIFFG");
      XML::sscanf( XML::getAttribute(node,"value_low"), "%lf", &value_low );
      XML::sscanf( XML::getAttribute(node,"value_normal"), "%lf", &value_normal );
      XML::sscanf( XML::getAttribute(node,"value_high"), "%lf", &value_high );
      DTVasp::INCAR::EDIFFG_def.setTable( value_low, value_normal, value_high );
    }

    // OpenMX defaults
    {
      QDomElement group = XML::getFirstElementByTagName(root,"OpenMX");
      QDomElement node;

      node = XML::getFirstElementByTagName(group,"scf.energycutoff");
      XML::sscanf( XML::getAttribute(node,"value_low"), "%lf", &value_low );
      XML::sscanf( XML::getAttribute(node,"value_normal"), "%lf", &value_normal );
      XML::sscanf( XML::getAttribute(node,"value_high"), "%lf", &value_high );
      DTOpenMX::scf::energycutoff_def.setTable( value_low, value_normal, value_high );

      node = XML::getFirstElementByTagName(group,"scf.Max_Mixing_Weight");
      XML::sscanf( XML::getAttribute(node,"value_low"), "%lf", &value_low );
      XML::sscanf( XML::getAttribute(node,"value_normal"), "%lf", &value_normal );
      XML::sscanf( XML::getAttribute(node,"value_high"), "%lf", &value_high );
      DTOpenMX::scf::Max_Mixing_Weight_def.setTable( value_low, value_normal, value_high );

      node = XML::getFirstElementByTagName(group,"scf.maxIter");
      XML::sscanf( XML::getAttribute(node,"value_low"), "%lf", &value_low );
      XML::sscanf( XML::getAttribute(node,"value_normal"), "%lf", &value_normal );
      XML::sscanf( XML::getAttribute(node,"value_high"), "%lf", &value_high );
      DTOpenMX::scf::maxIter_def.setTable( value_low, value_normal, value_high );

      node = XML::getFirstElementByTagName(group,"scf.criterion");
      XML::sscanf( XML::getAttribute(node,"value_low"), "%lf", &value_low );
      XML::sscanf( XML::getAttribute(node,"value_normal"), "%lf", &value_normal );
      XML::sscanf( XML::getAttribute(node,"value_high"), "%lf", &value_high );
      DTOpenMX::scf::criterion_def.setTable( value_low, value_normal, value_high );

      node = XML::getFirstElementByTagName(group,"Md.Opt_criterion");
      XML::sscanf( XML::getAttribute(node,"value_low"), "%lf", &value_low );
      XML::sscanf( XML::getAttribute(node,"value_normal"), "%lf", &value_normal );
      XML::sscanf( XML::getAttribute(node,"value_high"), "%lf", &value_high );
      DTOpenMX::MD::Opt_criterion_def.setTable( value_low, value_normal, value_high );

      QString element, Accuracy, pao, mode, vps;

      QDomElement atoms = XML::getFirstElementByTagName(group,"AtomicSpecies");
      vector<QDomElement> vatom = XML::getElementsByTagName(atoms,"atom");

      DTOpenMX::AtomicSpecies::velement[0].resize(ElementSymbol::Lr+1);
      DTOpenMX::AtomicSpecies::velement[1].resize(ElementSymbol::Lr+1);
      DTOpenMX::AtomicSpecies::velement[2].resize(ElementSymbol::Lr+1);

      for( int i=0; i<(int)vatom.size(); i++ ){
	XML::sscanf( XML::getAttribute(vatom[i],"element"), "%s", &element );
	XML::sscanf( XML::getAttribute(vatom[i],"accuracy"), "%s", &Accuracy );

	vector<DTOpenMX::AtomicSpecies::Element>& velement =
	  Accuracy == "Low"    ? DTOpenMX::AtomicSpecies::velement[0] :
	  Accuracy == "Normal" ? DTOpenMX::AtomicSpecies::velement[1] :
	  Accuracy == "High"   ? DTOpenMX::AtomicSpecies::velement[2] :
	  DTOpenMX::AtomicSpecies::velement[1];

	const int number = ElementSymbol::getAtomicNumber(element);

	XML::sscanf( XML::getAttribute(vatom[i],"pao"),  "%s", &pao );
	XML::sscanf( XML::getAttribute(vatom[i],"mode"), "%s", &mode );
	XML::sscanf( XML::getAttribute(vatom[i],"vps"),  "%s", &vps );

	velement[number] = DTOpenMX::AtomicSpecies::Element(element,pao,mode,vps);
      }
    }


    // RSDFT defaults
    {
      QDomElement group = XML::getFirstElementByTagName(root,"RSDFT");
      QDomElement node;

      node = XML::getFirstElementByTagName(group,"DGRID");
      XML::sscanf( XML::getAttribute(node,"value_low"), "%lf", &value_low );
      XML::sscanf( XML::getAttribute(node,"value_normal"), "%lf", &value_normal );
      XML::sscanf( XML::getAttribute(node,"value_high"), "%lf", &value_high );
      DTRSDFT::DGRID_def.setTable( value_low, value_normal, value_high );

      node = XML::getFirstElementByTagName(group,"BETA");
      XML::sscanf( XML::getAttribute(node,"value_low"), "%lf", &value_low );
      XML::sscanf( XML::getAttribute(node,"value_normal"), "%lf", &value_normal );
      XML::sscanf( XML::getAttribute(node,"value_high"), "%lf", &value_high );
      DTRSDFT::BETA_def.setTable( value_low, value_normal, value_high );

      node = XML::getFirstElementByTagName(group,"DITER");
      XML::sscanf( XML::getAttribute(node,"value_low"), "%lf", &value_low );
      XML::sscanf( XML::getAttribute(node,"value_normal"), "%lf", &value_normal );
      XML::sscanf( XML::getAttribute(node,"value_high"), "%lf", &value_high );
      DTRSDFT::DITER_def.setTable( value_low, value_normal, value_high );

      node = XML::getFirstElementByTagName(group,"SCFCONV");
      XML::sscanf( XML::getAttribute(node,"value_low"), "%lf", &value_low );
      XML::sscanf( XML::getAttribute(node,"value_normal"), "%lf", &value_normal );
      XML::sscanf( XML::getAttribute(node,"value_high"), "%lf", &value_high );
      DTRSDFT::SCFCONV_def.setTable( value_low, value_normal, value_high );

      node = XML::getFirstElementByTagName(group,"ATOMOPT2");
      XML::sscanf( XML::getAttribute(node,"value_low"), "%lf", &value_low );
      XML::sscanf( XML::getAttribute(node,"value_normal"), "%lf", &value_normal );
      XML::sscanf( XML::getAttribute(node,"value_high"), "%lf", &value_high );
      DTRSDFT::ATOMOPT2_def.setTable( value_low, value_normal, value_high );
    }
  }
  catch( const MyException& e ){
    MyException::critical(e);
    return false;
  }

  return true;
}
