/*
 Copyright (c) 2014 Shinji Tsuneyuki
 This file is distributed under the terms of the GNU General Public License version 3.
 */

#ifndef __DTRSDFT_H_INCLUDED
#define __DTRSDFT_H_INCLUDED

#include <QtCore/QString>
#include "position.h"
#include "imatrix.h"
#include "dtatoms.h"
#include "table.h"

#include <vector>
using namespace std;

class DTLattice;

struct DTRSDFT
{
  int    ISYM;
  QString XCTYPE;

  double AX;
  Position A1, A2, A3;
  int    NBAND;
  int    NSPIN;

  double DGRID; // minimum grid spacing
  static Table DGRID_def;
  double BETA;
  static Table BETA_def;
  int    DITER;
  static Table DITER_def;
  double SCFCONV;
  static Table SCFCONV_def;
  double ATOMOPT2; // FEPS
  static Table ATOMOPT2_def; // FEPS

  int    SWSCF;
  int    SWOPT;
  int    SWBAND;
  int    ATOMOPT1;

  int    nkmesh[3];
  int    skmesh[3];

  struct Symmetry{
    int  number_sym_op;
    bool has_inversion;
    int  denom_trans;
    vector<IMatrix> vmatrix;
  } Symmetry;

  struct Atom {
    vector<DTAtom> atom;
  } Atom;

  DTRSDFT( void ){
  }
  ~DTRSDFT( void ){
    clear();
  }
  void clear( void );
  QString guess( const QString& fname );
  bool load( const QString& fname );
  bool save( const DTLattice& lattice, const QString& fname ) const;

  void findSymmetry( void );
};

#endif // __DTRSDFT_H_INCLUDED
