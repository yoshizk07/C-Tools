/*
 Copyright (c) 2014 Shinji Tsuneyuki
 This file is distributed under the terms of the GNU General Public License version 3.
 */

/*!
 \file glatoms.h
 \brief �i�q�̌��q��GL�\���̃N���X
*/

#ifndef __GLATOMS_H_INCLUDED
#define __GLATOMS_H_INCLUDED

#include "glbase.h"

class DTModel;
class DTAtom;

class GLAtoms : public GLBase
{
private:
  DTModel& model;

public:
  GLAtoms( DTModel& _model ) : model(_model) {}

private:
  void makeAtom( const DTAtom& atom );
  void makeAtomSelected( const DTAtom& atom );

public:
  void update( void );
};

#endif // __GLATOMS_H_INCLUDED
