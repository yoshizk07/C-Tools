/*
 Copyright (c) 2014 Shinji Tsuneyuki
 This file is distributed under the terms of the GNU General Public License version 3.
 */

#ifndef __DTVASP_H_INCLUDED
#define __DTVASP_H_INCLUDED

#include <QtCore/QString>
#include "position.h"
#include "dtatoms.h"
#include "table.h"

#include <vector>
using namespace std;

struct DTVasp
{
  struct INCAR {
    QString SYSTEM;
    QString PREC;
    QString GGA;
    double AEXX;
    double AGGAC;
    double ALDAC;
    double AMIX,AMIX_min,AMIX_max;
    double EDIFF,EDIFF_min,EDIFF_max;
    double EDIFFG;
    double SIGMA;
    int ICHARG;
    int ISMEAR;
    int ISPIN;
    int ISTART;
    int ISYM;
    int NBANDS;
    int NELM,NELM_min,NELM_max;
    int NSW;
    bool LHFCAL;

    static QString SYSTEM_def;
    static QString GGA_def;

    static Table  AMIX_def;
    static Table  NELM_def;
    static Table  EDIFF_def;
    static Table  EDIFFG_def;

    static double AEXX_def;
    static double AGGAC_def;
    static double ALDAC_def;
    static double SIGMA_def;
    static int ICHARG_def;
    static int ISMEAR_def;
    static int ISPIN_def;
    static int ISTART_def;
    static int ISYM_def;
    static int NBANDS_def;

    static int NSW_def;
    static bool LHFCAL_def;
  } INCAR;

  struct POSCAR {
    double lattice_factor;
    Position lattice_list[3];
    vector<DTAtom> atom;
  } POSCAR;

  struct KPOINT {
    int nkmesh[3];
    int number_band_traced;
  } KPOINT;

  DTVasp( void ){
  }
  ~DTVasp( void ){
    clear();
  }

  void clear( void );
  QString guess( const QString& fname );
  bool load( const QString& fname );
  bool save( const DTLattice& lattice, const QString& fname ) const;
};

#endif // __DTVASP_H_INCLUDED
