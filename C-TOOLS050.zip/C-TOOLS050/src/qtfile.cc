/*
 Copyright (c) 2014 Shinji Tsuneyuki
 This file is distributed under the terms of the GNU General Public License version 3.
 */

/*!
 \file qtfile.cc
 \brief �t�@�C�������GUI�\���̃N���X
*/

#include "qtfile.h"
#include "dtmodel.h"
#include "qtexception.h"
#include "qtmisc.h"

QTFile::QTFile( DTModel& _model ) : model(_model)
{
  QVBoxLayout* layout = new QVBoxLayout(this);
  layout->setSizeConstraint( QLayout::SetFixedSize );

  {
    MyQPushButton* widget = new MyQPushButton
      ("clear", this, SLOT(edit(const MyEvent&)), ID_CLEAR );
    layout->addWidget(widget);
  }
  {
    MyQPushButton* widget = new MyQPushButton
      ("load", this, SLOT(edit(const MyEvent&)), ID_LOAD );
    layout->addWidget(widget);
  }

  {
    MyQPushButton* widget = new MyQPushButton
      ("save", this, SLOT(edit(const MyEvent&)), ID_SAVE );
    layout->addWidget(widget);
  }
  {
    MyQPushButton* widget = new MyQPushButton
      ("quit", this, SLOT(edit(const MyEvent&)), ID_QUIT );
    layout->addWidget(widget);
  }

  setLayout(layout);

  update();
}


void QTFile::edit( const MyEvent& ev )
{
  static bool first = true;
  if( first ){
    path = QDir::currentPath();
    first = false;
  }

  switch(ev.id){
  case ID_CLEAR : {
    model.clear();
  } break;

  case ID_LOAD : {
    QString fname = QFileDialog::getOpenFileName
      ( this, tr("Load a file"), path,
	tr("Molecule structure file(*.xyz);;"
	   "Crystal structure file(*.cif);;"
	   "UDF input file(*.udf);;"
	   "xTAPP input file(*.cg);;"
	   "VASP input file(INCAR);;"
	   "OpenMX input file(*.dat);;"
	   "RSDFT input file(fort.1);;"
	   ));
    load( fname );
  } break;

  case ID_SAVE : {
    QString fname = QFileDialog::getSaveFileName
      ( this, tr("Save a file"), path,
	tr("UDF input file(*.udf);;"
	   "xTAPP input file(*.cg);;"
	   "VASP input file(INCAR);;"
	   "OpenMX input file(*.dat);;"
	   "RSDFT input file(fort.1);;"
	   ));
    save(fname);
  } break;

  case ID_QUIT : {
    qApp->closeAllWindows();
  } break;

  default : break;
  }
}

void QTFile::update( void )
{
}

bool QTFile::load( const QString& fname )
{
  bool status = false;

  try{
    if( false );
    else if( fname.endsWith( ".xyz" ) ){
      status = model.loadXYZ(fname);
      if( status ){
	MyException::information("loaded a molecule structure");
	emit changed(MyEvent(ID_LOAD_MOLECULE));
      }
    }
    else if( fname.endsWith( ".cif" ) ){
      status = model.loadCIF(fname);
      if( status ){
	MyException::information("loaded a crystal structure");
	emit changed(MyEvent(ID_LOAD_MOLECULE));
      }
    }
    else if( fname.endsWith( ".udf" ) ){
      status = model.loadUDF(fname);
      if( status ){
	MyException::information("loaded UDF");
	emit changed(MyEvent(ID_LOAD_SOLVER));
      }
    }
    else if( fname.endsWith( ".cg" ) ){
      status = model.loadXTAPP(fname);
      if( status ){
	MyException::information("converted XTAPP to UDF");
	emit changed(MyEvent(ID_LOAD_SOLVER));
      }
    }
    else if( fname.endsWith( "INCAR" ) ){
      status = model.loadVASP(fname);
      if( status ){
	MyException::information("converted VASP to UDF");
	emit changed(MyEvent(ID_LOAD_SOLVER));
      }
    }
    else if( fname.endsWith( ".dat" ) ){
      status = model.loadOpenMX(fname);
      if( status ){
	MyException::information("converted OpenMX to UDF");
	emit changed(MyEvent(ID_LOAD_SOLVER));
      }
    }
    else if( fname.endsWith( "fort.1" ) ){
      status = model.loadRSDFT(fname);
      if( status ){
	MyException::information("converted RSDFT to UDF");
	emit changed(MyEvent(ID_LOAD_SOLVER));
      }
    }
    else if( fname != "" ){
      const QString format = model.guess(fname);

      if( false );
      else if( format == "solver udf format" ){
	status = model.loadUDF(fname);
	if( status ){
	  MyException::information("loaded UDf");
	  emit changed(MyEvent(ID_LOAD_SOLVER));
	}
      }
      else if( format == "solver xtapp format" ){
	status = model.loadXTAPP(fname);
	if( status ){
	  MyException::information("converted XTAPP to UDF");
	  emit changed(MyEvent(ID_LOAD_SOLVER));
	}
      }
      else if( format == "solver vasp format" ){
	status = model.loadVASP(fname);
	if( status ){
	  MyException::information("converted VASP to UDF");
	  emit changed(MyEvent(ID_LOAD_SOLVER));
	}
      }
      else if( format == "solver openmx format" ){
	status = model.loadOpenMX(fname);
	if( status ){
	  MyException::information("converted OpenMX to UDF");
	  emit changed(MyEvent(ID_LOAD_SOLVER));
	}
      }
      else if( format == "solver rsdft format" ){
	status = model.loadRSDFT(fname);
	if( status ){
	  MyException::information("converted RSDFT to UDF");
	  emit changed(MyEvent(ID_LOAD_SOLVER));
	}
      }
      else{
	throw MyException("unknown file format.",fname);
      }
    }
    if( status ){
      path = getDirName(fname);
    }
  }
  catch( const MyException& e ){
    MyException::critical(e);
  }

  return status;
}

bool QTFile::save( const QString& fname )
{
  bool status = false;

  try{
    if( false );
    else if( fname.endsWith( ".udf" ) ){
      status = model.saveUDF(fname);
      if( status ){
	MyException::information("saved to UDF");
	emit changed(MyEvent(ID_SAVE_SOLVER));
      }
    }
    else if( fname.endsWith( ".cg" ) ){
      status = model.saveXTAPP(fname);
      if( status ){
	MyException::information("converted UDF to XTAPP");
	emit changed(MyEvent(ID_SAVE_SOLVER));
      }
    }
    else if( fname.endsWith( "INCAR" ) ){
      status = model.saveVASP(fname);
      if( status ){
	MyException::information("converted UDF to VASP");
	emit changed(MyEvent(ID_SAVE_SOLVER));
      }
    }
    else if( fname.endsWith( ".dat" ) ){
      status = model.saveOpenMX(fname);
      if( status ){
      MyException::information("converted UDF to OpenMX");
	emit changed(MyEvent(ID_LOAD_SOLVER));
      }
    }
    else if( fname.endsWith( "fort.1" ) ){
      status = model.saveRSDFT(fname);
      if( status ){
	MyException::information("converted UDF to RSDFT");
	emit changed(MyEvent(ID_SAVE_SOLVER));
      }
    }
    else if( fname != "" ){
      throw MyException("file sufix unknown.",fname);
    }
    if( status ){
      path = getDirName(fname);
    }
  }
  catch( const MyException& e ){
    MyException::critical(e);
  }

  return status;
}
